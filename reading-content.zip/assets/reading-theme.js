(() => {
  'use strict';
  const node = document.getElementById('reading-artwork-catalog');
  if (!node) return;
  const config = JSON.parse(node.textContent);
  const images = config.images;
  if (!images.length) return;
  const key = 'daily-reading-artwork-rotation-v1';
  const signature = images.map(image => image.id).join('|');
  let state = {};
  try { state = JSON.parse(localStorage.getItem(key) || '{}'); }
  catch {
    try { if (window.name.startsWith(key + ':')) state = JSON.parse(window.name.slice(key.length + 1)); } catch {}
  }
  if (!state || typeof state !== 'object') state = {};
  const ids = images.map(image => image.id);
  let selected = images[0];
  if (config.randomize) {
    let deck = state.signature === signature && Array.isArray(state.deck)
      ? [...new Set(state.deck.filter(id => ids.includes(id)))] : [];
    if (!deck.length) {
      deck = [...ids];
      for (let i = deck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]];
      }
    }
    if (deck.length > 1 && deck[deck.length - 1] === state.last) {
      [deck[0], deck[deck.length - 1]] = [deck[deck.length - 1], deck[0]];
    }
    const next = deck.pop();
    selected = images.find(image => image.id === next) || selected;
    const saved = JSON.stringify({signature, deck, last: selected.id});
    try { localStorage.setItem(key, saved); }
    catch { try { window.name = key + ':' + saved; } catch {} }
  }
  let active = -1;
  const apply = image => {
    for (const [name, color] of Object.entries(image.theme)) {
      document.documentElement.style.setProperty('--reading-' + name, color);
    }
    document.documentElement.dataset.readingArtwork = image.id;
    const art = document.getElementById('reading-artwork');
    if (art) {
      art.src = image.src;
      art.alt = '本次阅读配图';
    }
    for (const id of ['reading-favicon', 'reading-touch-icon']) {
      const icon = document.getElementById(id);
      if (icon) { icon.removeAttribute('type'); icon.href = image.src; }
    }
  };
  // If a picture was removed or damaged, try the remaining originals.
  const attempt = image => {
    const index = images.indexOf(image);
    active = index;
    const probe = new Image();
    probe.onload = () => { if (active === index) apply(image); };
    probe.onerror = () => {
      if (active !== index || images.length === 1) return;
      const next = images[(index + 1) % images.length];
      if (next !== selected) attempt(next);
    };
    probe.src = image.src;
  };
  apply(selected);
  attempt(selected);
})();
