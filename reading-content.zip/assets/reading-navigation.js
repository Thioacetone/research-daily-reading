(() => {
  if (window.readingNavigationHandler) {
    document.removeEventListener('click', window.readingNavigationHandler, true);
  }
  window.readingNavigationHandler = event => {
    if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const link = event.target.closest?.('a[href^="#reading-"]');
    if (!link) return;
    const anchor = link.getAttribute('href');
    if (!/^#(?:reading-paper-\d+|reading-top)$/.test(anchor)) return;
    const target = document.getElementById(anchor.slice(1));
    if (!target) return;
    event.preventDefault();
    event.stopPropagation();
    target.scrollIntoView({block: 'start', behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth'});
    target.setAttribute('tabindex', '-1');
    target.focus({preventScroll: true});
  };
  document.addEventListener('click', window.readingNavigationHandler, true);
  // Issue generation happens in advance; change the directory at Beijing midnight.
  // Never interrupt an open paper or the archive while someone is reading.
  if (window.readingMidnightTimer) clearTimeout(window.readingMidnightTimer);
  if (window.readingDayVisibility) document.removeEventListener('visibilitychange', window.readingDayVisibility);
  const clock = window.ReadingClock;
  if (clock) {
    const openedDay = clock.day(Date.now());
    const isTodayDirectory = () => {
      const query = new URLSearchParams(location.search);
      return !query.has('paper') && query.get('view') !== 'archive';
    };
    const refreshDay = () => {
      if (clock.day(Date.now()) !== openedDay && isTodayDirectory()) location.reload();
    };
    window.readingMidnightTimer = setTimeout(refreshDay, clock.untilMidnight(Date.now()) + 250);
    window.readingDayVisibility = () => { if (!document.hidden) refreshDay(); };
    document.addEventListener('visibilitychange', window.readingDayVisibility);
  }
})();

// A non-searchable Streamlit select still renders a text input. Make it a
// read-only choice control and open its existing menu instead of selecting text.
(() => {
  const key = '__readingChoiceGuardV1';
  if (window[key]) { window[key].refresh(); return; }
  const selector = '[data-testid="stSelectbox"] input[role="combobox"]';
  const inputFor = event => event.target instanceof Element && event.target.matches(selector) ? event.target : null;
  const refresh = () => document.querySelectorAll(selector).forEach(input => {
    input.readOnly = true;
    input.setAttribute('aria-autocomplete', 'none');
    input.setAttribute('inputmode', 'none');
  });
  const prevent = event => { event.preventDefault(); event.stopPropagation(); };
  document.addEventListener('pointerdown', event => {
    const input = inputFor(event);
    if (!input || event.button !== 0) return;
    const button = input.closest('[role="group"]')?.querySelector('button');
    if (button && !button.disabled) { prevent(event); button.click(); }
  }, true);
  document.addEventListener('keydown', event => {
    if (!inputFor(event)) return;
    const shortcut = (event.ctrlKey || event.metaKey) && /^[axv]$/i.test(event.key);
    const typedText = event.key.length === 1 && event.key !== ' ' && !event.ctrlKey && !event.metaKey;
    if (shortcut || typedText || event.key === 'Backspace' || event.key === 'Delete') prevent(event);
  }, true);
  for (const name of ['beforeinput', 'paste', 'cut', 'drop']) {
    document.addEventListener(name, event => { if (inputFor(event)) prevent(event); }, true);
  }
  document.addEventListener('select', event => {
    const input = inputFor(event);
    if (input && input.selectionStart !== input.selectionEnd) input.setSelectionRange(input.selectionEnd, input.selectionEnd);
  }, true);
  new MutationObserver(refresh).observe(document.documentElement, {childList: true, subtree: true});
  window[key] = {refresh};
  refresh();
})();

// Community Cloud owns an outer same-origin frame. Styles confined to the
// Streamlit app cannot hide the controls that Cloud inserts around that frame.
(() => {
  const guardKey = '__readingChromeGuardV1';
  const styleId = 'reading-cloud-chrome';
  const css = `
    header[data-testid="stHeader"], [data-testid="stToolbar"],
    [data-testid="stStatusWidget"], [data-testid="stDecoration"],
    [data-testid="stMainMenu"], #MainMenu, .stDeployButton,
    [data-testid="stAppDeployButton"], [data-testid="manage-app-button"],
    [data-testid="stAppViewerBadge"], [data-testid="app-viewer-badge"],
    [class*="viewerBadge"], footer:not(.reader-publication) {
      display: none !important;
    }
  `;
  const install = doc => {
    const win = doc.defaultView;
    if (!win || !doc.documentElement) return;
    if (win[guardKey]) { win[guardKey].refresh(); return; }
    const frames = new WeakSet();
    let scheduled = false;
    const refresh = () => {
      scheduled = false;
      let style = doc.getElementById(styleId);
      if (!style) {
        style = doc.createElement('style');
        style.id = styleId;
        (doc.head || doc.documentElement).appendChild(style);
      }
      if (style.textContent !== css) style.textContent = css;
      // The optional embed footer is outside the paper app, alongside its frame.
      if (doc.querySelector('iframe[title="streamlitApp"]')) {
        doc.querySelectorAll('[class*="_hostedName_"]').forEach(label => {
          const parent = label.parentElement;
          if (/^Built with Streamlit/.test(label.textContent.trim()) && parent &&
              parent.querySelector('a[href*="utm_medium=oembed"]') && !parent.querySelector('iframe')) {
            parent.style.setProperty('display', 'none', 'important');
          }
        });
      }
      doc.querySelectorAll('iframe[title="streamlitApp"]').forEach(frame => {
        const follow = () => {
          try { if (frame.contentDocument) install(frame.contentDocument); }
          catch (_) { /* Do not touch a cross-origin frame. */ }
        };
        if (!frames.has(frame)) { frames.add(frame); frame.addEventListener('load', follow); }
        follow();
      });
    };
    const observer = new win.MutationObserver(() => {
      if (!scheduled) { scheduled = true; win.setTimeout(refresh, 0); }
    });
    win[guardKey] = { refresh };
    observer.observe(doc.documentElement, { childList: true, subtree: true });
    refresh();
  };
  let current = window;
  while (current) {
    try {
      install(current.document);
      if (current === current.parent) break;
      // Accessing .document throws when the next parent has another origin.
      current.parent.document;
      current = current.parent;
    } catch (_) { break; }
  }
})();
