(() => {
  if (window.readingNavigationHandler) {
    document.removeEventListener('click', window.readingNavigationHandler, true);
  }
  window.readingNavigationHandler = event => {
    if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const link = event.target.closest?.('a[href^="#reading-"]');
    if (!link) return;
    const anchor = link.getAttribute('href');
    if (!/^#(?:reading-paper-\d+|reading-top)$/.test(anchor)) return;
    const target = document.getElementById(anchor.slice(1));
    if (!target) return;
    event.preventDefault();
    event.stopPropagation();
    target.scrollIntoView({block: 'start', behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth'});
    target.setAttribute('tabindex', '-1');
    target.focus({preventScroll: true});
  };
  document.addEventListener('click', window.readingNavigationHandler, true);
  // Issue generation happens in advance; change the directory at Beijing midnight.
  // Never interrupt an open paper or the archive while someone is reading.
  if (window.readingMidnightTimer) clearTimeout(window.readingMidnightTimer);
  if (window.readingDayVisibility) document.removeEventListener('visibilitychange', window.readingDayVisibility);
  const clock = window.ReadingClock;
  if (clock) {
    const openedDay = clock.day(Date.now());
    const isTodayDirectory = () => {
      const query = new URLSearchParams(location.search);
      return !query.has('paper') && query.get('view') !== 'archive';
    };
    const refreshDay = () => {
      if (clock.day(Date.now()) !== openedDay && isTodayDirectory()) location.reload();
    };
    window.readingMidnightTimer = setTimeout(refreshDay, clock.untilMidnight(Date.now()) + 250);
    window.readingDayVisibility = () => { if (!document.hidden) refreshDay(); };
    document.addEventListener('visibilitychange', window.readingDayVisibility);
  }
})();
