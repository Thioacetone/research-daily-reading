(() => {
  if (window.readingNavigationHandler) {
    document.removeEventListener('click', window.readingNavigationHandler, true);
  }
  window.readingNavigationHandler = event => {
    if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const link = event.target.closest?.('a[href^="#reading-"]');
    if (!link) return;
    const anchor = link.getAttribute('href');
    if (!/^#(?:reading-paper-\d+|reading-top)$/.test(anchor)) return;
    const target = document.getElementById(anchor.slice(1));
    if (!target) return;
    event.preventDefault();
    event.stopPropagation();
    target.scrollIntoView({block: 'start', behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth'});
    target.setAttribute('tabindex', '-1');
    target.focus({preventScroll: true});
  };
  document.addEventListener('click', window.readingNavigationHandler, true);
})();
