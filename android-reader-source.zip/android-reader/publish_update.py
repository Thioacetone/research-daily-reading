"""Publish one verified, signed APK plus its machine-readable update manifest."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess

def publish(root):
    project=root/'android-reader';output=project/'app/build/outputs/apk/release'
    metadata=json.loads((output/'output-metadata.json').read_text(encoding='utf-8'))
    if metadata['applicationId']!='com.thioacetone.reading' or len(metadata['elements'])!=1:
        raise ValueError('Unexpected application or split APK output')
    entry=metadata['elements'][0];version=int(entry['versionCode']);name=entry['versionName'];filename=entry['outputFile']
    if Path(filename).name!=filename or not filename.endswith('.apk'):raise ValueError('Unexpected APK path')
    apk=output/filename
    tools=sorted((Path(os.environ['ANDROID_HOME'])/'build-tools').glob('*/apksigner'))
    if not tools:raise ValueError('APK signature verifier unavailable')
    verification=subprocess.run([str(tools[-1]),'verify','--print-certs',str(apk)],capture_output=True,text=True,check=True).stdout
    match=re.search(r'Signer #1 certificate SHA-256 digest: ([a-fA-F0-9]{64})',verification)
    expected=(project/'signing-certificate.sha256').read_text().strip().lower()
    if not match or match.group(1).lower()!=expected:raise ValueError('Unexpected Android signing certificate')
    data=apk.read_bytes();digest=hashlib.sha256(data).hexdigest()
    relative=Path('android/releases')/str(version)/'daily-reading.apk';target=root/relative
    if target.exists() and hashlib.sha256(target.read_bytes()).hexdigest()!=digest:
        raise ValueError('A published version cannot be overwritten')
    target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(apk,target)
    shutil.copyfile(apk,root/'daily-reading-android.apk')
    (root/'daily-reading-android.apk.sha256').write_text(digest+'  daily-reading-android.apk\n',encoding='ascii')
    manifest={'schemaVersion':1,'packageId':'com.thioacetone.reading','versionCode':version,'versionName':name,'minSdk':26,
        'sizeBytes':len(data),'sha256':digest,'signingCertificateSha256':expected,
        'apkUrl':'https://raw.githubusercontent.com/Thioacetone/research-daily-reading/main/'+relative.as_posix(),
        'releaseNotes':(project/'release-notes.txt').read_text(encoding='utf-8').strip()}
    (root/'android-update.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'versionCode':version,'versionName':name,'sizeBytes':len(data),'sha256':digest,'signatureVerified':True}))
if __name__=='__main__':publish(Path.cwd())
