package com.thioacetone.reading;

import java.net.URI;
import java.security.MessageDigest;
import java.util.Locale;

/** Checks used both by the Android updater and ordinary JVM unit tests. */
public final class UpdatePolicy {
    private UpdatePolicy() { }
    public static void validate(long version,String url,String sha256,long size,int minSdk) {
        if(version<1 || version>Integer.MAX_VALUE || size<1 || size>40_000_000 || minSdk<26)
            throw new IllegalArgumentException("更新信息不完整");
        URI uri=URI.create(url);
        String path="/Thioacetone/research-daily-reading/main/android/releases/"+version+"/daily-reading.apk";
        if(!"https".equals(uri.getScheme()) || !"raw.githubusercontent.com".equals(uri.getHost())
                || uri.getPort()!=-1 || uri.getUserInfo()!=null || uri.getFragment()!=null
                || uri.getQuery()!=null || !path.equals(uri.getRawPath()))
            throw new IllegalArgumentException("更新地址不属于本应用的发布仓库");
        if(sha256==null || !sha256.matches("[a-f0-9]{64}"))
            throw new IllegalArgumentException("更新校验值无效");
    }
    public static boolean sameDigest(String expected,String actual) {
        return expected!=null && actual!=null && MessageDigest.isEqual(
            expected.toLowerCase(Locale.ROOT).getBytes(java.nio.charset.StandardCharsets.US_ASCII),
            actual.toLowerCase(Locale.ROOT).getBytes(java.nio.charset.StandardCharsets.US_ASCII));
    }
    public static boolean isUpgrade(String installedId,long installedVersion,String candidateId,long candidateVersion) {
        return installedId.equals(candidateId) && candidateVersion>installedVersion;
    }
}
