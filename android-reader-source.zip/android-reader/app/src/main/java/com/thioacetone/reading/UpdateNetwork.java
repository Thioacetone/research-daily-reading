package com.thioacetone.reading;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLException;

/** Two first-party delivery origins; neither credentials nor arbitrary redirects. */
public final class UpdateNetwork {
    public static final String PAGES="https://thioacetone.github.io/research-daily-reading/";
    public static final String RAW="https://raw.githubusercontent.com/Thioacetone/research-daily-reading/main/";
    private UpdateNetwork() { }
    public interface Reader<T> { T read(String address) throws Exception; }
    public static String[] manifests() { return new String[]{PAGES+"android-update.json",RAW+"android-update.json"}; }
    public static String[] downloads(long version,String canonical) {
        String path="android/releases/"+version+"/daily-reading.apk";
        if(version<1 || version>Integer.MAX_VALUE || !(RAW+path).equals(canonical))
            throw new IllegalArgumentException("更新地址不属于本应用的发布仓库");
        return new String[]{PAGES+path,canonical};
    }
    public static void requireEndpoint(String address) {
        String relative;
        if(address.startsWith(PAGES))relative=address.substring(PAGES.length());
        else if(address.startsWith(RAW))relative=address.substring(RAW.length());
        else throw new IllegalArgumentException("更新地址不属于本应用");
        if(!relative.equals("android-update.json") &&
                !relative.matches("android/releases/[1-9][0-9]{0,9}/daily-reading\\.apk"))
            throw new IllegalArgumentException("更新路径无效");
    }
    public static final class RouteFailure extends IOException {
        RouteFailure(List<String> failures) { super(String.join("\n",failures)); }
    }
    public static <T> T firstAvailable(String[] addresses,Reader<T> reader) throws Exception {
        List<String> failures=new ArrayList<>();
        for(String address:addresses) {
            requireEndpoint(address);
            if(Thread.currentThread().isInterrupted())throw new InterruptedException();
            try { return reader.read(address); }
            catch(InterruptedException stopped) { Thread.currentThread().interrupt();throw stopped; }
            catch(Exception error) { failures.add(URI.create(address).getHost()+"："+describe(error)); }
        }
        throw new RouteFailure(failures);
    }
    public static HttpsURLConnection open(String address) throws Exception {
        requireEndpoint(address);
        HttpsURLConnection connection=(HttpsURLConnection)new URL(address).openConnection();
        try {
            connection.setConnectTimeout(8_000);connection.setReadTimeout(15_000);
            connection.setInstanceFollowRedirects(false);connection.setUseCaches(false);
            connection.setRequestProperty("Cache-Control","no-cache");
            connection.setRequestProperty("Accept-Encoding","identity");
            connection.setRequestProperty("User-Agent","DailyReading-AndroidUpdater/1.2");
            int status=connection.getResponseCode();
            if(status!=200)throw new IOException("HTTP "+status);
            return connection;
        } catch(Exception error) { connection.disconnect();throw error; }
    }
    public static byte[] readLimited(InputStream stream,int limit) throws Exception {
        ByteArrayOutputStream output=new ByteArrayOutputStream();byte[] buffer=new byte[4096];int count;
        while((count=stream.read(buffer))!=-1) {
            if(output.size()+count>limit)throw new IllegalArgumentException("更新信息过大");
            output.write(buffer,0,count);
        }
        return output.toByteArray();
    }
    public static String describe(Exception error) {
        if(error instanceof RouteFailure)return error.getMessage();
        if(error instanceof UnknownHostException)return "无法解析域名，请切换网络后重试";
        if(error instanceof SocketTimeoutException)return "连接超时";
        if(error instanceof SSLException)return "安全连接失败，请检查系统日期和网络";
        String message=error.getMessage();
        if(message!=null && message.matches("HTTP [0-9]{3}"))return "服务器返回 "+message;
        if(error instanceof IllegalArgumentException && message!=null && message.length()<100)return message;
        if(error instanceof IOException)return "网络连接中断";
        return "返回的更新信息无效";
    }
}
