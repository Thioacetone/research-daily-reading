package com.thioacetone.reading;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.net.ssl.HttpsURLConnection;

/** User-controlled self-update. No WebView bridge and no silent installation. */
public final class AppUpdater {
    private final Activity activity;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final SharedPreferences preferences;
    private boolean checking,showing,downloading;
    private volatile boolean cancelled,closed;
    private AlertDialog downloadDialog;

    private static final class Release {
        final long code,size;final String name,url,sha,notes,packageId;final int minSdk;
        Release(JSONObject value) throws Exception {
            if(value.getInt("schemaVersion")!=1)throw new IllegalArgumentException("未知的更新格式");
            code=value.getLong("versionCode");size=value.getLong("sizeBytes");
            name=value.getString("versionName");url=value.getString("apkUrl");
            sha=value.getString("sha256");notes=value.optString("releaseNotes","");
            packageId=value.getString("packageId");minSdk=value.getInt("minSdk");
            UpdatePolicy.validate(code,url,sha,size,minSdk);
            if(name.length()>80 || notes.length()>4000)throw new IllegalArgumentException("更新说明过长");
        }
    }

    public AppUpdater(Activity activity) {
        this.activity=activity;
        preferences=activity.getSharedPreferences("app-updates",0);
    }
    private boolean active() { return !closed && !activity.isFinishing() && !activity.isDestroyed(); }
    private void toast(String text) { if(active())Toast.makeText(activity,text,Toast.LENGTH_LONG).show(); }
    private PackageInfo installed() throws Exception { return activity.getPackageManager().getPackageInfo(activity.getPackageName(),0); }
    private static long code(PackageInfo info) { return Build.VERSION.SDK_INT>=28?info.getLongVersionCode():info.versionCode; }

    public void check(boolean manual) {
        if(!active())return;
        if(checking){if(manual)toast("正在检查更新，连接失败时会自动尝试备用地址…");return;}
        if(downloading || showing)return;
        long now=System.currentTimeMillis();
        if(!manual && (now-preferences.getLong("last-success",0)<6*60*60*1000L
                || now-preferences.getLong("last-attempt",0)<5*60*1000L))return;
        checking=true;preferences.edit().putLong("last-attempt",now).apply();
        if(manual)toast("正在检查新版本…");
        worker.execute(()->{
            try {
                Release release=UpdateNetwork.firstAvailable(UpdateNetwork.manifests(),address->{
                    HttpsURLConnection connection=UpdateNetwork.open(address);
                    byte[] bytes;
                    try(InputStream stream=connection.getInputStream()) { bytes=UpdateNetwork.readLimited(stream,32_768); }
                    finally { connection.disconnect(); }
                    Release value=new Release(new JSONObject(new String(bytes,java.nio.charset.StandardCharsets.UTF_8)));
                    if(!activity.getPackageName().equals(value.packageId))throw new IllegalArgumentException("更新属于其他应用");
                    return value;
                });
                PackageInfo current=installed();
                if(!activity.getPackageName().equals(release.packageId))throw new IllegalArgumentException("更新属于其他应用");
                boolean newer=UpdatePolicy.isUpgrade(current.packageName,code(current),release.packageId,release.code);
                preferences.edit().putLong("last-success",System.currentTimeMillis()).apply();
                main.post(()->{
                    checking=false;if(!active())return;
                    if(newer && release.minSdk<=Build.VERSION.SDK_INT)showRelease(release);
                    else if(manual)toast(newer?"新版本不支持当前安卓版本":"已是最新版本（"+current.versionName+"）");
                });
            } catch(Exception error) {
                main.post(()->{checking=false;if(manual)showFailure("暂时无法检查更新",error,()->check(true));});
            }
        });
    }
    private void showRelease(Release release) {
        if(!active() || showing)return;
        showing=true;
        String message="新版本 "+release.name+"（约 "+Math.max(1,(release.size+999_999)/1_000_000)+" MB）\n\n"
            +release.notes+"\n\n在 APP 内下载，之后由安卓系统请你确认安装。";
        AlertDialog dialog=new AlertDialog.Builder(activity).setTitle("发现新版本")
            .setMessage(message).setNegativeButton("稍后",(d,w)->{})
            .setPositiveButton("下载更新",(d,w)->download(release)).create();
        dialog.setOnDismissListener(d->showing=false);dialog.show();
    }
    private void showFailure(String title,Exception error,Runnable retryAction) {
        if(!active() || showing)return;
        showing=true;
        AlertDialog dialog=new AlertDialog.Builder(activity).setTitle(title)
            .setMessage("两个官方更新地址均未能完成请求。\n\n"+UpdateNetwork.describe(error)
                +"\n\n可以重试，或在浏览器打开官方下载页。论文阅读不受影响。")
            .setNegativeButton("取消",(d,w)->{})
            .setNeutralButton("浏览器下载",(d,w)->{
                try{activity.startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(UpdateNetwork.PAGES)));}
                catch(ActivityNotFoundException unavailable){toast("未找到浏览器，请稍后重试。");}
            })
            .setPositiveButton("重试",(d,w)->main.post(()->{showing=false;retryAction.run();})).create();
        dialog.setOnDismissListener(d->showing=false);dialog.show();
    }
    private File folder() throws Exception {
        File folder=new File(activity.getCacheDir(),"app-updates");
        if(!folder.isDirectory()&&!folder.mkdirs())throw new IllegalStateException("无法保存更新");return folder;
    }
    private void download(Release release) {
        if(downloading || !active())return;
        downloading=true;cancelled=false;
        ProgressBar bar=new ProgressBar(activity,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);
        downloadDialog=new AlertDialog.Builder(activity).setTitle("正在下载 "+release.name).setView(bar)
            .setNegativeButton("取消",(d,w)->cancelled=true).create();
        downloadDialog.setOnCancelListener(d->cancelled=true);downloadDialog.show();
        worker.execute(()->{
            File part=null;
            try {
                File directory=folder();part=new File(directory,"reading-"+release.code+".download.apk");
                File apk=new File(directory,"reading-"+release.code+".apk");
                // Each download is validated again, including a previously cached APK.
                if(!apk.isFile() || !validFile(apk,release)) {
                    final File temporary=part;
                    UpdateNetwork.firstAvailable(UpdateNetwork.downloads(release.code,release.url),address->{
                    if(cancelled||closed)throw new InterruptedException();
                    main.post(()->bar.setProgress(0));
                    HttpsURLConnection connection=UpdateNetwork.open(address);
                    MessageDigest digest=MessageDigest.getInstance("SHA-256");
                    long total=0;int prior=-1;
                    try(InputStream input=connection.getInputStream();FileOutputStream output=new FileOutputStream(temporary)) {
                        byte[] buffer=new byte[32_768];int count;
                        while((count=input.read(buffer))!=-1) {
                            if(cancelled||closed)throw new InterruptedException();
                            total+=count;if(total>release.size)throw new IllegalArgumentException("更新大小不符");
                            digest.update(buffer,0,count);output.write(buffer,0,count);
                            int percent=(int)(total*100/release.size);
                            if(percent!=prior){prior=percent;main.post(()->bar.setProgress(percent));}
                        }
                        output.getFD().sync();
                    } finally { connection.disconnect(); }
                    if(total!=release.size || !UpdatePolicy.sameDigest(release.sha,hex(digest.digest())))
                        throw new IllegalArgumentException("下载校验失败，请重试");
                    if(cancelled||closed)throw new InterruptedException();
                    validateApk(temporary,release);
                    return true;
                    });
                    if(apk.exists()&&!apk.delete())throw new IllegalStateException("无法替换旧的更新文件");
                    if(!part.renameTo(apk))throw new IllegalStateException("无法保存更新文件");
                }
                if(cancelled||closed)throw new InterruptedException();
                preferences.edit().putString("pending-file",apk.getName()).putLong("pending-code",release.code)
                    .putString("pending-sha",release.sha).putLong("pending-size",release.size).putBoolean("ready-prompt",true).apply();
                main.post(()->{
                    downloading=false;if(downloadDialog!=null)downloadDialog.dismiss();
                    main.postDelayed(()->{if(active()&&activity.hasWindowFocus())offerInstall();},350);
                });
            } catch(Exception error) {
                final boolean stopped=cancelled||closed;
                main.post(()->{downloading=false;if(downloadDialog!=null)downloadDialog.dismiss();
                    if(!stopped)showFailure("更新下载或验证失败",error,()->download(release));});
            } finally { if(part!=null && part.isFile())part.delete(); }
        });
    }
    private static String hex(byte[] bytes) {
        StringBuilder out=new StringBuilder();for(byte b:bytes)out.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return out.toString();
    }
    private static String digest(File file) throws Exception {
        MessageDigest hash=MessageDigest.getInstance("SHA-256");
        try(InputStream input=new java.io.FileInputStream(file)){byte[] buffer=new byte[32_768];int count;while((count=input.read(buffer))!=-1)hash.update(buffer,0,count);}
        return hex(hash.digest());
    }
    private boolean validFile(File file,Release release) throws Exception {
        if(file.length()!=release.size || !UpdatePolicy.sameDigest(release.sha,digest(file)))return false;
        validateApk(file,release);return true;
    }
    private static Set<String> certificates(PackageInfo info) throws Exception {
        Set<String> certificates=new HashSet<>();
        Signature[] values=Build.VERSION.SDK_INT>=28 && info.signingInfo!=null
            ?info.signingInfo.getApkContentsSigners():info.signatures;
        if(values==null || values.length==0)throw new IllegalArgumentException("安装包没有签名");
        for(Signature signature:values)certificates.add(hex(MessageDigest.getInstance("SHA-256").digest(signature.toByteArray())));
        return certificates;
    }
    private void validateApk(File apk,Release release) throws Exception {
        PackageManager pm=activity.getPackageManager();
        int flags=Build.VERSION.SDK_INT>=28?PackageManager.GET_SIGNING_CERTIFICATES:PackageManager.GET_SIGNATURES;
        PackageInfo candidate=pm.getPackageArchiveInfo(apk.getAbsolutePath(),flags);
        PackageInfo current=pm.getPackageInfo(activity.getPackageName(),flags);
        if(candidate==null || code(candidate)!=release.code || !UpdatePolicy.isUpgrade(
                current.packageName,code(current),candidate.packageName,code(candidate))
                || !certificates(current).equals(certificates(candidate)))
            throw new IllegalArgumentException("应用包名、版本或签名不匹配");
    }
    private void offerInstall() {
        if(!active() || showing || !preferences.contains("pending-file"))return;
        preferences.edit().putBoolean("ready-prompt",false).apply();
        showing=true;
        AlertDialog dialog=new AlertDialog.Builder(activity).setTitle("更新已下载并验证")
            .setMessage("现在安装新版本？阅读数据和网站内容会保留。")
            .setNegativeButton("稍后",(d,w)->{})
            .setPositiveButton("立即安装",(d,w)->requestInstall()).create();
        dialog.setOnDismissListener(d->showing=false);dialog.show();
    }
    private void requestInstall() {
        if(!activity.getPackageManager().canRequestPackageInstalls()) {
            new AlertDialog.Builder(activity).setTitle("允许本 APP 安装更新")
                .setMessage(activity.getString(R.string.update_install_permission,activity.getString(R.string.app_name)))
                .setNegativeButton("取消",(d,w)->{})
                .setPositiveButton("去设置",(d,w)->{
                    preferences.edit().putBoolean("awaiting-permission",true).apply();
                    try{activity.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+activity.getPackageName())));}
                    catch(ActivityNotFoundException error){preferences.edit().remove("awaiting-permission").apply();toast("系统未提供安装授权页面。");}
                }).show();
        } else install();
    }
    private void install() {
        if(!preferences.contains("pending-file"))return;
        // File reads and signature checks remain off the UI thread.
        worker.execute(()->{
            try {
                String filename=preferences.getString("pending-file","");
                if(!filename.matches("reading-[0-9]+\\.apk"))throw new IllegalArgumentException();
                File apk=new File(folder(),filename);
                long expectedCode=preferences.getLong("pending-code",0);
                if(apk.length()!=preferences.getLong("pending-size",0) || !UpdatePolicy.sameDigest(
                    preferences.getString("pending-sha",""),digest(apk)))throw new IllegalArgumentException();
                PackageInfo candidate=activity.getPackageManager().getPackageArchiveInfo(apk.getAbsolutePath(),0);
                if(candidate==null || code(candidate)!=expectedCode)throw new IllegalArgumentException();
                JSONObject json=new JSONObject().put("schemaVersion",1).put("versionCode",expectedCode)
                    .put("versionName",candidate.versionName).put("packageId",activity.getPackageName())
                    .put("apkUrl","https://raw.githubusercontent.com/Thioacetone/research-daily-reading/main/android/releases/"+expectedCode+"/daily-reading.apk")
                    .put("sha256",preferences.getString("pending-sha","")).put("sizeBytes",apk.length()).put("minSdk",26);
                validateApk(apk,new Release(json));
                Uri uri=FileProvider.getUriForFile(activity,activity.getPackageName()+".updates",apk);
                main.post(()->{if(active()){
                    try{activity.startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.android.package-archive")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));}
                    catch(ActivityNotFoundException error){toast("未找到系统安装程序。");}
                }});
            } catch(Exception error){main.post(()->toast("更新验证未通过，请重新下载。"));}
        });
    }
    public void resume() {
        if(!active())return;
        if(preferences.getBoolean("awaiting-permission",false)) {
            preferences.edit().remove("awaiting-permission").apply();
            if(activity.getPackageManager().canRequestPackageInstalls())install();
            else toast("尚未允许安装更新，可以稍后重试。");
        } else if(preferences.getBoolean("ready-prompt",false)) {
            main.postDelayed(this::offerInstall,500);
        } else check(false);
    }
    public void close() { closed=true;cancelled=true;main.removeCallbacksAndMessages(null);worker.shutdownNow(); }
}
