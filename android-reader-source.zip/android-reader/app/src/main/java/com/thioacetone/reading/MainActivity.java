package com.thioacetone.reading;

import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import java.time.ZoneId;
import java.time.ZonedDateTime;

/** Online reader: the published website remains the single source of content. */
public final class MainActivity extends ComponentActivity {
    private static final String HOST = "thioacetone-reading.streamlit.app";
    private static final String HOME = "https://" + HOST + "/?view=today";
    private static final ZoneId BEIJING = ZoneId.of("Asia/Shanghai");
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WebView web;
    private ProgressBar progress;
    private LinearLayout cover;
    private TextView message;
    private Button retry;
    private boolean mainFrameFailed;
    private String displayedDay;
    // Hide framework chrome only; paper buttons and selection controls stay intact.
    private static final String CLEAN_CHROME = "(()=>{const css='header[data-testid=stHeader],"
        +"[data-testid=stToolbar],[data-testid=stStatusWidget],[data-testid=stDecoration],"
        +"[data-testid=stMainMenu],#MainMenu,.stDeployButton,[data-testid=stAppDeployButton],"
        +"[data-testid=manage-app-button],footer:not(.reader-publication){display:none!important}';"
        +"let s=document.getElementById('android-reader-chrome');if(!s){s=document.createElement('style');"
        +"s.id='android-reader-chrome';(document.head||document.documentElement).appendChild(s);}s.textContent=css;})()";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        displayedDay = beijingDay();
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(247,248,252));
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            } else {
                v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(247,248,252));
        root.addView(web,new FrameLayout.LayoutParams(-1,-1));
        WebSettings settings=web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        CookieManager.getInstance().setAcceptCookie(true);
        // Streamlit's public-app session bootstrap can redirect through its own host.
        CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri=request.getUrl();
                if (internal(uri)) return false;
                if (request.hasGesture() && "https".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); }
                    catch (ActivityNotFoundException ignored) { }
                }
                return true;
            }
            @Override public void onPageStarted(WebView view,String url,android.graphics.Bitmap icon) {
                mainFrameFailed=false;progress.setVisibility(View.VISIBLE);
            }
            @Override public void onPageCommitVisible(WebView view,String url) { cleanChrome(); }
            @Override public void onPageFinished(WebView view,String url) {
                cleanChrome();progress.setVisibility(View.GONE);
                if (!mainFrameFailed) cover.setVisibility(View.GONE);
            }
            @Override public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError error) {
                if (request.isForMainFrame()) {
                    mainFrameFailed=true;message.setText("暂时无法连接论文库，请检查网络后重试。");
                    retry.setVisibility(View.VISIBLE);cover.setVisibility(View.VISIBLE);
                    progress.setVisibility(View.GONE);
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view,int value) { progress.setProgress(value); }
        });
        cover=new LinearLayout(this);cover.setGravity(Gravity.CENTER);cover.setOrientation(LinearLayout.VERTICAL);
        cover.setPadding(dp(32),dp(32),dp(32),dp(32));cover.setBackgroundColor(Color.rgb(247,248,252));
        ImageView artwork=new ImageView(this);artwork.setImageResource(com.thioacetone.reading.R.drawable.app_art);
        artwork.setScaleType(ImageView.ScaleType.FIT_CENTER);cover.addView(artwork,new LinearLayout.LayoutParams(dp(220),dp(220)));
        message=new TextView(this);message.setText("每日论文精读 · 正在打开论文库");message.setTextSize(16);
        message.setTextColor(Color.rgb(64,71,90));message.setGravity(Gravity.CENTER);cover.addView(message);
        retry=new Button(this);retry.setText("重新连接");retry.setVisibility(View.GONE);
        retry.setOnClickListener(v->{message.setText("正在重新连接…");retry.setVisibility(View.GONE);web.loadUrl(HOME);});
        cover.addView(retry);root.addView(cover,new FrameLayout.LayoutParams(-1,-1));
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        FrameLayout.LayoutParams bar=new FrameLayout.LayoutParams(-1,dp(3),Gravity.TOP);root.addView(progress,bar);
        setContentView(root);
        getOnBackPressedDispatcher().addCallback(this,new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() { back(); }
        });
        if (state==null || web.restoreState(state)==null) web.loadUrl(HOME);
        scheduleMidnight();
    }
    private int dp(int n) { return Math.round(n*getResources().getDisplayMetrics().density); }
    private static boolean internal(Uri uri) {
        return "https".equals(uri.getScheme()) && (HOST.equals(uri.getHost()) ||
            ("share.streamlit.io".equals(uri.getHost()) && uri.getPath()!=null && uri.getPath().startsWith("/-/auth/")));
    }
    private void cleanChrome() {
        if (web.getUrl()!=null && HOST.equals(Uri.parse(web.getUrl()).getHost())) web.evaluateJavascript(CLEAN_CHROME,null);
    }
    private static String beijingDay() { return ZonedDateTime.now(BEIJING).toLocalDate().toString(); }
    private void refreshDayIfNeeded() {
        String current=beijingDay();
        if (!current.equals(displayedDay)) {
            displayedDay=current;
            // Community Cloud wraps the app in a same-origin frame. Inspect its
            // actual route, so midnight cannot interrupt a paper inside that frame.
            web.evaluateJavascript("(()=>{let w=window;try{const f=document.querySelector('iframe[title=streamlitApp]');"
                +"if(f&&f.contentWindow.location.host===location.host)w=f.contentWindow;}catch(e){}"
                +"const q=new URLSearchParams(w.location.search);if(!q.has('paper')&&q.get('view')!=='archive')"
                +"w.location.reload();})()",null);
        }
    }
    private void scheduleMidnight() {
        ZonedDateTime now=ZonedDateTime.now(BEIJING);
        long delay=java.time.Duration.between(now,now.toLocalDate().plusDays(1).atStartOfDay(BEIJING)).toMillis()+100;
        handler.postDelayed(()->{refreshDayIfNeeded();scheduleMidnight();},delay);
    }
    @Override protected void onResume() { super.onResume();if(web!=null){web.onResume();refreshDayIfNeeded();} }
    @Override protected void onPause() { if(web!=null)web.onPause();super.onPause(); }
    @Override protected void onSaveInstanceState(Bundle state) { web.saveState(state);super.onSaveInstanceState(state); }
    private void back() {
        web.evaluateJavascript("(()=>{let w=window;try{const f=document.querySelector('iframe[title=streamlitApp]');"
            +"if(f&&f.contentWindow.location.host===location.host)w=f.contentWindow;}catch(e){}"
            +"const u=new URL(w.location.href);if(u.searchParams.has('paper')){u.searchParams.delete('paper');"
            +"w.location.href=u.href;return true;}if(u.searchParams.get('view')==='archive'){u.search='?view=today';"
            +"w.location.href=u.href;return true;}return false;})()",handled->{if(!"true".equals(handled))finish();});
    }
    @Override protected void onDestroy() { handler.removeCallbacksAndMessages(null);web.destroy();super.onDestroy(); }
}
