package com.thioacetone.reading;
import org.junit.Test;
import static org.junit.Assert.*;

public class UpdatePolicyTest {
    private final String hash="abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789";
    private final String url="https://raw.githubusercontent.com/Thioacetone/research-daily-reading/main/android/releases/42/daily-reading.apk";
    @Test public void validImmutableDownload() { UpdatePolicy.validate(42,url,hash,2430156,26); }
    @Test public void rejectOtherOriginsAndMutableOrMismatchedPaths() {
        String[] bad={url.replace("https:","http:"),url.replace("raw.githubusercontent.com","raw.githubusercontent.com.evil.example"),
            url.replace("/42/","/41/"),url.replace("daily-reading.apk","../daily-reading.apk"),
            url+"?redirect=anything",url+"#anything",url.replace(".com/",".com:443/"),
            url.replace("raw.githubusercontent.com","user@raw.githubusercontent.com")};
        for(String value:bad)assertThrows(IllegalArgumentException.class,()->UpdatePolicy.validate(42,value,hash,2000,26));
    }
    @Test public void rejectInvalidSizeDigestAndVersions() {
        assertThrows(IllegalArgumentException.class,()->UpdatePolicy.validate(42,url,hash,40_000_001,26));
        assertThrows(IllegalArgumentException.class,()->UpdatePolicy.validate(42,url,"bad",2000,26));
        assertThrows(IllegalArgumentException.class,()->UpdatePolicy.validate(0,url,hash,2000,26));
    }
    @Test public void requireSamePackageAndIncreasingVersion() {
        assertTrue(UpdatePolicy.isUpgrade("reader",2,"reader",3));
        assertFalse(UpdatePolicy.isUpgrade("reader",2,"reader",2));
        assertFalse(UpdatePolicy.isUpgrade("reader",2,"reader",1));
        assertFalse(UpdatePolicy.isUpgrade("reader",2,"imposter",3));
    }
    @Test public void validateDigest() { assertTrue(UpdatePolicy.sameDigest(hash,hash.toUpperCase()));assertFalse(UpdatePolicy.sameDigest(hash,"bad")); }
}
