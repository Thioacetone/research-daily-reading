package com.thioacetone.reading;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.Test;
import static org.junit.Assert.*;

public class UpdateNetworkTest {
    @Test public void fallsBackWhenFirstHostnameIsUnavailable() throws Exception {
        AtomicInteger calls=new AtomicInteger();
        String result=UpdateNetwork.firstAvailable(UpdateNetwork.manifests(),url->{
            if(calls.incrementAndGet()==1)throw new UnknownHostException();return "valid release";
        });
        assertEquals("valid release",result);assertEquals(2,calls.get());
    }
    @Test public void invalidPrimaryResponseAlsoTriesTheSecondRoute() throws Exception {
        AtomicInteger calls=new AtomicInteger();
        assertEquals("valid",UpdateNetwork.firstAvailable(UpdateNetwork.manifests(),url->{
            if(calls.incrementAndGet()==1)throw new IllegalArgumentException("更新信息过大");return "valid";
        }));
        assertEquals(2,calls.get());
    }
    @Test public void reportsBothFailedRoutesWithoutHidingTheReason() {
        Exception failure=assertThrows(UpdateNetwork.RouteFailure.class,()->
            UpdateNetwork.firstAvailable(UpdateNetwork.manifests(),url->{throw new IOException("HTTP 403");}));
        assertTrue(failure.getMessage().contains("thioacetone.github.io"));
        assertTrue(failure.getMessage().contains("raw.githubusercontent.com"));
        assertTrue(failure.getMessage().contains("HTTP 403"));
    }
    @Test public void stopRequestsDoNotProceedToTheBackupRoute() {
        AtomicInteger calls=new AtomicInteger();
        try {
            assertThrows(InterruptedException.class,()->UpdateNetwork.firstAvailable(UpdateNetwork.manifests(),url->{
                calls.incrementAndGet();throw new InterruptedException();
            }));
            assertEquals(1,calls.get());
        } finally { Thread.interrupted(); }
    }
    @Test public void boundedManifestAndRepositoryScopedDownloadRoutes() throws Exception {
        assertEquals(3,UpdateNetwork.readLimited(new ByteArrayInputStream(new byte[3]),3).length);
        assertThrows(IllegalArgumentException.class,()->UpdateNetwork.readLimited(new ByteArrayInputStream(new byte[4]),3));
        String canonical=UpdateNetwork.RAW+"android/releases/42/daily-reading.apk";
        assertEquals(UpdateNetwork.PAGES+"android/releases/42/daily-reading.apk",UpdateNetwork.downloads(42,canonical)[0]);
        assertThrows(IllegalArgumentException.class,()->UpdateNetwork.downloads(43,canonical));
        for(String bad:new String[]{"http://thioacetone.github.io/research-daily-reading/android-update.json",
                UpdateNetwork.PAGES+"../secret",UpdateNetwork.PAGES+"android-update.json?redirect=evil",
                UpdateNetwork.PAGES.replace(".io/",".io.evil/")+"android-update.json",
                UpdateNetwork.PAGES+"android/releases/42/../daily-reading.apk"})
            assertThrows(IllegalArgumentException.class,()->UpdateNetwork.requireEndpoint(bad));
    }
}
