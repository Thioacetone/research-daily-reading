# 每日论文精读 · 安卓版

Android 8.0 及以上手机、平板。与现有 Streamlit 网站共用内容和页面，隐藏框架工具栏、菜单及部署入口，保留论文目录、筛选、独立阅读、作者单位、DOI、随机配图和自动配色。需要联网，未加入离线论文功能。

北京时间凌晨 00:00 切换今日目录；文章在云端提前生成。正在阅读的单篇不会被午夜强制打断，返回目录时读取新日期。后台暂停或手机休眠时不承诺执行定时器，重新打开会检查日期。

网站的论文和样式更新不需要重装 APK。APP 外壳自身修改仍需安装新版本；本版不自动下载安装包、不索取安装权限。

在已安装 Java 17、Android SDK 36 的环境，使用 Gradle 8.13 执行：

    gradle assembleDebug lintDebug

GitHub Actions 的 Build Android reading app 工作流生成可安装的测试签名 APK，产物 daily-reading-android。此测试签名不用于应用商店正式发行。
