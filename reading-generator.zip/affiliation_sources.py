"""Recover exact author affiliations from public, DOI-linked primary sources."""
from datetime import datetime,timezone,timedelta
import hashlib,io,json,logging,re,urllib.parse,urllib.request,threading,time
from pathlib import Path
import unicodedata
from xml.etree import ElementTree as ET

from author_roles import name_key,display_unit_names,unit_has_detail,affiliation_country,jats_roles

LOG=logging.getLogger('digest')
POLICY='author-units-and-country-v2'
REVIEWED_PATH=Path(__file__).with_name('reviewed_affiliations.json')
_PUBLIC_LOCK=threading.Lock()
_PUBLIC_NEXT={}

def read_public(url,body=None,limit=5_000_000):
    parsed=urllib.parse.urlsplit(url)
    if parsed.scheme!='https' or parsed.hostname not in ('api.figshare.com','ndownloader.figshare.com','www.ebi.ac.uk','eutils.ncbi.nlm.nih.gov'):
        raise ValueError('Untrusted affiliation source')
    request=urllib.request.Request(url,data=json.dumps(body).encode() if body else None,
        headers={'Content-Type':'application/json','User-Agent':'ResearchDigest/1.0 (public author metadata)'})
    # Respect public-service limits even when source repair uses worker threads.
    interval=0.4 if parsed.hostname=='eutils.ncbi.nlm.nih.gov' else 1.05 if parsed.hostname=='api.figshare.com' else 0
    if interval:
        with _PUBLIC_LOCK:
            pause=max(0,_PUBLIC_NEXT.get(parsed.hostname,0)-time.monotonic())
            if pause:time.sleep(pause)
            _PUBLIC_NEXT[parsed.hostname]=time.monotonic()+interval
    with urllib.request.urlopen(request,timeout=20) as response:data=response.read(limit+1)
    if len(data)>limit:raise ValueError('Affiliation source size limit')
    return data

def affiliation_text_pairs(text,authors):
    """Only link printed author markers to printed affiliation markers.

    No matches are inferred from the subject or the other author's institution.
    Text after the title-page affiliation block is not considered.
    """
    text=unicodedata.normalize('NFC',text).translate(str.maketrans('¹²³⁴⁵⁶⁷⁸⁹⁰','1234567890'))
    text=text.split('===PAGE===')[0]
    lines=text.splitlines()
    institution=re.compile(r'\b(?:School|College|Faculty|Department|Division|Institute|Institut|Laboratory|Center|Centre|University|IISER|RIKEN|State Key|Key Laboratory|Materials Sciences)\b',re.I)
    marker=re.compile(r'^\s*(\d{1,2}|[a-z]|[†‡¶§‖⊥#])\s*[.)]?\s*(.*)$')
    blocks={};start=None;current=None;ignored=set()
    stop=re.compile(r'^(?:E[- ]?mail|\*?Correspond|Contents|C\s+o\s+n\s+t|Materials and Methods|Experimental|Quantum Dot|S\. No\.|§These|These authors|The Supporting Information)',re.I)
    for index,line in enumerate(lines):
        stripped=line.strip()
        if start is not None and re.match(r'^(?:Contents|C\s+o\s+n\s+t|S\. No\.|The Supporting Information|Quantum Dot)',stripped,re.I):break
        match=marker.match(line)
        if match and re.search(r'contributed equally|equal contribution',match[2],re.I):
            ignored.add(match[1]);current=None;continue
        if match and (institution.search(match[2]) or any(name_key(n) in name_key(match[2]) for n in authors)):
            key=match[1];current=key;blocks[key]=[match[2]]
            if start is None:start=index
            continue
        if start is not None and match and match[2].strip():
            current=None
            continue
        if current is not None:
            if stop.search(stripped) or stripped in ('ç','S-1','S1'):
                current=None
                continue
            if stripped:blocks[current].append(stripped)
    if start is None:return []
    header=' '.join(lines[:start])
    units={}
    for key,parts in blocks.items():
        # Some SI files list the names under each marker, then the address.
        parts=[p for p in parts if not any(name_key(n) in name_key(p) for n in authors)]
        value=' '.join(' '.join(parts).split())
        value=re.split(r'\bE[- ]?mail\s*:',value,flags=re.I)[0].strip()
        if institution.search(value):units[key]=value
    result=[]
    reference=r'(?:\d{1,2}|[a-z](?![A-Za-z])|[†‡¶§‖⊥#*∗])'
    for name in authors:
        pattern=re.escape(unicodedata.normalize('NFC',name)).replace(r'\ ',r'\s*').replace(r'\.',r'\.?')
        match=re.search('(?i:'+pattern+')'+r'\s*[,，]?\s*('+reference+r'(?:[\s,]*'+reference+r')*)',header)
        if not match:continue
        refs=[ref for ref in re.findall(r'\d{1,2}|[a-z]|[†‡¶§‖⊥#]',match[1]) if ref not in ignored]
        # A partial marker match cannot silently discard another affiliation.
        if not refs or any(ref not in units for ref in refs):continue
        selected=list(dict.fromkeys(units[ref] for ref in refs))
        if selected:result.append({'name':name,'institutions':selected})
    return result

def apply_verified(item,entry):
    known={name_key(n):n for n in item.get('people',[])}
    pairs={name_key(p['name']):p for p in item.get('author_affiliations',[])}
    changed=False
    explicit=[known[name_key(n)] for n in entry.get('corresponding_authors',[]) if name_key(n) in known]
    if explicit:item['corresponding_authors']=explicit
    first=[known[name_key(n)] for n in entry.get('first_authors',[]) if name_key(n) in known]
    if first:item['first_authors']=first
    for pair in entry.get('author_affiliations',[]):
        key=name_key(pair.get('name',''))
        if key in known and pair.get('institutions'):
            pairs[key]={'name':known[key],'institutions':pair['institutions']};changed=True
    if changed:
        item['author_affiliations']=list(pairs.values())
        item.setdefault('institutions_zh',{}).update(entry.get('institutions_zh',{}))
        item['affiliation_sources']=list(dict.fromkeys(item.get('affiliation_sources',[])+entry.get('sources',[])))
    return changed


def recover_into(item,entry,pairs,sources,correspondents=None):
    """Cache all recovered authors when different sources supply different people."""
    combined={name_key(p['name']):p for p in entry.get('author_affiliations',[])}
    combined.update({name_key(p['name']):p for p in pairs})
    entry['author_affiliations']=list(combined.values())
    entry['sources']=list(dict.fromkeys(entry.get('sources',[])+sources))
    if correspondents:entry['corresponding_authors']=correspondents
    apply_verified(item,entry)


def text_correspondents(text,authors):
    first_page=text.split('===PAGE===')[0]
    start=re.search(r'\bCorrespondence\s*:',first_page,re.I)
    if not start:return []
    block=re.split(r'The Supporting Information|Contents|Materials and Methods',first_page[start.end():],flags=re.I)[0]
    result=[]
    for name in authors:
        pattern=re.escape(name).replace(r'\ ',r'\s*').replace(r'\.',r'\.?')
        if re.search(r'(?<![A-Za-z])'+pattern+r'(?![A-Za-z])',block,re.I):result.append(name)
    return result

def units_complete(item):
    names=(item.get('first_authors') or item.get('people',[])[:1])+(item.get('corresponding_authors') or item.get('people',[])[-1:])
    pairs={name_key(p['name']):p.get('institutions',[]) for p in item.get('author_affiliations',[])}
    if not names or any(not pairs.get(name_key(n)) for n in names):return False
    units=display_unit_names(item)
    return bool(units and all(unit_has_detail(u) and affiliation_country(u) for u in units))


def pubmed_pairs(raw,doi,authors):
    """PubMed's publication-time per-author addresses, with exact DOI identity."""
    if b'<!ENTITY' in raw.upper():raise ValueError('Unsafe author XML')
    root=ET.fromstring(raw)
    known={name_key(n):n for n in authors}
    pairs=[]
    for article in root.findall('PubmedArticle'):
        identifiers=article.findall('./PubmedData/ArticleIdList/ArticleId')
        if not any(n.get('IdType')=='doi' and (n.text or '').strip().lower()==doi.lower() for n in identifiers):continue
        for person in article.findall('./MedlineCitation/Article/AuthorList/Author'):
            name=' '.join(filter(None,[person.findtext('ForeName'),person.findtext('LastName')]))
            actual=known.get(name_key(name))
            units=[' '.join(' '.join(n.itertext()).split()) for n in person.findall('./AffiliationInfo/Affiliation')]
            if actual and units:pairs.append({'name':actual,'institutions':units})
    return pairs

def supplement_affiliations(item,root):
    doi=item.get('doi','').lower()
    item['affiliation_policy']=POLICY
    try:
        reviewed=json.loads(REVIEWED_PATH.read_text(encoding='utf-8')).get(doi)
        if reviewed:apply_verified(item,reviewed)
    except (OSError,ValueError,TypeError):pass
    if units_complete(item):return
    directory=Path(root)/'data/affiliations';directory.mkdir(parents=True,exist_ok=True)
    path=directory/(hashlib.sha256((POLICY+doi).encode()).hexdigest()+'.json')
    if path.exists():
        try:
            cached=json.loads(path.read_text(encoding='utf-8'))
            lifetime=timedelta(days=7) if cached.get('complete') else timedelta(hours=6)
            if cached.get('doi')==doi and datetime.now(timezone.utc)-datetime.fromisoformat(cached['checked_at'])<lifetime:
                apply_verified(item,cached);return
        except (OSError,ValueError,TypeError,KeyError):pass
    entry={'doi':doi,'author_affiliations':[],'sources':[],'checked_at':datetime.now(timezone.utc).isoformat()}
    authors=item.get('people',[])
    # Europe PMC's full metadata retains per-author, publication-time addresses.
    try:
        url='https://www.ebi.ac.uk/europepmc/webservices/rest/search?'+urllib.parse.urlencode({'query':'DOI:'+doi,'format':'json','resultType':'core','pageSize':5})
        rows=json.loads(read_public(url)).get('resultList',{}).get('result',[])
        if not rows and item.get('paper_title'):
            url='https://www.ebi.ac.uk/europepmc/webservices/rest/search?'+urllib.parse.urlencode({'query':'TITLE:"'+item['paper_title'].replace('"','')+'"','format':'json','resultType':'core','pageSize':5})
            rows=json.loads(read_public(url)).get('resultList',{}).get('result',[])
        for row in rows:
            if row.get('doi','').lower()!=doi:continue
            pairs=[]
            for author in row.get('authorList',{}).get('author',[]):
                name=' '.join(filter(None,(author.get('firstName'),author.get('lastName'))))
                actual=next((n for n in authors if name_key(n)==name_key(name)),None)
                units=[a['affiliation'] for a in author.get('authorAffiliationDetailsList',{}).get('authorAffiliation',[]) if a.get('affiliation')]
                if actual and units:pairs.append({'name':actual,'institutions':units})
            if pairs:
                recover_into(item,entry,pairs,[url])
            pmcid=row.get('pmcid','')
            if not units_complete(item) and re.fullmatch(r'PMC\d+',pmcid):
                full_url='https://www.ebi.ac.uk/europepmc/webservices/rest/'+pmcid+'/fullTextXML'
                try:
                    raw=read_public(full_url)
                    if b'<!ENTITY' in raw.upper():raise ValueError('Unsafe author XML')
                    tree=ET.fromstring(raw)
                    if any(n.get('pub-id-type')=='doi' and (n.text or '').strip().lower()==doi for n in tree.findall('./front/article-meta/article-id')):
                        roles=jats_roles(raw)
                        recover_into(item,entry,roles['author_affiliations'],[full_url],roles['corresponding_authors'])
                except (OSError,ValueError,ET.ParseError):pass
    except (OSError,ValueError,TypeError,KeyError):LOG.info('部分 DOI 署名元数据不可读，继续核对出版社补充材料。')
    if not units_complete(item):
        try:
            search='https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?'+urllib.parse.urlencode({'db':'pubmed','term':doi+'[doi]','retmode':'json','retmax':5})
            ids=json.loads(read_public(search)).get('esearchresult',{}).get('idlist',[])
            ids=[str(i) for i in ids if re.fullmatch(r'\d+',str(i))]
            if ids:
                source='https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?'+urllib.parse.urlencode({'db':'pubmed','id':','.join(ids),'retmode':'xml'})
                pairs=pubmed_pairs(read_public(source),doi,authors)
                if pairs:recover_into(item,entry,pairs,[source])
        except (OSError,ValueError,TypeError,KeyError,ET.ParseError):LOG.info('PubMed 原始署名暂不可读，继续核对出版社补充材料。')
    if not units_complete(item) and doi.startswith('10.1021/'):
        try:
            from pypdf import PdfReader
            rows=json.loads(read_public('https://api.figshare.com/v2/articles/search',{'resource_doi':doi,'page_size':20}))
            if not rows and item.get('paper_title'):
                rows=json.loads(read_public('https://api.figshare.com/v2/articles/search',{'search_for':item['paper_title'],'page_size':20}))
            files=[]
            for row in rows[:20]:
                if (str(row.get('resource_doi','')).lower()!=doi
                        and name_key(row.get('title',''))!=name_key(item.get('paper_title',''))):continue
                article=json.loads(read_public('https://api.figshare.com/v2/articles/'+str(row['id'])))
                if article.get('resource_doi','').lower()!=doi or not article.get('url_public_html','').startswith('https://acs.figshare.com/'):
                    continue
                for f in article.get('files',[]):
                    if f['name'].lower().endswith('.pdf') and f.get('size',0)<=30_000_000:
                        files.append((f,article['url_public_html']))
            for file,url in sorted(files,key=lambda pair:pair[0]['name'])[:2]:
                raw=read_public(file['download_url'],limit=30_000_000)
                if not raw.startswith(b'%PDF'):continue
                reader=PdfReader(io.BytesIO(raw),strict=False)
                page=reader.pages[0].extract_text() or ''
                pairs=affiliation_text_pairs(page,authors)
                if pairs:
                    recover_into(item,entry,pairs,[url],text_correspondents(page,authors))
                    if units_complete(item):break
        except (OSError,ValueError,TypeError,KeyError,ImportError):LOG.info('未取得完整出版社署名；院系保留待原文核实，不从研究方向推测。')
    entry['complete']=units_complete(item)
    path.write_text(json.dumps(entry,ensure_ascii=False),encoding='utf-8')
