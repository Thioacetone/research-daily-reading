"""Cloud-only daily website build; no email credentials or inference API calls."""
import argparse
from datetime import date, datetime, timedelta, timezone
import hashlib
import json
import logging
import os
from pathlib import Path
import urllib.parse
from xml.etree import ElementTree as ET

from reading_policy import (DIRECTIONS,PRIORITY,QUERIES,POLICY_VERSION,PolicyError,
                           choose_daily,validate_daily,identity_keys,direction)
from cloud_bundle import ensure_bundled_files
from reading_library import load_library

ROOT=Path(__file__).resolve().parent
BJ=timezone(timedelta(hours=8))
LOG=logging.getLogger('website-reading')


def history(root):
    ensure_bundled_files(root)
    reports,failed=load_library(root)
    if failed:raise PolicyError('Some historical reports cannot be read; refusing to guess duplicate history')
    path=Path(root)/'reading-history.json'
    saved=json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
    if not isinstance(saved,dict):raise PolicyError('Website reading history is invalid')
    for entry in reports:
        for section in entry['report']['sections'].values():
            for item in section['items']:
                for key in identity_keys(item):saved[key]=min(saved.get(key,entry['day']),entry['day'])
    for key,day in saved.items():
        if not key.startswith(('doi:','title:')):raise PolicyError('Unknown identity in website history')
        date.fromisoformat(day)
    return reports,saved


def quality(item):
    from paper_recommendation import complete_item
    from bilingual_mail import complete,VERSION,LAYOUT_VERSION
    return complete_item(item) and complete({'edition':'paper-recommendation','bilingual_version':VERSION,
                    'bilingual_layout':LAYOUT_VERSION,'sections':{'papers':{'items':[item]}}})


def already_published(root,day):
    reports,saved=history(root)
    used={key for key,first in saved.items() if first!=day}
    for entry in reports:
        if entry['day']!=day or entry['report'].get('reading_policy_version')!=POLICY_VERSION:continue
        items=[i for s in entry['report']['sections'].values() for i in s['items']]
        try:validate_daily(items,used,quality)
        except PolicyError:continue
        return True
    return False


def discover(root,lane,used,day):
    """Search broad themes in independent indexes; only vetted journals enter the pool."""
    from recommendation_sources import read_json,interleave,is_preprint,BAD_TITLE,EPMC,discover_pubmed
    from journal_discovery import JournalRegistry
    from crossref_metadata import normalize_doi
    registry=JournalRegistry.load(root)
    lanes=[]
    query=QUERIES[lane]
    for sort in ('sort_cited:y','sort_date:y'):
        found=[];cursor='*'
        for _ in range(3):
            args={'query':f'({query}) AND OPEN_ACCESS:Y AND HAS_FT:Y AND FIRST_PDATE:[1900-01-01 TO {day}] {sort}',
                  'format':'json','resultType':'core','pageSize':50,'cursorMark':cursor}
            try:result=read_json(EPMC+'search?'+urllib.parse.urlencode(args))
            except (OSError,ValueError):break
            rows=result.get('resultList',{}).get('result',[])
            for row in rows:
                doi=normalize_doi(row.get('doi'));title=row.get('title','')
                journal=row.get('journalInfo',{}).get('journal',{}).get('title','') or row.get('journalTitle','')
                item={'doi':doi,'title':title}
                if (not doi or identity_keys(item)&used or is_preprint(doi) or BAD_TITLE.search(title)
                        or row.get('isRetracted')=='Y' or not registry.match(journal)):
                    continue
                found.append({**item,'pmcid':row.get('pmcid',''),'candidate_journal':journal,
                              'discovery_sources':['Europe PMC'],'research_direction':lane})
            nxt=result.get('nextCursorMark')
            if len(found)>=12 or not rows or not nxt or nxt==cursor:break
            cursor=nxt
        lanes.append(found)
    for sort in ('is-referenced-by-count','relevance'):
        found=[]
        for offset in (0,60,120):
            args={'query.bibliographic':query.replace(' OR ',' ').replace(' AND ',' '),
                  'filter':f'type:journal-article,until-pub-date:{day}','rows':60,'offset':offset,
                  'sort':sort,'order':'desc'}
            try:rows=read_json('https://api.crossref.org/works?'+urllib.parse.urlencode(args))['message']['items']
            except (OSError,ValueError,KeyError):break
            for row in rows:
                doi=normalize_doi(row.get('DOI'));title=' '.join(row.get('title') or [])
                journals=row.get('container-title') or []
                item={'doi':doi,'title':title}
                if (not doi or identity_keys(item)&used or is_preprint(doi) or BAD_TITLE.search(title)
                        or not any(registry.match(j,row.get('ISSN',[])) for j in journals)
                        or any(u.get('type') in ('retraction','withdrawal','expression-of-concern') for u in row.get('update-to',[]))
                        or any(row.get('relation',{}).get(k) for k in ('is-retracted-by','is-preprint-of'))):continue
                found.append({**item,'pmcid':'','candidate_journal':journals[0],
                              'discovery_sources':['Crossref'],'research_direction':lane})
            if len(found)>=12 or len(rows)<60:break
        lanes.append(found)
    used_dois={key[4:] for key in used if key.startswith('doi:')}
    for kind in ('research','review'):
        lanes.append(discover_pubmed(kind,used_dois,date.fromisoformat(day),themes=((lane,query),),registry=registry))
    return interleave(lanes)


def prepare_item(root,item,day,writer=None):
    import bilingual_mail
    report={'date':(date.fromisoformat(day)-timedelta(days=1)).isoformat(),
            'recommendation_date':day,'edition':'paper-recommendation',
            'sections':{'papers':{'status':'ok','items':[item],'note':'','sources':[]}}}
    translator=bilingual_mail.LocalTranslator(root)
    if writer is not None:translator.writer=writer
    bilingual_mail.prepare(report,root,translator=translator)
    if not quality(item):raise PolicyError('Full text, affiliations or paragraph translations are incomplete')
    return item


def worker(root,lane,day,output):
    from paper_recommendation import load_catalog,load_candidate_fulltext,complete_item,RecommendationError
    from recommendation_writer import DeepReadingWriter
    from journal_discovery import JournalRegistry
    reports,saved=history(root);used=set(saved)
    registry=JournalRegistry.load(root)
    result=[];writer=DeepReadingWriter(root)
    diagnostics={'discovered':0,'fulltext_failed':0,'journal_rejected':0,
                 'editorial_rejected':0,'bilingual_failed':0,'qualified':0}
    target=2 if lane in PRIORITY else 1
    curated=[i for i in load_catalog(root) if direction(i)==lane and not identity_keys(i)&used]
    for item in curated:
        if not registry.match(item.get('venue','')):continue
        try:item=prepare_item(root,json.loads(json.dumps(item)),day,writer)
        except (OSError,ValueError):
            diagnostics['bilingual_failed']+=1
            continue
        result.append(item);used.update(identity_keys(item))
        if len(result)>=target:break
    if len(result)<target:
        candidates=discover(root,lane,used,day)
        diagnostics['discovered']=len(candidates)
        for candidate in candidates[:12]:
            if identity_keys(candidate)&used:continue
            stage='fulltext_failed'
            try:
                paper,paragraphs,abstract=load_candidate_fulltext(root,candidate)
                if not registry.match(paper.get('venue','')):
                    diagnostics['journal_rejected']+=1
                    continue
                stage='editorial_rejected'
                item=writer.analyze(paper,paragraphs,abstract)
                # Keep valid interdisciplinary discoveries. The final selector
                # applies quotas to the full-text judgement, never this search lane.
                if not item or not complete_item(item) or direction(item) not in DIRECTIONS:
                    diagnostics['editorial_rejected']+=1
                    continue
                stage='bilingual_failed'
                item=prepare_item(root,item,day,writer)
            except (OSError,ValueError,ET.ParseError,RecommendationError):
                diagnostics[stage]+=1
                LOG.warning('Candidate did not pass full-text or bilingual checks: %s',candidate['doi'])
                continue
            result.append(item);used.update(identity_keys(item))
            if len(result)>=target:break
    diagnostics['qualified']=len(result)
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps({'day':day,'lane':lane,'items':result,'diagnostics':diagnostics},ensure_ascii=False),encoding='utf-8')
    if os.environ.get('GITHUB_STEP_SUMMARY'):
        summary=[f'### {lane}',f'- Date: {day}',
                 *[f'- {key}: {value}' for key,value in diagnostics.items()],
                 *[f"- Qualified: `{item['doi']}` ({direction(item)})" for item in result]]
        with open(os.environ['GITHUB_STEP_SUMMARY'],'a',encoding='utf-8') as stream:
            stream.write('\n'.join(summary)+'\n')
    print(json.dumps({'lane':lane,'qualified_papers':len(result)}))


def combine(root,day,pools):
    import bilingual_mail
    from paper_library import saved_cards
    reports,saved=history(root)
    if already_published(root,day):
        print('A complete non-repeating issue is already published; unchanged.');return
    candidates=[]
    for path in sorted(Path(pools).rglob('*.json')):
        value=json.loads(path.read_text(encoding='utf-8'))
        if value.get('day')==day:candidates.extend(value.get('items',[]))
    chosen=choose_daily(candidates,set(saved),quality_check=quality)
    audit=validate_daily(chosen,set(saved),quality)
    sources=[]
    for index,item in enumerate(chosen,1):
        sid='s'+str(index)
        item.update(source_ids=[sid],primary_source_id=sid)
        sources.append({'id':sid,'title':'Verified original paper','url':'https://doi.org/'+item['doi']})
    report={'date':(date.fromisoformat(day)-timedelta(days=1)).isoformat(),'recommendation_date':day,
            'generated_at':datetime.now(BJ).isoformat(),'edition':'paper-recommendation','demo':False,
            'reading_policy_version':POLICY_VERSION,'selection_audit':audit,
            'bilingual_version':bilingual_mail.VERSION,'bilingual_layout':bilingual_mail.LAYOUT_VERSION,
            'sections':{'papers':{'status':'ok','items':chosen,'sources':sources,'note':''}}}
    if not bilingual_mail.complete(report):raise PolicyError('Bilingual report is incomplete')
    plain,document=bilingual_mail.render(report)
    saved_cards({'document':document,'count':10})
    destination=Path(root)/'data/paper-recommendation'/report['date']
    destination.mkdir(parents=True,exist_ok=True)
    (destination/'report.html').write_text(document,encoding='utf-8')
    (destination/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    for item in chosen:
        for key in identity_keys(item):saved.setdefault(key,day)
    (Path(root)/'reading-history.json').write_text(json.dumps(saved,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(audit,ensure_ascii=False))


def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=('preflight','worker','combine'))
    p.add_argument('--date',default=datetime.now(BJ).date().isoformat())
    p.add_argument('--lane',choices=list(DIRECTIONS));p.add_argument('--output',default='pool/result.json')
    p.add_argument('--pools',default='pool');args=p.parse_args()
    date.fromisoformat(args.date)
    if args.mode=='preflight':
        import os
        ready=already_published(ROOT,args.date)
        values={'day':args.date,'run':str(not ready).lower(),'lanes':json.dumps(list(DIRECTIONS))}
        if os.environ.get('GITHUB_OUTPUT'):
            with open(os.environ['GITHUB_OUTPUT'],'a',encoding='utf-8') as f:
                for key,value in values.items():f.write(key+'='+value+'\n')
        print(json.dumps(values))
    elif args.mode=='worker':
        if not args.lane:p.error('--lane is required')
        worker(ROOT,args.lane,args.date,args.output)
    else:combine(ROOT,args.date,args.pools)


if __name__=='__main__':
    logging.basicConfig(level=logging.INFO)
    main()
