"""Independent scholarly discovery; metadata never substitutes for full text.

Public, key-free bibliographic services only. Source and subject lanes are
interleaved before editorial review, so one index cannot monopolize the queue.
"""
import json
import logging
import re
import threading
import time
import urllib.parse
import urllib.request
from xml.etree import ElementTree as ET

from crossref_metadata import normalize_doi

LOG = logging.getLogger('digest')
NCBI = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/'
EPMC = 'https://www.ebi.ac.uk/europepmc/webservices/rest/'
# Public full-text audit: the abstract assigns mitochondria to bacteria and
# conflates hydroxyl radicals with hydroxide. Do not propagate these errors.
EDITORIAL_EXCLUSIONS={'10.1007/s40820-015-0040-x':'Serious biological and ROS-speciation errors in the source abstract'}
THEMES = (
    ('bioorthogonal', 'bioorthogonal OR tetrazine OR "click-to-release"'),
    ('cadd-aidd', '"virtual screening" OR "drug discovery" AND "deep learning" OR docking'),
    ('neuropharmacology', 'psychedelic OR psychoplastogen OR antidepressant'),
    ('chemical-probes', '"chemical probe" OR chemoproteomics OR "covalent ligand"'),
    ('protein-degradation', 'PROTAC OR LYTAC OR "targeted protein degradation"'),
    ('drug-discovery', '"drug mechanism" OR "drug design" OR "target engagement"'),
)
# An editable entry shortlist, not an excellence score or impact-factor cutoff.
# Every candidate still has to pass the same full-text editorial gate.
JOURNALS = (
    'Nature', 'Science', 'Cell', 'Nature Chemical Biology', 'Nature Chemistry',
    'Nature Biotechnology', 'Nature Methods', 'Nature Medicine', 'Nature Neuroscience',
    'Nature Communications', 'Science Advances', 'Science Translational Medicine',
    'Cell Chemical Biology', 'Chemistry & Biology', 'Chem', 'Molecular Cell',
    'Cell Reports', 'Cell Reports Medicine', 'Neuron', 'Biological Psychiatry',
    'Molecular Psychiatry', 'Neuropsychopharmacology', 'ACS Central Science',
    'ACS Chemical Biology', 'Journal of Medicinal Chemistry',
    'Journal of the American Chemical Society', 'Angewandte Chemie International Edition',
    'Angewandte Chemie (International ed. in English)',
    'Chemical Science', 'Chemical Society Reviews', 'Chemical Reviews',
    'Drug Discovery Today', 'Trends in Pharmacological Sciences',
    'Trends in Chemistry', 'Trends in Biochemical Sciences', 'Trends in Neurosciences',
    'Nature Reviews Drug Discovery', 'Nature Reviews Chemistry',
    'Nature Reviews Molecular Cell Biology', 'Nature Reviews Neuroscience',
    'Annual Review of Pharmacology and Toxicology', 'Annual Review of Biochemistry',
    'Proceedings of the National Academy of Sciences',
    'Proceedings of the National Academy of Sciences of the United States of America',
    'eLife', 'PLOS Biology', 'PLOS Computational Biology', 'PLOS Genetics',
    'PLOS Medicine', 'PLOS Pathogens', 'Journal of Hematology & Oncology',
    'Frontiers in Psychiatry', 'Journal of Chemical Information and Modeling',
    'Journal of Chemical Theory and Computation', 'Briefings in Bioinformatics',
    'Bioinformatics', 'Nucleic Acids Research', 'EMBO Journal', 'The EMBO Journal',
)
def journal_key(value):
    return re.sub(r'[^a-z0-9]', '', value.lower())

PREFERRED_JOURNALS = {journal_key(v) for v in JOURNALS}
BAD_TITLE = re.compile(r'^\s*(retraction|retracted|correction|corrigendum|erratum|editorial|expression of concern)\b', re.I)
_ncbi_lock = threading.Lock()
_ncbi_last = 0.0

def is_preprint(doi):
    value=normalize_doi(doi) or ''
    return (value.startswith(('10.1101/','10.21203/','10.26434/','10.31219/','10.20944/','10.2139/'))
            or bool(re.fullmatch(r'10\.7554/elife\.\d+\.\d+',value)))

def read_bytes(url):
    global _ncbi_last
    if url.startswith(NCBI):
        with _ncbi_lock:
            time.sleep(max(0, .4-(time.monotonic()-_ncbi_last)))
            _ncbi_last = time.monotonic()
    request = urllib.request.Request(url, headers={'User-Agent':'ResearchDigest/1.0 (scholarly full-text reader)'})
    with urllib.request.urlopen(request, timeout=20) as response:
        data = response.read(5_000_001)
    if len(data)>5_000_000 or b'<!ENTITY' in data.upper():
        raise ValueError('Scholarly response is too large or contains entity declarations')
    return data

def read_json(url):
    return json.loads(read_bytes(url))

def title_abstract_query(query,index='epmc'):
    """Keep Boolean structure, but do not match references or author addresses."""
    if index=='epmc':return 'TITLE_ABS:('+query+')'
    if index!='pubmed':raise ValueError('Unknown scholarly index')
    def scope(match):
        value=match.group()
        return value if value.upper() in ('AND','OR','NOT') else value+'[tiab]'
    return re.sub(r'"[^"]+"|[A-Za-z0-9][A-Za-z0-9-]*',scope,query)

def node_text(node):
    return ' '.join(' '.join(node.itertext()).split()) if node is not None else ''

def pubmed_rows(data, kind, used, direction, registry=None):
    root = ET.fromstring(data)
    rows=[]
    for record in root.findall('PubmedArticle'):
        article=record.find('./MedlineCitation/Article')
        if article is None:continue
        types={node_text(n).lower() for n in article.findall('./PublicationTypeList/PublicationType')}
        if types & {'retracted publication','retraction of publication','published erratum','editorial','comment','preprint'}:continue
        if ('review' in types or 'systematic review' in types or 'meta-analysis' in types)!=(kind=='review'):continue
        title=node_text(article.find('ArticleTitle'))
        journal=node_text(article.find('./Journal/Title'))
        eligible=bool(registry.match(journal)) if registry is not None else journal_key(journal) in PREFERRED_JOURNALS
        if BAD_TITLE.search(title) or not eligible:continue
        ids={n.get('IdType'):node_text(n) for n in record.findall('./PubmedData/ArticleIdList/ArticleId')}
        doi=normalize_doi(ids.get('doi'))
        if not doi or doi in used or is_preprint(doi):continue
        rows.append({'doi':doi,'pmcid':ids.get('pmc',''),'research_direction':direction,
                     'discovery_sources':['PubMed'],'candidate_journal':journal})
    return rows

def discover_pubmed(kind, used, day, themes=None, registry=None, audit=None):
    lanes=[]
    for direction,query in (THEMES if themes is None else themes):
        for sort in ('relevance','pub_date'):
            genre='(Review[pt] OR Systematic Review[pt] OR Meta-Analysis[pt])'
            if kind=='research':genre='NOT '+genre
            term=f'({query}) AND {genre} AND ("1900/01/01"[dp] : "{day:%Y/%m/%d}"[dp]) NOT (Retracted Publication[pt] OR Preprint[pt])'
            try:
                lane=[]
                for offset in (0,40,80):
                    if audit is not None:audit['queries']=audit.get('queries',0)+1
                    ids=read_json(NCBI+'esearch.fcgi?'+urllib.parse.urlencode(
                        {'db':'pubmed','term':term,'retmode':'json','retmax':40,'retstart':offset,'sort':sort}))['esearchresult']['idlist']
                    if not ids:break
                    raw=read_bytes(NCBI+'efetch.fcgi?'+urllib.parse.urlencode({'db':'pubmed','id':','.join(ids),'retmode':'xml'}))
                    lane.extend(pubmed_rows(raw,kind,used,direction,registry=registry))
                    if len(lane)>=8 or len(ids)<40:break
                lanes.append(lane[:8])
            except (OSError,ValueError,KeyError,ET.ParseError):
                if audit is not None:audit['failures']=audit.get('failures',0)+1
                LOG.warning('PubMed 推荐检索暂不可用；保留其他独立来源。')
                # Avoid repeated long timeouts when the entire endpoint is down.
                return interleave(lanes)
    return interleave(lanes)

def crossref_rows(rows, used, direction):
    selected=[]
    for row in rows:
        doi=normalize_doi(row.get('DOI'))
        title=' '.join(row.get('title') or [])
        journals=row.get('container-title') or []
        if (not doi or doi in used or is_preprint(doi) or row.get('type')!='journal-article' or BAD_TITLE.search(title)
                or not any(journal_key(j) in PREFERRED_JOURNALS for j in journals)):
            continue
        # Crossmark can record a retraction/concern on the affected article.
        if any(u.get('type') in ('retraction','withdrawal','expression-of-concern') for u in row.get('update-to',[])):continue
        if any(row.get('relation',{}).get(k) for k in ('is-retracted-by','is-preprint-of')):continue
        selected.append({'doi':doi,'pmcid':'','research_direction':direction,
                         'discovery_sources':['Crossref'],'candidate_journal':journals[0]})
    return selected

def discover_crossref(kind, used, day):
    lanes=[]
    for direction,theme in THEMES:
        query=re.sub(r'\b(?:AND|OR)\b|"',' ',theme)
        if kind=='review':query+=' review'
        for sort in ('is-referenced-by-count','relevance'):
            args={'query.bibliographic':query,'filter':f'type:journal-article,until-pub-date:{day.isoformat()}',
                  'rows':60,'sort':sort,'order':'desc'}
            try:
                lane=[]
                for offset in (0,60,120):
                    rows=read_json('https://api.crossref.org/works?'+urllib.parse.urlencode({**args,'offset':offset}))['message']['items']
                    lane.extend(crossref_rows(rows,used,direction))
                    if len(lane)>=8 or len(rows)<60:break
                lanes.append(lane[:8])
            except (OSError,ValueError,KeyError):
                LOG.warning('Crossref 推荐检索暂不可用；保留其他独立来源。')
                return interleave(lanes)
    return interleave(lanes)

def interleave(lanes):
    """Round-robin sources/subjects, deduplicate DOI and merge provenance."""
    selected=[];by_doi={}
    for position in range(max((len(lane) for lane in lanes),default=0)):
        for lane in lanes:
            if position>=len(lane):continue
            row=lane[position];doi=normalize_doi(row.get('doi'))
            if not doi:continue
            if doi not in by_doi:
                row={**row,'doi':doi,'discovery_sources':list(row.get('discovery_sources',[]))}
                by_doi[doi]=row;selected.append(row)
            else:
                saved=by_doi[doi]
                saved['discovery_sources']=list(dict.fromkeys(saved['discovery_sources']+row.get('discovery_sources',[])))
                if not saved.get('pmcid') and re.fullmatch(r'PMC\d+',row.get('pmcid','')):saved['pmcid']=row['pmcid']
    return selected

def plos_fulltext_url(doi):
    match=re.fullmatch(r'10\.1371/journal\.(pbio|pcbi|pgen|pmed|ppat)\.\d+',normalize_doi(doi) or '')
    if not match:return ''
    journal={'pbio':'plosbiology','pcbi':'ploscompbiol','pgen':'plosgenetics','pmed':'plosmedicine','ppat':'plospathogens'}[match[1]]
    return 'https://journals.plos.org/'+journal+'/article/file?'+urllib.parse.urlencode({'id':doi,'type':'manuscript'})

def resolve_pmc(doi):
    """Exact DOI match only; never pick a similarly titled article."""
    doi=normalize_doi(doi)
    if not doi:return ''
    result=read_json(EPMC+'search?'+urllib.parse.urlencode({'query':'DOI:"'+doi+'"','format':'json','resultType':'core','pageSize':10}))
    for row in result.get('resultList',{}).get('result',[]):
        if normalize_doi(row.get('doi'))==doi and row.get('isRetracted')=='Y':
            raise ValueError('Candidate has a retraction flag')
        if normalize_doi(row.get('doi'))==doi and row.get('isRetracted')!='Y' and re.fullmatch(r'PMC\d+',row.get('pmcid','')):
            return row['pmcid']
    return ''
