"""Substantial, diverse chemical-biology reading recommendations per Beijing day.

Reviewed classics bootstrap the queue. New candidates need accessible full text
and a locally generated, evidence-linked editorial review, never just an abstract.
"""
from datetime import date, timedelta, datetime, timezone
import base64
import hashlib
import json
import logging
from itertools import combinations
from pathlib import Path
import re
import urllib.parse
import urllib.request
from xml.etree import ElementTree as ET

from author_roles import jats_roles, display_unit_names, known_unit_translations, unit_translation_valid, name_key
from crossref_metadata import normalize_doi
from github_state import store_from_environment, StateError

VERSION = 'chemical-biology-deep-reading-v1'
EDITION = 'paper-recommendation'
TOPIC = '优秀论文推荐'
CRITERIA = {1:'领域开创性', 2:'很强的创新性', 3:'研究思路与逻辑有意思', 4:'研究内容有实质意义'}
NARRATIVES = ('action','research_logic','own_synthesis','selection_reason','application_prospects','future_directions')
PLAN_VERSION = 'daily-reading-plan-v2'
SINGLE_WEEKDAYS = {1, 2}  # Tuesday and Wednesday in Beijing.
DIRECTIONS = {'bioorthogonal':'生物正交反应', 'cadd-aidd':'CADD/AIDD 与计算药物发现',
              'neuropharmacology':'神经可塑性与抑郁症药物', 'chemical-probes':'化学探针与共价配体',
              'protein-degradation':'靶向蛋白降解', 'drug-discovery':'药物设计与作用机制'}
from reading_policy import DIRECTIONS as BROAD_DIRECTIONS
DIRECTIONS.update({k:v for k,v in BROAD_DIRECTIONS.items() if k not in DIRECTIONS})
ENDPOINT = 'https://www.ebi.ac.uk/europepmc/webservices/rest/'
LOG = logging.getLogger('digest')


class RecommendationError(Exception):
    pass


def scheduled_kind(target):
    return scheduled_plan(target)[0]


def scheduled_plan(target):
    return ('research',) if (target+timedelta(days=1)).weekday() in SINGLE_WEEKDAYS else ('review','research','research')


def research_direction(item):
    declared=item.get('research_direction')
    if declared in DIRECTIONS:return declared
    title=item.get('paper_title',item.get('title','')).lower()
    for direction,pattern in (
        ('bioorthogonal',r'bioorthogonal|bio-orthogonal|staudinger ligation|click-to-release|tetrazine'),
        ('cadd-aidd',r'docking|virtual screening|computer.aided|deep learning|generative'),
        ('neuropharmacology',r'psychedelic|psychoplastogen|hallucinogen|antidepressant|neural plasticity|lsd analogue'),
        ('protein-degradation',r'degrad|protac|lytac'),
        ('chemical-probes',r'covalent ligand|chemical probe|chemoproteom')):
        if re.search(pattern,title):return direction
    return ''


def plan_complete(items,target):
    if not isinstance(items,list) or len(items)!=len(scheduled_plan(target)) or not all(complete_item(i) for i in items):return False
    if len({i['doi'] for i in items})!=len(items):return False
    if len(items)==1:return True
    kinds=[i['recommendation_kind'] for i in items]
    return (kinds.count('review')==1 and kinds.count('research')==2
            and len({research_direction(i) for i in items})==3
            and all(research_direction(i) for i in items))


def ledger_papers(record):
    return record.get('papers',[]) if 'papers' in record else [record]


def used_dois(ledger,except_day=None):
    return {p['doi'] for day,record in ledger.items() if day!=except_day for p in ledger_papers(record)}


def read_json_url(url):
    request = urllib.request.Request(url,headers={'User-Agent':'ResearchDigest/1.0 (public scholarly reader)'})
    with urllib.request.urlopen(request,timeout=30) as response:
        raw = response.read(5_000_001)
    if len(raw) > 5_000_000:
        raise RecommendationError('公开文献数据超过大小限制。')
    return json.loads(raw)


def text(node):
    return ' '.join(' '.join(node.itertext()).split()) if node is not None else ''


def parse_fulltext(data, pmcid='', expected_doi=None):
    if len(data) > 5_000_000 or b'<!ENTITY' in data.upper():
        raise RecommendationError('全文格式不安全或超过大小限制。')
    root = ET.fromstring(data)  # stdlib does not fetch the external JATS DTD.
    # NCBI EFetch wraps its single JATS article in pmc-articleset.
    if root.tag == 'pmc-articleset' and len(root.findall('article')) == 1:
        root = root.find('article')
    if root.tag != 'article' or root.find('body') is None:
        raise RecommendationError('未取得可读取的论文正文。')
    meta = root.find('./front/article-meta')
    if meta is None:
        raise RecommendationError('全文没有可核实的文献信息。')
    doi = normalize_doi(next((n.text for n in meta.findall('article-id') if n.get('pub-id-type')=='doi'),''))
    declared_pmc = next((n.text for n in meta.findall('article-id') if n.get('pub-id-type') in ('pmcid','pmc')),pmcid)
    declared_pmc = 'PMC' + (declared_pmc or '').strip().removeprefix('PMC')
    if (not doi or (pmcid and declared_pmc != pmcid)
            or (expected_doi is not None and doi != normalize_doi(expected_doi))
            or (not pmcid and expected_doi is None)):
        raise RecommendationError('全文身份无法核实。')
    from recommendation_sources import BAD_TITLE, is_preprint
    if (is_preprint(doi) or any('preprint' in text(n).lower() for n in meta.findall('article-version'))):
        raise RecommendationError('预印本不纳入深读推荐配额。')
    if (BAD_TITLE.search(text(meta.find('./title-group/article-title')))
            or any(n.get('related-article-type') in ('retraction','retracted-article','expression-of-concern')
                   for n in meta.findall('.//related-article'))):
        raise RecommendationError('撤稿、关注声明或更正不纳入推荐。')
    kind = root.get('article-type','')
    if kind == 'review-article':
        kind = 'review'
    elif kind in ('research-article','original-article'):
        kind = 'research'
    else:
        raise RecommendationError('评论、社论、勘误或非研究／综述文献不纳入推荐配额。')
    # A serialization strips the harmless external DOCTYPE before role parsing.
    roles = jats_roles(ET.tostring(root))
    if not roles['authors']:
        raise RecommendationError('未取得可靠作者名单。')
    paragraphs = []
    administrative = re.compile(r'acknowledg|author contribution|funding|conflict|publisher|supplementary material|references|associated data|extended data',re.I)
    def walk(node, heading='正文'):
        if node.tag == 'sec':
            heading = text(node.find('title')) or heading
            if administrative.search(heading):
                return
        if node.tag in ('p','caption'):
            value = text(node)
            if len(value) >= 90:
                paragraphs.append({'id':'p'+str(len(paragraphs)+1),'heading':heading,'text':value})
            return
        for child in node:
            if child.tag not in ('ref-list','supplementary-material','table-wrap','ack'):
                walk(child,heading)
    walk(root.find('body'))
    body = '\n'.join(p['heading']+': '+p['text'] for p in paragraphs)
    if len(body) < 2500 or len(paragraphs) < 4:
        raise RecommendationError('可读正文过少，不能生成深入推荐。')
    stamps = []
    for node in meta.findall('pub-date'):
        if node.get('pub-type') in ('pmc-release','pmc-release-in-progress'):
            continue
        try:
            year = int(node.findtext('year'))
            month, day = node.findtext('month'),node.findtext('day')
            stamps.append(date(year,int(month),int(day)).isoformat() if month and day else str(year))
        except (TypeError,ValueError):
            continue
    item = {'doi':doi,'pmcid':pmcid,'title':text(meta.find('./title-group/article-title')),
            'paper_title':text(meta.find('./title-group/article-title')),
            'people':roles['authors'],'first_authors':roles['first_authors'],
            'corresponding_authors':roles['corresponding_authors'],'author_affiliations':roles['author_affiliations'],
            'institutions':list(dict.fromkeys(u for p in roles['author_affiliations'] for u in p['institutions'])),
            'venue':text(root.find('./front/journal-meta/journal-title-group/journal-title')) or text(root.find('./front/journal-meta/journal-title')),
            'publication_time':min(stamps) if stamps else '原文未披露发表日期',
            'kind':'综述' if kind=='review' else '研究论文','recommendation_kind':kind,
            'quote':{'speaker':'','original':'','translation':'','source_id':''},
            'fulltext_sha256':hashlib.sha256(body.encode()).hexdigest(),'fulltext_paragraph_count':len(paragraphs),
            'fulltext_verified':True,'editorial_version':VERSION}
    return item, paragraphs, text(meta.find('abstract'))


def load_fulltext(root, pmcid):
    if not re.fullmatch(r'PMC[0-9]+',pmcid):
        raise RecommendationError('无效的全文编号。')
    path = Path(root)/'data/recommendation-fulltext'/(pmcid+'.xml')
    if path.exists():
        raw = path.read_bytes()
    else:
        from recommendation_sources import read_bytes,NCBI
        urls=(ENDPOINT+pmcid+'/fullTextXML',
              NCBI+'efetch.fcgi?'+urllib.parse.urlencode({'db':'pmc','id':pmcid[3:],'retmode':'xml'}))
        for index,url in enumerate(urls):
            try:
                raw=read_bytes(url)
                parse_fulltext(raw,pmcid)
                break
            except (OSError,ValueError,ET.ParseError,RecommendationError):
                if index==len(urls)-1:raise
                LOG.warning('Europe PMC full-text route unavailable; trying official NCBI PMC XML for %s',pmcid)
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(raw)
    return parse_fulltext(raw,pmcid)


def load_candidate_fulltext(root, candidate):
    """Resolve metadata to an identity-checked body, including publisher XML."""
    from recommendation_sources import plos_fulltext_url, resolve_pmc, read_bytes
    doi=normalize_doi(candidate['doi'])
    pmcid=candidate.get('pmcid','')
    publisher_url=plos_fulltext_url(doi)
    if not pmcid:
        try:
            pmcid=resolve_pmc(doi)
        except OSError:
            if not publisher_url:raise
            LOG.warning('全文索引暂不可用，改用出版社的原文 XML。')
    if pmcid:
        result=load_fulltext(root,pmcid)
        if result[0]['doi']!=doi:raise RecommendationError('索引 DOI 与正文身份不一致。')
        result[0]['fulltext_url']='https://pmc.ncbi.nlm.nih.gov/articles/'+pmcid+'/'
    elif publisher_url:
        path=Path(root)/'data/recommendation-fulltext'/('doi-'+hashlib.sha256(doi.encode()).hexdigest()+'.xml')
        raw=path.read_bytes() if path.exists() else read_bytes(publisher_url)
        result=parse_fulltext(raw,expected_doi=doi)
        if not path.exists():
            path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
        result[0]['fulltext_url']='https://doi.org/'+doi
    else:
        raise RecommendationError('检索到文献信息，但未取得可核验的全文。')
    result[0]['discovery_sources']=candidate.get('discovery_sources',[])
    return result


def repetitive_narrative(value):
    """Reject repeated sentences used to inflate a substantial-reading length."""
    text=value.replace('\\n\\n','\n\n')
    sentences=[re.sub(r'\s+','',s) for s in re.split(r'[。！？\n]+',text)]
    seen=set();repeated=0;total=sum(len(s) for s in sentences)
    for sentence in sentences:
        if len(sentence)<24:continue
        if sentence in seen:repeated+=len(sentence)
        seen.add(sentence)
    return bool(total and repeated/total>.2)


def complete_item(item):
    from paper_summary import valid_title
    if (item.get('editorial_version') != VERSION or item.get('recommendation_kind') not in ('review','research')
            or not item.get('fulltext_verified') or item.get('fulltext_paragraph_count',0) < 4
            or not re.fullmatch(r'[0-9a-f]{64}',item.get('fulltext_sha256',''))
            or not normalize_doi(item.get('doi')) or not valid_title(item.get('paper_title',''),item.get('title_zh'))):
        return False
    criteria = item.get('recommendation_criteria')
    if not isinstance(criteria,list) or not criteria or any(type(c) is not int or c not in CRITERIA for c in criteria):
        return False
    if any(not isinstance(item.get(key),str) or len(item[key].strip()) < minimum
           or not re.search(r'[\u4e00-\u9fff]',item[key]) for key,minimum in
           [('action',450),('research_logic',160),('own_synthesis',100),('selection_reason',200),
            ('application_prospects',80),('future_directions',100)]):
        return False
    if sum(len(item[key]) for key in NARRATIVES) < 1200:
        return False
    if any(repetitive_narrative(item[key]) for key in NARRATIVES):return False
    if (item.get('editorial_method')=='local-fulltext-analysis'
            and not re.search(r'归纳|启发|迁移|方法论|在我看来|我的理解',item['own_synthesis'])):return False
    names = (item.get('first_authors') or item.get('people',[])[:1]) + (item.get('corresponding_authors') or item.get('people',[])[-1:])
    pairs = {name_key(p['name']):p.get('institutions',[]) for p in item.get('author_affiliations',[])}
    units = display_unit_names(item)
    from affiliation_sources import units_complete
    if not units_complete(item):return False
    return bool(names and units and all(pairs.get(name_key(n)) for n in names)
                and all(unit_translation_valid(u,item.get('institutions_zh',{}).get(u)) for u in units))


class ReadingLedger:
    def __init__(self, root, remote=None):
        self.path = Path(root)/'data'/EDITION/'reading-ledger.json'
        self.remote = remote

    def read(self):
        if self.remote:
            value = self.remote.request('GET','contents/reading-ledger.json?'+urllib.parse.urlencode({'ref':self.remote.branch}),allow_404=True)
            if value is None:
                return {},None
            try:
                data = json.loads(base64.b64decode(value['content']).decode('utf-8'))
            except (KeyError,ValueError,UnicodeError):
                raise StateError('推荐记录损坏，停止选文以避免重复。') from None
            sha = value['sha']
        elif self.path.exists():
            data = json.loads(self.path.read_text(encoding='utf-8'));sha=None
        else:
            return {},None
        if (not isinstance(data,dict) or any(not isinstance(v,dict) or not ledger_papers(v)
                or not isinstance(ledger_papers(v),list) or any(not isinstance(p,dict)
                    or not normalize_doi(p.get('doi')) or p.get('kind') not in ('review','research')
                    for p in ledger_papers(v)) for v in data.values())):
            raise StateError('推荐记录格式异常。')
        try:
            for day in data:date.fromisoformat(day)
        except (ValueError,TypeError):
            raise StateError('推荐记录日期格式异常。') from None
        if len(used_dois(data)) != sum(len(ledger_papers(v)) for v in data.values()):
            raise StateError('推荐记录存在重复论文，停止选文。')
        return data,sha

    def reserve(self, target, item):
        self.reserve_many(target,[item])

    def reserve_many(self, target, items):
        day = target.isoformat()
        requested=[{'doi':i['doi'],'kind':i['recommendation_kind'],'pmcid':i.get('pmcid',''),
                    'direction':research_direction(i),'discovery_sources':i.get('discovery_sources',[])} for i in items]
        if not requested or len({p['doi'] for p in requested})!=len(requested):
            raise StateError('本日推荐名单为空或有重复论文。')
        for _ in range(3):
            ledger,sha = self.read()
            existing = ledger.get(day)
            if existing:
                old={(p['doi'],p['kind']) for p in ledger_papers(existing)}
                new={(p['doi'],p['kind']) for p in requested}
                if old==new:
                    return
                # An older one-paper reservation can be extended to the new
                # three-paper plan, retaining that exact reserved paper.
                if not ('papers' not in existing and len(requested)==3 and old<new):
                    raise StateError('该日期已有另一组推荐，停止覆盖。')
            if used_dois(ledger,day)&{p['doi'] for p in requested}:
                raise StateError('该论文已在其他日期推荐，停止重复选文。')
            ledger[day] = {'papers':requested,'plan_version':PLAN_VERSION}
            if not self.remote:
                self.path.parent.mkdir(parents=True,exist_ok=True)
                temp = self.path.with_suffix('.tmp')
                temp.write_text(json.dumps(ledger,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(self.path)
                return
            payload = {'branch':self.remote.branch,'message':'Reserve daily reading '+day,
                       'content':base64.b64encode(json.dumps(ledger,ensure_ascii=False).encode()).decode()}
            if sha:payload['sha']=sha
            try:
                self.remote.request('PUT','contents/reading-ledger.json',payload)
                return
            except StateError:
                continue
        raise StateError('无法持久保存推荐记录，停止发送。')


def load_catalog(root):
    value = json.loads((Path(root)/'recommendation_catalog.json').read_text(encoding='utf-8'))
    return [item for item in value['papers'] if complete_item(item)]


def unused_curated(root, target, ledger):
    catalog = load_catalog(root)
    assigned = ledger.get(target.isoformat())
    if assigned:
        assigned_dois={p['doi'] for p in ledger_papers(assigned)}
        return [item for item in catalog if item['doi'] in assigned_dois or item['doi'] not in used_dois(ledger)]
    return [item for item in catalog if item['doi'] not in used_dois(ledger)]


class _ReviewedTranslator:
    """Check committed editorial translations without loading a model or writing caches."""
    def __init__(self, root):
        path=Path(root)/'reviewed_english.json'
        self.reviewed=json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}

    def translate(self, source, language='en'):
        import bilingual_mail as bilingual
        if not source.strip():return ''
        if language=='en' and not re.search(r'[\u4e00-\u9fff]',source):return source
        if language=='zh' and re.search(r'[\u4e00-\u9fff]',source):return source
        source=source.strip()
        if language=='en' and source in bilingual.FIXED_ENGLISH:return bilingual.FIXED_ENGLISH[source]
        key=hashlib.sha256((bilingual.VERSION+language+source).encode()).hexdigest()
        entry=self.reviewed.get(key)
        if (isinstance(entry,dict) and entry.get('source')==source and entry.get('language')==language
                and bilingual.valid_translation(source,entry.get('translation'),language)):
            return entry['translation']
        raise bilingual.TranslationError('A required reviewed translation is unavailable',source=source,language=language)


def curated_ready(root, target, remote, config=None):
    """A complete, unsent plan must also be renderable without a translation model."""
    from paper_history import history_from
    import bilingual_mail as bilingual
    config=config or {}
    history=history_from(config,root,remote)
    excluded={key[4:] for key in history.blocked(target.isoformat(),EDITION) if key.startswith('doi:')} if history else set()
    items=select_papers(root,target,ReadingLedger(root,remote).read()[0],curated_only=True,excluded_dois=excluded)
    if items is None:return False
    if not bilingual.enabled(config):return True
    report={'edition':EDITION,'sections':{TOPIC:{'items':items}}}
    try:
        bilingual.prepare(report,root,translator=_ReviewedTranslator(root))
        return bilingual.complete(report)
    except (OSError,ValueError):
        return False


def curated_combination(catalog,target,assigned,used):
    """Find a complete diverse set before requesting any model downloads."""
    if len(scheduled_plan(target))==1:
        choices=assigned or [i for i in catalog if i['doi'] not in used and i['recommendation_kind']=='research']
        return choices[:1] if choices and plan_complete(choices[:1],target) else None
    reserved={i['doi'] for i in assigned}
    available=[i for i in catalog if i['doi'] not in used|reserved and research_direction(i)]
    reviews=[i for i in assigned if i['recommendation_kind']=='review'] or [i for i in available if i['recommendation_kind']=='review']
    fixed_research=[i for i in assigned if i['recommendation_kind']=='research']
    if len(fixed_research)>2 or sum(i['recommendation_kind']=='review' for i in assigned)>1:return None
    for review in reviews:
        base=[review]+fixed_research
        directions={research_direction(i) for i in base}
        if len(directions)!=len(base):continue
        # One representative per direction suffices for finding a valid set.
        options={}
        for item in available:
            direction=research_direction(item)
            if item['recommendation_kind']=='research' and direction not in directions:
                options.setdefault(direction,item)
        for additional in combinations(options.values(),2-len(fixed_research)):
            group=base+list(additional)
            if plan_complete(group,target):return group
    return None


def discover_europe_pmc(kind, used, delivery_day):
    from recommendation_sources import is_preprint
    genre = 'PUB_TYPE:review' if kind=='review' else 'NOT PUB_TYPE:review'
    themes = (
        '(TITLE_ABS:bioorthogonal OR TITLE_ABS:"bio-orthogonal" OR TITLE_ABS:"Staudinger ligation" OR TITLE_ABS:"strain-promoted azide" OR TITLE_ABS:"click-to-release" OR (TITLE_ABS:tetrazine AND TITLE_ABS:ligation))',
        '(TITLE_ABS:"chemical biology" OR TITLE_ABS:"chemical probe" OR TITLE_ABS:"covalent ligand" OR TITLE_ABS:"targeted degradation" OR TITLE_ABS:PROTAC OR TITLE_ABS:"drug discovery")',
        '(TITLE_ABS:"virtual screening" OR TITLE_ABS:"computer-aided drug" OR TITLE_ABS:"structure-based drug" OR ((TITLE_ABS:"deep learning" OR TITLE_ABS:"machine learning" OR TITLE_ABS:"generative model") AND (TITLE_ABS:drug OR TITLE_ABS:ligand)))',
        '(TITLE_ABS:psychoplastogen OR TITLE_ABS:antidepressant OR ((TITLE_ABS:depression OR TITLE_ABS:psychedelic) AND (TITLE_ABS:molecular OR TITLE_ABS:receptor OR TITLE_ABS:plasticity OR TITLE_ABS:compound)))',
    )
    lanes = []
    # Interleave subject areas and established/recent work. Citation counts
    # narrow the reading queue only; they do not satisfy a quality criterion.
    # Page past used papers, so the program does not exhaust the first page.
    for direction,theme in zip(('bioorthogonal','chemical-probes','cadd-aidd','neuropharmacology'),themes):
        for sort in ('sort_cited:y','sort_date:y'):
            query = f'{theme} AND OPEN_ACCESS:Y AND HAS_FT:Y AND {genre} AND FIRST_PDATE:[1900-01-01 TO {delivery_day.isoformat()}] {sort}'
            lane=[];seen=set();cursor='*'
            for _ in range(12):
                url=ENDPOINT+'search?'+urllib.parse.urlencode({'query':query,'format':'json','resultType':'core','pageSize':25,'cursorMark':cursor})
                try:
                    result=read_json_url(url)
                except (OSError,ValueError,RecommendationError):
                    LOG.warning('部分推荐检索来源暂时不可用，继续其他主题。')
                    break
                rows=result.get('resultList',{}).get('result',[])
                for row in rows:
                    doi=normalize_doi(row.get('doi'))
                    if (doi and doi not in used|seen and not is_preprint(doi)
                            and row.get('source')!='PPR' and 'preprint' not in [p.lower() for p in row.get('pubTypeList',{}).get('pubType',[])]
                            and re.fullmatch(r'PMC[0-9]+',row.get('pmcid','')) and row.get('isRetracted')!='Y'):
                        lane.append({'doi':doi,'pmcid':row['pmcid'],'research_direction':direction,
                                     'discovery_sources':['Europe PMC']});seen.add(doi)
                next_cursor=result.get('nextCursorMark')
                if len(lane)>=8 or not rows or not next_cursor or next_cursor==cursor:
                    break
                cursor=next_cursor
            lanes.append(lane)
    selected=[];seen=set()
    for position in range(max((len(lane) for lane in lanes),default=0)):
        for lane in lanes:
            if position<len(lane) and lane[position]['doi'] not in seen:
                selected.append(lane[position]);seen.add(lane[position]['doi'])
    return selected


def discover_candidates(kind, used, delivery_day):
    from recommendation_sources import discover_pubmed, discover_crossref, interleave
    return interleave([discover_europe_pmc(kind,used,delivery_day),
                       discover_pubmed(kind,used,delivery_day),
                       discover_crossref(kind,used,delivery_day)])


def select_papers(root,target,ledger,writer=None,curated_only=False,excluded_dois=None):
    catalog=load_catalog(root)
    by_doi={i['doi']:i for i in catalog}
    selected=[];used=used_dois(ledger,target.isoformat())|set(excluded_dois or ());pools={}
    def analyzed(candidate):
        nonlocal writer
        try:
            paper,paragraphs,abstract=load_candidate_fulltext(root,candidate)
            if paper['doi']!=candidate['doi']:return None
            if writer is None:
                from recommendation_writer import DeepReadingWriter
                writer=DeepReadingWriter(root)
            result=writer.analyze(paper,paragraphs,abstract)
            return result if result and complete_item(result) else None
        except (OSError,ValueError,ET.ParseError,RecommendationError):
            LOG.warning('推荐候选全文或深入分析未通过检查，换选下一篇：%s',candidate['doi'])
            return None
    assigned=ledger_papers(ledger[target.isoformat()]) if target.isoformat() in ledger else []
    for record in assigned:
        if record['doi'] in used:
            raise RecommendationError('预留论文已在其他日期或栏目发送，停止重复推荐。')
        item=by_doi.get(record['doi'])
        if item is None:
            if curated_only:return None
            item=analyzed(record)
        if not item or item['recommendation_kind']!=record['kind']:
            raise RecommendationError('已预留文章未通过全文与类型核验，停止替换。')
        selected.append(item)
    plan=scheduled_plan(target)
    if len(plan)==1 and selected:
        if len(selected)==1 and plan_complete(selected,target):return json.loads(json.dumps(selected))
        raise RecommendationError('本日已预留名单与单篇计划冲突。')
    if len(plan)==3 and (len({research_direction(i) for i in selected})!=len(selected)
            or any(not research_direction(i) for i in selected)):
        raise RecommendationError('预留文章的研究方向缺失或重复。')
    ready=curated_combination(catalog,target,selected,used)
    if ready:return json.loads(json.dumps(ready,ensure_ascii=False))
    if curated_only:return None
    for kind in plan:
        wanted=plan.count(kind)
        if sum(i['recommendation_kind']==kind for i in selected)>=wanted:continue
        existing={i['doi'] for i in selected}
        directions={research_direction(i) for i in selected}
        item=next((i for i in catalog if i['recommendation_kind']==kind
            and i['doi'] not in used|existing and research_direction(i)
            and (len(plan)==1 or research_direction(i) not in directions)),None)
        if item is None and not curated_only:
            if kind not in pools:pools[kind]=discover_candidates(kind,used|existing,target+timedelta(days=1))
            for candidate in pools[kind][:16]:
                if candidate['doi'] in used|existing:continue
                if len(plan)>1 and candidate.get('research_direction') in directions:continue
                result=analyzed(candidate)
                if (result and result['recommendation_kind']==kind and research_direction(result)
                        and (len(plan)==1 or research_direction(result) not in directions)):
                    item=result;break
        if item is None:
            if curated_only:return None
            raise RecommendationError('未找到满足本日篇数、综述配额、不同方向与全文深读要求的完整推荐组合；不发送凑数推荐。')
        selected.append(item)
    selected.sort(key=lambda i:0 if i['recommendation_kind']=='review' else 1)
    if not plan_complete(selected,target):
        raise RecommendationError('深度阅读组合没有通过本日配额与不同方向检查。')
    return json.loads(json.dumps(selected,ensure_ascii=False))


def build_report(root, config, target, reserve=False, writer=None):
    import daily_digest as digest
    from public_research import ENGINE
    remote=store_from_environment()
    if remote:remote.ensure_branch()
    ledger_store=ReadingLedger(root,remote)
    ledger,_=ledger_store.read()
    from paper_history import history_from,reserve_report
    history=history_from(config,root,remote)
    excluded={key[4:] for key in history.blocked(target.isoformat(),EDITION) if key.startswith('doi:')} if history else set()
    items=select_papers(root,target,ledger,writer=writer,**({'excluded_dois':excluded} if history else {}))
    sources=[]
    for index,item in enumerate(items):
        first='s'+str(2*index+1);second='s'+str(2*index+2)
        item.update(primary_source_id=first,date_source_id=first,source_ids=[first,second],research_direction=research_direction(item))
        sources.extend([{'id':first,'title':'期刊原文与 DOI','url':'https://doi.org/'+item['doi']},
                        {'id':second,'title':'可读取全文','url':item.get('fulltext_url') or
                         ('https://pmc.ncbi.nlm.nih.gov/articles/'+item['pmcid']+'/' if item.get('pmcid') else 'https://doi.org/'+item['doi'])}])
    section={'status':'ok','items':items,'sources':sources,'quality_gate':VERSION,
             'note':'周二、周三每天1篇；其余每天3篇，含1篇综述、2篇研究论文，三篇研究方向不同。论文不限发表年份。',
             'engine':ENGINE,'max_items':len(items)}
    report={'date':target.isoformat(),'recommendation_date':(target+timedelta(days=1)).isoformat(),
            'generated_at':datetime.now(digest.BJ).isoformat(),'edition':EDITION,'engine':ENGINE,'demo':False,
            'sections':{TOPIC:section},'recommendation_version':VERSION,'recommendation_plan_version':PLAN_VERSION}
    digest.prepare_language(report,config)
    if reserve:
        reserve_report(history,report)
        ledger_store.reserve_many(target,items)
    directory = digest.report_directory(target,EDITION)
    digest.save_json(directory/'report.json',report);digest.write_preview(report,directory)
    return report
