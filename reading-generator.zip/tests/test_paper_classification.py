import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from paper_classification import (classification_ready,checked_audit,display_direction,
    make_audit,registry,semantic_issue,title_key)
from paper_library import paper_direction,paper_type,DIRECTION_LABELS
from reading_policy import direction


def certified(item,subject='organic'):
    item={**item,'research_direction':subject,'fulltext_sha256':'a'*64}
    if not item.get('doi'):
        import hashlib
        item['doi']='10.1234/'+hashlib.sha256(item['title'].encode()).hexdigest()[:16]
    paragraphs=[{'id':'p'+str(n),'text':'Original controlled chemistry and drug discovery evidence from independent experiments. '+str(n)} for n in range(1,4)]
    decision={'research_direction':subject,'focus':'The central contribution concerns experimentally supported chemical research and drug discovery.',
              'evidence_ids':['p1','p2','p3']}
    item['classification_audit']=make_audit(item,decision,decision,paragraphs,'Original chemical and drug discovery evidence.')
    return item


class ClassificationTests(unittest.TestCase):
    def item(self,doi):
        row=registry()[doi]
        return {'doi':doi,'paper_title':row['title'],'research_direction':'neuropharmacology'}

    def test_actual_published_misclassifications_are_corrected(self):
        cases={
          '10.1002/advs.78113':('inorganic','inorganic'),
          '10.1038/nature14292':('cancer-biology',''),
          '10.7150/thno.18068':('diagnostic-imaging',''),
          '10.2196/104397':('medical-education',''),
          '10.1186/2049-2618-1-28':('microbial-ecology',''),
          '10.1016/j.cell.2026.08.057':('structural-biology',''),
          '10.1080/10717544.2026.2614585':('drug-delivery','drug-discovery'),
          '10.1002/advs.78164':('electrochemistry','electrochemistry'),
          '10.1039/c7sc02664a':('cheminformatics','interdisciplinary'),
          '10.1007/s10555-026-10388-1':('cancer-biology',''),
        }
        for doi,(display,canonical) in cases.items():
            with self.subTest(doi=doi):
                item=self.item(doi)
                self.assertEqual(paper_direction(item),display)
                self.assertEqual(direction(item),canonical)
                self.assertEqual(classification_ready(item),bool(canonical))

    def test_all_reviewed_entries_have_sources_valid_types_and_visible_labels(self):
        self.assertEqual(len(registry()),47)
        for doi,row in registry().items():
            self.assertTrue(row['source_url'].startswith('https://'))
            self.assertGreater(len(row['reason']),10)
            self.assertIn(row['display_direction'],DIRECTION_LABELS)
            self.assertIn(paper_type(self.item(doi)),('review','research'))

    def test_doi_does_not_apply_to_a_different_article_title(self):
        item=self.item('10.1002/advs.78113');item['paper_title']='An unrelated paper'
        self.assertEqual(display_direction(item),'other')
        self.assertFalse(classification_ready(item))

    def test_search_lane_and_generated_future_applications_are_not_evidence(self):
        item={'doi':'10.1234/new','title':'A new coordination complex',
              'research_direction':'chemical-probes','future_directions':'Treat depression with AI drug discovery'}
        self.assertEqual(paper_direction(item),'other')
        self.assertFalse(classification_ready(item))

    def test_semantic_boundaries_reject_specific_false_friends(self):
        for subject,title,body in (
            ('neuropharmacology','Cancer checkpoint blockade','A depression in the CD8/Treg ratio.'),
            ('neuropharmacology','Neuroendocrine tumour imaging','PET prognosis.'),
            ('protein-degradation','ATP synthase structure','Protein structure and energy metabolism.'),
            ('chemical-probes','Phosphine coordination complexes','Isotope NMR spectroscopy.'),
            ('cadd-aidd','Molecular machine learning','Quantum chemistry benchmarks.'),
            ('interdisciplinary','Educational evaluation of a training module','Students learning radiation safety.'),
        ):
            with self.subTest(title=title):self.assertTrue(semantic_issue(subject,title,body))
        self.assertFalse(semantic_issue('neuropharmacology','Antidepressant effects','Treatment experiments.'))

    def test_new_evidence_survives_only_matching_identity_body_and_two_decisions(self):
        good=certified({'doi':'10.1234/new','paper_title':'Original chemistry'})
        self.assertTrue(classification_ready(good))
        changes=[('doi','10.1234/other'),('paper_title','Different study'),
                 ('fulltext_sha256','b'*64),('research_direction','chemical-probes')]
        for key,value in changes:
            broken={**good,key:value}
            self.assertFalse(classification_ready(broken))
        broken=copy.deepcopy(good)
        broken['classification_audit']['decisions'][1]['direction']='inorganic'
        self.assertFalse(classification_ready(broken))
        broken=copy.deepcopy(good)
        broken['classification_audit']['decisions'][0]['evidence_ids']=['invented','p1']
        self.assertFalse(classification_ready(broken))
        broken=copy.deepcopy(good);broken['classification_audit']['version']='old-cache'
        self.assertFalse(classification_ready(broken))

    def test_publication_quality_rejects_unreviewed_complete_editorial(self):
        from website_daily import quality
        with patch('paper_recommendation.complete_item',return_value=True),patch('bilingual_mail.complete',return_value=True):
            self.assertFalse(quality({'doi':'10.1234/new','research_direction':'organic'}))
            self.assertTrue(quality(certified({'doi':'10.1234/new','paper_title':'A chemical study'})))
            self.assertFalse(quality(self.item('10.1038/nature14292')))

    def test_writer_holds_disagreement_before_generating_the_article(self):
        from recommendation_writer import DeepReadingWriter
        first={'focus':'The original experiments develop a new method for organic synthesis.',
               'research_direction':'organic','evidence_ids':['p1','p2']}
        second={'assessment':'The original evidence concerns catalyst design and controlled mechanistic comparisons. '*3,
                'research_direction':'catalysis','related':True,'substantive':True,'not_routine':True,
                'criteria':[3],'evidence_ids':['p1','p2','p3']}
        item={'doi':'10.1234/new','paper_title':'Original chemistry','fulltext_sha256':'a'*64,'recommendation_kind':'research'}
        with tempfile.TemporaryDirectory() as folder,patch('affiliation_sources.units_complete',return_value=True):
            writer=DeepReadingWriter(folder)
            with patch.object(writer,'evidence_pack',return_value=('Original full text',{'p1','p2','p3'})),patch.object(writer,'generate',side_effect=[first,second]) as model:
                self.assertIsNone(writer.analyze(item,[],''))
                self.assertEqual(writer.last_rejection,'classification_disagreement_requires_review')
                self.assertEqual(model.call_count,2)

    def test_saved_body_and_directory_show_the_same_corrected_subject(self):
        from reading_view import article_cards
        item=self.item('10.1002/advs.78113')
        old=("<h4>Research direction <span>研究方向</span></h4>"
             "<div>Chemical probes and covalent ligands</div><div>化学探针与共价配体</div>"
             "<h4>Study overview</h4><p>Keep scientific prose and H<sub>2</sub>O.</p>")
        entry={'count':1,'saved_cards':[old],'report':{'sections':{'papers':{'items':[item]}}}}
        rendered=article_cards(entry)[0]
        self.assertNotIn('Chemical probes',rendered)
        self.assertNotIn('化学探针',rendered)
        self.assertIn('Inorganic and coordination chemistry',rendered)
        self.assertIn('无机与配位化学',rendered)
        self.assertIn('Keep scientific prose and H<sub>2</sub>O.',rendered)


if __name__=='__main__':unittest.main()
