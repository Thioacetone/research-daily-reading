import unittest
from author_roles import author_unit_fields, display_unit_names, jats_roles, meta_correspondents, known_unit_translations, merge_author_affiliations
import public_research as public


class AuthorRoleTests(unittest.TestCase):
    def test_translation_input_excludes_postal_address_and_preserves_deposited_campus(self):
        from author_roles import academic_unit_text
        self.assertEqual(academic_unit_text('Department of Chemistry, University of Cambridge, Lensfield Road, Cambridge CB2 1EW, UK'),
                         'Department of Chemistry, University of Cambridge')
        self.assertEqual(academic_unit_text('Department of Chemistry, University of California, Los Angeles, CA 90095, USA'),
                         'Department of Chemistry, University of California, Los Angeles')
    def test_chinese_address_cannot_hide_postcode_behind_word_boundaries(self):
        from author_roles import unit_translation_valid
        original='Department of Chemistry, University of Cambridge, UK'
        self.assertFalse(unit_translation_valid(original,'剑桥大学化学系，加利福尼亚州92037，美国'))
        self.assertTrue(unit_translation_valid(original,'剑桥大学化学系'))
    def test_structured_postal_country_is_not_joined_to_institution(self):
        raw=b'''<article><front><article-meta><contrib-group><contrib contrib-type="author">
        <name><surname>First</surname></name><xref ref-type="aff" rid="a1"/></contrib></contrib-group>
        <aff id="a1"><institution>TU Wien, Institute of Chemistry</institution><country>Austria</country></aff>
        </article-meta></front></article>'''
        from affiliation_sources import units_complete
        from author_roles import affiliation_country,unit_has_detail
        parsed=jats_roles(raw)
        self.assertTrue(units_complete({**parsed,'people':parsed['authors']}))
        self.assertEqual(affiliation_country('School of Physics, Universiti Sains Malaysia, Pulau Pinang Malaysia'),'马来西亚')
        self.assertEqual(affiliation_country('Universitat de València, Valencia, España'),'西班牙')
        self.assertTrue(unit_has_detail('Instituto de Química, Universitat de València, España'))
    def test_one_shared_group_address_maps_only_when_unambiguous(self):
        group='''<article><front><article-meta><contrib-group>
        <contrib contrib-type="author"><name><surname>First</surname></name>{ref}</contrib>
        <contrib contrib-type="author"><name><surname>Last</surname></name></contrib>
        <aff id="a1">School of Chemistry, University A, UK</aff>{extra}
        </contrib-group></article-meta></front></article>'''
        result=jats_roles(group.format(ref='',extra='').encode())
        self.assertTrue(all(row['institutions']==['School of Chemistry, University A, UK'] for row in result['author_affiliations']))
        for values in ({'ref':'<xref ref-type="aff" rid="a1"/>','extra':''},
                       {'ref':'','extra':'<aff id="a2">School of Chemistry, University B, UK</aff>'}):
            result=jats_roles(group.format(**values).encode())
            self.assertFalse(any(row['name']=='Last' and row['institutions'] for row in result['author_affiliations']))

    def test_explicit_corresponding_note_without_email_is_recognized(self):
        raw=b'''<article><front><article-meta><contrib-group>
        <contrib contrib-type="author"><name><surname>First</surname><given-names>A</given-names></name><xref ref-type="author-notes" rid="c"/></contrib>
        <contrib contrib-type="author"><name><surname>Last</surname><given-names>B</given-names></name></contrib>
        </contrib-group><author-notes><fn id="c">Corresponding author.</fn></author-notes>
        </article-meta></front></article>'''
        self.assertEqual(jats_roles(raw)['corresponding_authors'],['A First'])

    def test_printed_department_abbreviation_and_bulgarian_country(self):
        from author_roles import unit_has_detail,affiliation_country
        self.assertTrue(unit_has_detail('Università degli Studi di Firenze, NEUROFARBA Dept, Florence, Italy'))
        self.assertFalse(unit_has_detail('University of Florence, Italy'))
        self.assertEqual(affiliation_country('Institute of Neurobiology, Bulgarian Academy of Sciences, Sofia, Bulgaria'),'保加利亚')

    def test_chinese_units_show_only_target_authors_and_do_not_invent_a_college(self):
        item = {'people':['Alice','Bob','Carol'], 'author_affiliations':[
            {'name':'Alice','institutions':['Hunan University']},
            {'name':'Bob','institutions':['Not Displayed University']},
            {'name':'Carol','institutions':['Shanghai Jiao Tong University']}]}
        self.assertEqual(display_unit_names(item), ['Hunan University','Shanghai Jiao Tong University'])
        fields = dict(author_unit_fields(item))
        self.assertIn('湖南大学（院系待原文核实）', fields['第一作者及工作单位'])
        self.assertIn('上海交通大学（院系待原文核实）', fields['通讯作者及工作单位（默认末位作者）'])
        self.assertNotIn('Hunan University', str(fields))
        self.assertNotIn('Not Displayed', str(fields))

    def test_school_display_orders_university_before_college_without_address(self):
        unit = 'School of Chemistry and Chemical Engineering, Nanjing University, Nanjing 210023, China'
        fields = dict(author_unit_fields({'people':['Alice'], 'author_affiliations':[{'name':'Alice','institutions':[unit]}]}))
        self.assertEqual(fields['第一作者及工作单位'], 'Alice：南京大学化学化工学院')
        self.assertNotIn('210023', str(fields))
        self.assertNotIn('School', str(fields))

    def test_department_is_preserved_and_unknown_school_not_collapsed(self):
        units = ['Department of Chemistry, University of Bristol, Cantock’s Close',
                 'School of Unlisted Studies, Hunan University']
        translated = known_unit_translations(units)
        self.assertEqual(translated[units[0]], '布里斯托大学化学系')
        self.assertNotIn(units[1], translated)
        item = {'people':['Alice'],'author_affiliations':[{'name':'Alice','institutions':[units[1]]}],
                'institutions_zh':{units[1]:'湖南大学未列名研究学院'}}
        self.assertIn('湖南大学未列名研究学院',str(author_unit_fields(item)))

    def test_detailed_author_mapping_replaces_only_same_authors_broad_unit(self):
        existing = [{'name':'Alice','institutions':['Nanjing University']},
                    {'name':'Bob','institutions':['Nanjing University']}]
        detailed = [{'name':'Alice','institutions':['School of Chemistry, Nanjing University']}]
        result = merge_author_affiliations(existing, detailed)
        self.assertEqual(result[0]['institutions'], detailed[0]['institutions'])
        self.assertEqual(result[1]['institutions'], ['Nanjing University'])
        self.assertEqual(merge_author_affiliations(result,existing), result)
        separate = merge_author_affiliations(existing, [{'name':'Alice','institutions':['School of Chemistry, Nanjing University of Technology']}])
        self.assertEqual(len(separate[0]['institutions']),2)

    def test_html_author_references_link_specific_school_to_exact_name(self):
        page = b'''<meta name="citation_author" content="Alice"><meta name="citation_author_institution" content="Nanjing University">
        <meta name="citation_author" content="Bob"><meta name="citation_author_institution" content="Hunan University">
        <div class="author-info"><span class="author-name">Alice</span><a href="#aff1">1</a></div>
        <div class="author-info"><span class="author-name">Bob</span><a href="#aff2">2</a></div>
        <div class="author-info"><span class="author-name">Unrelated Person</span><a href="#aff1">1</a></div>
        <div class="affiliation" id="aff1">School of Chemistry, Nanjing University</div>
        <div class="affiliation" id="aff2">Department of Chemistry, Hunan University</div>'''
        info = public.article_info(page)
        self.assertEqual(info['author_affiliations'], [
            {'name':'Alice','institutions':['School of Chemistry, Nanjing University']},
            {'name':'Bob','institutions':['Department of Chemistry, Hunan University']}])

    def test_department_meta_preserved_with_individual_author(self):
        page = b'''<meta name="citation_author" content="Alice"><meta name="citation_author_institution" content="Nanjing University">
        <meta name="citation_author_department" content="School of Chemistry">'''
        self.assertEqual(public.article_info(page)['author_affiliations'][0]['institutions'],
                         ['School of Chemistry, Nanjing University'])
        reversed_page = b'''<meta name="citation_author" content="Alice"><meta name="citation_author_department" content="School of Chemistry">
        <meta name="citation_author_institution" content="Nanjing University"><meta name="citation_author_affiliation" content="School of Chemistry, Nanjing University">'''
        self.assertEqual(public.article_info(reversed_page)['author_affiliations'][0]['institutions'],
                         ['School of Chemistry, Nanjing University'])

    def test_only_first_and_explicit_corresponding_units_are_displayed(self):
        item = {'people':['Alice', 'Bob', 'Carol'], 'corresponding_authors':['Carol'],
                'institutions':['Pooled Unit'], 'author_affiliations':[
                    {'name':'Alice', 'institutions':['First Unit']},
                    {'name':'Bob', 'institutions':['Middle Unit']},
                    {'name':'Carol', 'institutions':['Corresponding Unit', 'Other Corresponding Unit']}]}
        text = str(author_unit_fields(item))
        self.assertIn('Alice：First Unit', text)
        self.assertIn('Carol：Corresponding Unit；Other Corresponding Unit', text)
        self.assertNotIn('Middle Unit', text)
        self.assertNotIn('Pooled Unit', text)

    def test_default_last_author_uses_only_their_mapped_units(self):
        fields = dict(author_unit_fields({'people':['Alice','Bob'], 'institutions':['Pooled Unit'],
                                         'author_affiliations':[{'name':'Bob','institutions':['Last Unit']}]}))
        self.assertEqual(fields['第一作者及工作单位'], 'Alice：工作单位未明确提供')
        self.assertEqual(fields['通讯作者及工作单位（默认末位作者）'], 'Bob：Last Unit')
        self.assertNotIn('Pooled Unit', str(fields))

    def test_explicit_corresponding_author_overrides_last_author_default(self):
        item = {'people':['Alice','Bob','Carol'], 'corresponding_authors':['Alice'],
                'author_affiliations':[{'name':'Alice','institutions':['First Unit']},
                                       {'name':'Carol','institutions':['Last Unit']}]}
        fields = dict(author_unit_fields(item))
        self.assertEqual(fields['通讯作者及工作单位'], 'Alice：First Unit')
        self.assertNotIn('Last Unit', str(fields))

    def test_last_author_missing_units_does_not_borrow_another_author_units(self):
        item = {'people':['Alice','Bob'], 'institutions':['Pooled Unit'],
                'author_affiliations':[{'name':'Alice','institutions':['First Unit']}]}
        fields = dict(author_unit_fields(item))
        self.assertEqual(fields['通讯作者及工作单位（默认末位作者）'], 'Bob：工作单位未明确提供')

    def test_jats_explicit_correspondence_and_affiliation_references(self):
        page = b'''<article><front><article-meta><contrib-group>
        <contrib contrib-type="author"><name><surname>Smith</surname><given-names>Alice</given-names></name><xref ref-type="aff" rid="a1"/></contrib>
        <contrib contrib-type="author" corresp="yes"><name><surname>Jones</surname><given-names>Bob</given-names></name><xref ref-type="aff" rid="a2"/></contrib>
        <contrib contrib-type="author"><name><surname>Wang</surname><given-names>Carol</given-names></name><xref ref-type="aff" rid="a2"/><xref ref-type="corresp" rid="c1"/></contrib>
        <contrib contrib-type="author"><name><surname>Last</surname><given-names>Dan</given-names></name></contrib>
        </contrib-group><aff id="a1"><label>1</label>University A</aff><aff id="a2"><label>2</label>University B</aff>
        <author-notes><corresp id="c1">Correspondence to Carol Wang</corresp></author-notes>
        </article-meta></front><back><ref-list><contrib-group><contrib contrib-type="author" corresp="yes"><string-name>Unrelated Author</string-name></contrib></contrib-group></ref-list></back></article>'''
        roles = jats_roles(page)
        self.assertEqual(roles['first_authors'], ['Alice Smith'])
        self.assertEqual(roles['corresponding_authors'], ['Bob Jones', 'Carol Wang'])
        info = public.article_info(page)
        self.assertEqual(info['corresponding_authors'], ['Bob Jones', 'Carol Wang'])
        self.assertEqual(info['authors'], ['Alice Smith','Bob Jones','Carol Wang','Dan Last'])
        self.assertEqual(info['author_affiliations'][0]['institutions'], ['University A'])

    def test_correspondence_meta_requires_an_exact_author_name(self):
        self.assertEqual(meta_correspondents({'citation_corresponding_author':['Bob; contact@example.com; Publisher']}, ['Alice','Bob']), ['Bob'])
        info = public.article_info(b'<meta name="citation_author" content="Alice"><meta name="citation_author" content="Bob"><meta name="citation_corresponding_author" content="Bob">')
        self.assertEqual(info['first_authors'], ['Alice'])
        self.assertEqual(info['corresponding_authors'], ['Bob'])


if __name__ == '__main__':
    unittest.main()
