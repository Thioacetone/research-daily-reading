"""Classification and cross-issue deduplication must preserve source identity."""
import unittest
from pathlib import Path
import tempfile

from paper_library import as_collection,build_paper_library,filter_papers,paper_direction,paper_type,publication_history,newest_first,reading_period,page_parameters,selected_paper,category_counts
from reading_view import article_cards
from tests.test_paper_classification import certified


def report(day,items):
    for item in items:
        if item.get('research_direction'):
            item.update(certified(item,item['research_direction']))
            if item['research_direction']=='protein-degradation':
                audit=item['classification_audit'];audit['abstract']='Targeted protein degradation by PROTAC molecules.'
                import hashlib
                audit['abstract_sha256']=hashlib.sha256(audit['abstract'].encode()).hexdigest()
    return {'day':day,'count':len(items),'saved_cards':['body:'+item['title'] for item in items],
            'report':{'sections':{'papers':{'items':items}}}}


class PaperLibraryTests(unittest.TestCase):
    def test_fine_topics_merge_without_losing_counts_or_changing_source_evidence(self):
        from paper_library import reader_direction
        from reading_policy import direction
        from paper_classification import classification_ready
        item=certified({'doi':'10.1234/grouping','paper_title':'Drug discovery through virtual screening'},'cadd-aidd')
        self.assertEqual(reader_direction(item),'medicinal')
        self.assertEqual(direction(item),'cadd-aidd')
        self.assertEqual(item['classification_audit']['direction'],'cadd-aidd')
        self.assertTrue(classification_ready(item))
        records=[{'type':'research','direction':k} for k in (
            'cadd-aidd','drug-discovery','neuropharmacology','protein-degradation',
            'bioorthogonal','chemical-probes','theoretical','electrochemistry','catalysis')]
        counts=category_counts(records,'direction')
        self.assertEqual({r['key']:r['count'] for r in counts},
                         {'all':9,'medicinal':3,'chemical-biology':3,'physical':3})
        self.assertEqual(len(filter_papers(records,direction='medicinal')),3)
        self.assertEqual(len(filter_papers(records,direction='protein-degradation')),3)
        self.assertEqual(sum(r['count'] for r in counts if r['key']!='all'),9)

    def test_every_reviewed_topic_has_one_broad_discipline_and_legacy_urls_still_work(self):
        from paper_library import DIRECTION_LABELS,DIRECTION_GROUPS,BROWSE_DIRECTIONS,browse_direction
        from paper_classification import registry
        self.assertEqual(set(DIRECTION_LABELS)-set(DIRECTION_GROUPS),set())
        for row in registry().values():
            self.assertIn(row['display_direction'],DIRECTION_GROUPS)
            self.assertIn(browse_direction(row['display_direction']),BROWSE_DIRECTIONS)
        self.assertEqual(page_parameters('archive',direction='cadd-aidd')['direction'],'medicinal')
        self.assertEqual(page_parameters('archive',direction='bioorthogonal')['direction'],'chemical-biology')
        self.assertEqual(page_parameters('archive',direction='theoretical')['direction'],'physical')
        self.assertEqual(page_parameters('archive',direction='untrusted')['direction'],'all')

    def test_category_pages_rank_by_count_and_keep_the_other_filter(self):
        records=[{'type':'research','direction':'chemical-biology'},
                 {'type':'research','direction':'chemical-biology'},
                 {'type':'review','direction':'chemical-biology'},
                 {'type':'research','direction':'cadd-aidd'},
                 {'type':'review','direction':'cadd-aidd'},
                 {'type':'review','direction':'organic'}]
        subjects=category_counts(records,'direction')
        self.assertEqual([(r['key'],r['count']) for r in subjects],
                         [('all',6),('chemical-biology',3),('medicinal',2),('organic',1)])
        kinds=category_counts(records,'type',direction='chemical-biology')
        self.assertEqual([(r['key'],r['count']) for r in kinds],[('all',3),('research',2),('review',1)])
        review_subjects=category_counts(records,'direction',kind='review',direction='organic')
        self.assertEqual(review_subjects[0]['count'],3)
        self.assertEqual({r['key'] for r in review_subjects},{'all','chemical-biology','medicinal','organic'})
        # Choosing a new direction replaces that axis, preserving the review filter.
        self.assertEqual(len(filter_papers(records,'review','cadd-aidd')),1)

    def test_category_index_counts_only_visible_archive_and_handles_empty_scope(self):
        records=[{'day':'2026-10-24','type':'research','direction':'organic'},
                 {'day':'2026-10-26','type':'review','direction':'organic'},
                 {'day':'2026-10-27','type':'review','direction':'cadd-aidd'}]
        archive=reading_period(records,'archive','2026-10-26')
        self.assertEqual([(r['key'],r['count']) for r in category_counts(archive,'type')],[('all',1),('research',1)])
        self.assertEqual(category_counts(archive,'direction',kind='review'),[{'key':'all','label':'全部方向','count':0}])
        with self.assertRaises(ValueError):category_counts(archive,'untrusted')

    def test_category_routes_are_independent_and_preserve_valid_filter_context(self):
        self.assertEqual(page_parameters('archive','review','organic',browse='direction'),
                         {'view':'archive','kind':'review','direction':'organic','browse':'direction'})
        self.assertEqual(page_parameters('archive','research','cadd-aidd',browse='type')['browse'],'type')
        self.assertNotIn('browse',page_parameters('today',browse='direction'))
        self.assertNotIn('browse',page_parameters('archive',browse='invalid'))
        paper=page_parameters('archive','review','organic','doi:10.1234/one',browse='direction')
        self.assertNotIn('browse',paper)
        self.assertEqual(paper['paper'],'doi:10.1234/one')

    def test_reader_refresh_tracks_publication_and_beijing_day_not_unused_candidates(self):
        from paper_library import published_signature
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);initial=published_signature(root,'2026-10-20')
            (root/'reading-candidates.json').write_text('{}')
            self.assertEqual(initial,published_signature(root,'2026-10-20'))
            (root/'reading-content.zip').write_bytes(b'new published report')
            changed=published_signature(root,'2026-10-20')
            self.assertNotEqual(initial,changed)
            self.assertNotEqual(changed,published_signature(root,'2026-10-21'))
    def test_normalized_doi_keeps_newest_body_and_metadata_together(self):
        old={'doi':'HTTPS://DOI.ORG/10.1234/ABC','title':'Old edition','kind':'研究论文'}
        new={'doi':'10.1234/abc','title':'New edition','recommendation_kind':'research','research_direction':'cadd-aidd'}
        records=build_paper_library([report('2026-10-01',[old]),report('2026-10-19',[new])])
        self.assertEqual(len(records),1)
        self.assertIs(records[0]['item'],new)
        self.assertEqual(records[0]['content'],'body:New edition')
        self.assertEqual(records[0]['direction'],'medicinal')
        self.assertEqual(records[0]['day'],'2026-10-01')
        self.assertEqual(reading_period(records,'today','2026-10-19'),[])

    def test_same_title_under_different_doi_retains_first_recommendation_day(self):
        old={'doi':'10.1234/a','paper_title':'A chemical discovery','title':'A chemical discovery'}
        new={'doi':'10.1234/b','paper_title':'A chemical discovery','title':'A chemical discovery'}
        records=build_paper_library([report('2026-10-15',[old]),report('2026-10-19',[new])])
        self.assertEqual(len(records),1)
        self.assertEqual(records[0]['day'],'2026-10-15')
        self.assertIs(records[0]['item'],new)

    def test_title_deduplication_when_doi_is_absent(self):
        a={'title':'A Study Of Ligands','kind':'研究论文'}
        b={'title':'a  study of ligands','kind':'研究论文'}
        self.assertEqual(len(build_paper_library([report('2026-10-19',[a,b])])),1)

    def test_explicit_classification_and_conservative_title_fallback(self):
        self.assertEqual(paper_type({'recommendation_kind':'review','kind':'研究论文'}),'review')
        self.assertEqual(paper_direction({'doi':'10.3389/fpsyt.2021.727117','paper_title':'Psychedelics and Other Psychoplastogens for Treating Mental Illness'}),'neuropharmacology')
        self.assertEqual(paper_direction({'title':'Unknown chemistry','future_directions':'Possible antidepressant applications'}),'other')
        self.assertEqual(paper_direction({'research_direction':'protein-degradation','title':'New approach'}),'other')

    def test_type_and_direction_filters_intersect(self):
        items=[{'title':'Review','recommendation_kind':'review','research_direction':'protein-degradation'},
               {'title':'Research','recommendation_kind':'research','research_direction':'protein-degradation'},
               {'title':'Docking','recommendation_kind':'research','research_direction':'cadd-aidd'}]
        records=build_paper_library([report('2026-10-19',items)])
        chosen=filter_papers(records,'research','protein-degradation')
        self.assertEqual([r['item']['title'] for r in chosen],['Research'])
        self.assertEqual(filter_papers(records,'review','cadd-aidd'),[])
        collection=as_collection(chosen)
        self.assertEqual(collection['saved_cards'],['body:Research'])
        self.assertIs(collection['report']['sections']['library']['items'][0],items[1])

    def test_incomplete_article_mapping_is_rejected(self):
        entry=report('2026-10-19',[{'title':'Paper'}])
        entry['saved_cards']=[]
        with self.assertRaises(ValueError):build_paper_library([entry])

    def test_website_date_survives_repackaging_but_content_change_updates_it(self):
        records=build_paper_library([report('2020-01-01',[{'title':'Paper','doi':'10.1234/paper'}])])
        first=publication_history(records,{},'2026-10-19')
        self.assertEqual(first['doi:10.1234/paper']['updated_on'],'2026-10-19')
        self.assertEqual(publication_history(records,first,'2026-10-20'),first)
        records[0]['content']+=' new interpretation'
        self.assertEqual(publication_history(records,first,'2026-10-20')['doi:10.1234/paper']['updated_on'],'2026-10-20')

    def test_today_priority_and_descending_website_date_survive_filter(self):
        reports=[report('2026-10-19',[{'title':'Recent report','doi':'10.1234/old','recommendation_kind':'review'}]),
                 report('2020-01-01',[{'title':'Older report','doi':'10.1234/new','recommendation_kind':'review'}])]
        history={'doi:10.1234/old':{'updated_on':'2026-10-18'},'doi:10.1234/new':{'updated_on':'2026-10-19'}}
        records=newest_first(build_paper_library(reports,history),'2026-10-19')
        self.assertEqual([r['item']['title'] for r in filter_papers(records,'review')],['Older report','Recent report'])
        self.assertEqual(as_collection(records)['paper_updates'],['2026-10-19','2026-10-18'])

    def test_doi_is_plain_text_and_website_date_is_at_the_end(self):
        entry=report('2001-01-01',[{'title':'Paper','doi':'https://doi.org/10.1234/ABC'}])
        entry['saved_cards']=['<h3>Paper</h3><p>Keep H<sub>2</sub>O and scientific text.</p><p><a href="https://doi.org/10.1234/ABC">Read original / 阅读原文</a><a href="https://example.org">Supporting source / 补充来源</a></p>']
        records=build_paper_library([entry],{'doi:10.1234/abc':{'updated_on':'2026-10-19'}})
        rendered=article_cards(as_collection(records))[0]
        self.assertNotIn('href="https://',rendered)
        self.assertNotIn('阅读原文',rendered)
        self.assertIn('DOI: <span class="reader-doi">10.1234/abc</span>',rendered)
        self.assertIn('datetime="2026-10-19"',rendered)
        self.assertIn('Keep H<sub>2</sub>O and scientific text.',rendered)
        self.assertGreater(rendered.index('Website updated'),rendered.index('scientific text'))

    def test_today_archive_uses_recommendation_date_not_bulk_upload_date(self):
        reports=[report('2026-10-19',[{'title':'Today','recommendation_kind':'research'}]),
                 report('2026-10-18',[{'title':'Archive','recommendation_kind':'review'}]),
                 report('2026-10-20',[{'title':'Future','recommendation_kind':'research'}])]
        records=build_paper_library(reports)
        for r in records:r['updated_on']='2026-10-19'
        self.assertEqual([r['item']['title'] for r in reading_period(records,'today','2026-10-19')],['Today'])
        archive=reading_period(records,'archive','2026-10-19')
        self.assertEqual([r['item']['title'] for r in archive],['Archive'])
        self.assertEqual(len(filter_papers(archive,'review')),1)
        self.assertEqual(filter_papers(archive,'research'),[])
        self.assertEqual(reading_period(records,'today','2026-10-21'),[])

    def test_today_offline_export_has_no_library_directory(self):
        from pathlib import Path
        from reading_view import standalone
        entry=as_collection(build_paper_library([report('2026-10-19',[{'title':'Today'}])]),'today','2026-10-19')
        entry['saved_cards']=['<h3>Today</h3><p>Complete paper content.</p>']
        page=standalone(entry,Path(__file__).resolve().parents[1]/'assets/program-art.jpg','')
        self.assertNotIn('class="reader-toc"',page)
        self.assertIn('TODAY’S READING',page)
        self.assertIn('返回顶部 ↑',page)
        self.assertIn('Complete paper content.',page)

    def test_directory_links_open_paper_route_and_preserve_filters(self):
        from reading_view import table_of_contents
        from html import unescape
        from urllib.parse import urlparse,parse_qs
        import re
        entry=as_collection(build_paper_library([report('2026-10-18',[{'title':'A review','doi':'10.1234/a&b','recommendation_kind':'review'}])]),'archive')
        entry.update(page_links=True,kind='review',direction='protein-degradation')
        rendered=table_of_contents(entry)
        href=unescape(re.search(r'href="([^"]+)"',rendered)[1])
        query=parse_qs(urlparse(href).query)
        self.assertEqual(query,{'view':['archive'],'kind':['review'],'direction':['chemical-biology'],'paper':['doi:10.1234/a&b']})
        self.assertIn('target="_self"',rendered)
        self.assertNotIn('#reading-paper-',rendered)

    def test_single_paper_page_contains_only_requested_paper(self):
        entries=[report('2026-10-18',[{'title':'One','doi':'10.1234/one'},{'title':'Two','doi':'10.1234/two'}]),
                 report('2026-10-20',[{'title':'Future','doi':'10.1234/future'}])]
        records=build_paper_library(entries)
        match=selected_paper(records,'doi:10.1234/two','archive','2026-10-19')
        detail=as_collection([match],'paper','2026-10-19')
        cards=article_cards(detail)
        self.assertEqual(len(cards),1)
        self.assertIn('body:Two',cards[0])
        self.assertNotIn('body:One',cards[0])
        self.assertNotIn('href="#reading-top"',cards[0])
        self.assertIsNone(selected_paper(records,'doi:10.1234/future','archive','2026-10-19'))
        self.assertIsNone(selected_paper(records,'missing','archive','2026-10-19'))
        self.assertEqual(page_parameters('invalid','invalid','invalid'),{'view':'today'})


if __name__=='__main__':
    unittest.main()
