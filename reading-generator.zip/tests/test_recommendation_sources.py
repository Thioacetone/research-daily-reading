from datetime import date
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from urllib.parse import parse_qs,urlsplit

import recommendation_sources as sources
import paper_recommendation as reading


def fulltext(doi='10.1371/journal.pcbi.1000001',kind='research-article'):
    paragraphs=''.join('<p>'+('A specific drug mechanism was tested with orthogonal controls and independent validation. '*15)+'</p>' for _ in range(5))
    return (f'<article article-type="{kind}"><front><journal-meta><journal-title>PLOS Computational Biology</journal-title></journal-meta>'
        f'<article-meta><article-id pub-id-type="doi">{doi}</article-id><title-group><article-title>Drug discovery study</article-title></title-group>'
        '<contrib-group><contrib contrib-type="author"><name><surname>Smith</surname><given-names>A</given-names></name><xref ref-type="aff" rid="a1"/></contrib></contrib-group>'
        '<aff id="a1">Department of Chemistry, University of Cambridge, United Kingdom</aff>'
        '</article-meta></front><body><sec><title>Results</title>'+paragraphs+'</sec></body></article>').encode()


def pubmed(types='Journal Article',doi='10.1234/example',journal='Nature Chemical Biology'):
    return (f'<PubmedArticleSet><PubmedArticle><MedlineCitation><Article><Journal><Title>{journal}</Title></Journal>'
        '<ArticleTitle>Covalent ligand study</ArticleTitle><PublicationTypeList>'
        +''.join(f'<PublicationType>{t}</PublicationType>' for t in types.split('|'))+
        f'</PublicationTypeList></Article></MedlineCitation><PubmedData><ArticleIdList><ArticleId IdType="doi">{doi}</ArticleId>'
        '<ArticleId IdType="pmc">PMC123</ArticleId></ArticleIdList></PubmedData></PubmedArticle></PubmedArticleSet>').encode()


class SourceTests(unittest.TestCase):
    def test_pubmed_checks_publication_kind_journal_and_retractions(self):
        rows=sources.pubmed_rows(pubmed(),'research',set(),'chemical-probes')
        self.assertEqual(rows[0]['pmcid'],'PMC123')
        self.assertEqual(rows[0]['discovery_sources'],['PubMed'])
        for bad in ('Journal Article|Retracted Publication','Editorial','Preprint','Review'):
            self.assertEqual(sources.pubmed_rows(pubmed(bad),'research',set(),'chemical-probes'),[])
        self.assertEqual(sources.pubmed_rows(pubmed(journal='Unknown Journal'),'research',set(),'chemical-probes'),[])
        self.assertEqual(sources.pubmed_rows(pubmed(),'research',{'10.1234/example'},'chemical-probes'),[])
        self.assertTrue(sources.pubmed_rows(pubmed('Systematic Review'),'review',set(),'chemical-probes'))

    def test_crossref_never_qualifies_metadata_alone_and_excludes_nonpapers(self):
        valid={'DOI':'10.1234/example','title':['A drug mechanism study'],'container-title':['ACS Chemical Biology'],'type':'journal-article'}
        for change in ({'type':'posted-content'},{'title':['Correction: study']},
                       {'container-title':['Unknown Journal']},{'update-to':[{'type':'retraction'}]},
                       {'DOI':'10.1101/2026.01.01.123456'},{'relation':{'is-retracted-by':[{'id':'10.1234/retraction'}]}}):
            self.assertEqual(sources.crossref_rows([{**valid,**change}],set(),'drug-discovery'),[])
        candidate=sources.crossref_rows([valid],set(),'drug-discovery')[0]
        self.assertFalse(reading.complete_item(candidate))
        self.assertNotIn('fulltext_verified',candidate)

    def test_independent_sources_interleave_and_merge_doi_provenance(self):
        lanes=[[{'doi':'10.1234/a','pmcid':'','discovery_sources':['Crossref']},{'doi':'10.1234/d'}],
               [{'doi':'10.1234/b','discovery_sources':['PubMed']},{'doi':'10.1234/A','pmcid':'PMC123','discovery_sources':['PubMed']}],
               [{'doi':'10.1234/c','discovery_sources':['Europe PMC']}]]
        result=sources.interleave(lanes)
        self.assertEqual([r['doi'] for r in result],['10.1234/a','10.1234/b','10.1234/c','10.1234/d'])
        self.assertEqual(result[0]['discovery_sources'],['Crossref','PubMed'])
        self.assertEqual(result[0]['pmcid'],'PMC123')
        self.assertEqual(lanes[0][0]['pmcid'],'')  # do not mutate input pools

    def test_index_outage_does_not_disable_other_sources(self):
        with patch.object(reading,'discover_europe_pmc',return_value=[{'doi':'10.1234/epmc'}]), \
             patch.object(sources,'read_json',side_effect=OSError('unavailable')):
            result=reading.discover_candidates('research',set(),date(2026,10,10))
        self.assertEqual([r['doi'] for r in result],['10.1234/epmc'])

    def test_publisher_fulltext_without_pmc_must_match_doi_and_have_body(self):
        doi='10.1371/journal.pcbi.1000001'
        item,paragraphs,_=reading.parse_fulltext(fulltext(),expected_doi=doi)
        self.assertTrue(item['fulltext_verified']);self.assertGreater(len(paragraphs),4)
        self.assertEqual(item['pmcid'],'')
        self.assertIn('Department of Chemistry',item['institutions'][0])
        for data in (fulltext('10.1371/journal.pcbi.1000002'),fulltext(kind='article-commentary'),
                     fulltext().replace(b'<body>',b'<abstract>').replace(b'</body>',b'</abstract>')):
            with self.assertRaises(reading.RecommendationError):reading.parse_fulltext(data,expected_doi=doi)
        with self.assertRaises(reading.RecommendationError):reading.parse_fulltext(fulltext())
        for doi in ('10.1101/2026.01.01.123456','10.7554/elife.123456.1'):
            with self.assertRaises(reading.RecommendationError):reading.parse_fulltext(fulltext(doi),expected_doi=doi)

    def test_publisher_reader_works_during_index_outage_and_revalidates_cache(self):
        doi='10.1371/journal.pcbi.1000001'
        with tempfile.TemporaryDirectory() as tmp,patch.object(sources,'resolve_pmc',side_effect=OSError()), \
             patch.object(sources,'read_bytes',return_value=fulltext()) as fetch:
            candidate={'doi':doi,'discovery_sources':['Crossref']}
            item,_,_=reading.load_candidate_fulltext(tmp,candidate)
            again,_,_=reading.load_candidate_fulltext(tmp,candidate)
            self.assertEqual(item['fulltext_sha256'],again['fulltext_sha256'])
            self.assertEqual(item['discovery_sources'],['Crossref'])
            self.assertEqual(item['fulltext_url'],'https://doi.org/'+doi)
            self.assertEqual(fetch.call_count,1)
            cache=next((Path(tmp)/'data/recommendation-fulltext').glob('*.xml'))
            cache.write_bytes(fulltext('10.1371/journal.pcbi.1000002'))
            with self.assertRaises(reading.RecommendationError):reading.load_candidate_fulltext(tmp,candidate)

    def test_known_retraction_cannot_fall_back_to_publisher(self):
        with patch.object(sources,'resolve_pmc',side_effect=ValueError('retracted')),patch.object(sources,'read_bytes') as fetch:
            with self.assertRaises(ValueError):reading.load_candidate_fulltext('.',{'doi':'10.1371/journal.pcbi.1000001'})
            fetch.assert_not_called()

    def test_exact_doi_resolver_rejects_wrong_identity_and_retractions(self):
        with patch.object(sources,'read_json',return_value={'resultList':{'result':[{'doi':'10.1234/other','pmcid':'PMC123'}]}}):
            self.assertEqual(sources.resolve_pmc('10.1234/example'),'')
        with patch.object(sources,'read_json',return_value={'resultList':{'result':[{'doi':'10.1234/example','pmcid':'PMC123','isRetracted':'Y'}]}}):
            with self.assertRaises(ValueError):sources.resolve_pmc('10.1234/example')

    def test_publisher_route_is_constrained_to_known_journals(self):
        self.assertTrue(sources.plos_fulltext_url('10.1371/journal.pcbi.1000001').startswith('https://journals.plos.org/ploscompbiol/'))
        for doi in ('10.1371/journal.pone.1234','10.1234/https://evil.example','garbage'):
            self.assertEqual(sources.plos_fulltext_url(doi),'')

    def test_new_indexes_page_past_already_recommended_papers(self):
        offsets=[]
        def pub_search(url):
            offset=int(parse_qs(urlsplit(url).query)['retstart'][0]);offsets.append(offset)
            return {'esearchresult':{'idlist':['used' if not offset else 'new']*40}}
        def pub_fetch(url):
            ids=parse_qs(urlsplit(url).query)['id'][0]
            records=[pubmed(doi='10.1234/used' if 'used' in ids else f'10.1234/new-{i}').decode() for i in range(8)]
            return ('<PubmedArticleSet>'+''.join(r.removeprefix('<PubmedArticleSet>').removesuffix('</PubmedArticleSet>') for r in records)+'</PubmedArticleSet>').encode()
        with patch.object(sources,'THEMES',sources.THEMES[:1]),patch.object(sources,'read_json',side_effect=pub_search), \
             patch.object(sources,'read_bytes',side_effect=pub_fetch):
            rows=sources.discover_pubmed('research',{'10.1234/used'},date(2026,10,10))
        self.assertEqual(offsets,[0,40,0,40]);self.assertEqual(len(rows),8)
        offsets=[]
        def crossref_search(url):
            offset=int(parse_qs(urlsplit(url).query)['offset'][0]);offsets.append(offset)
            rows=[{'DOI':'10.1234/used' if not offset else f'10.1234/new-{i}',
                   'type':'journal-article','title':['Drug design'],'container-title':['Nature Chemical Biology']}
                  for i in range(60 if not offset else 8)]
            return {'message':{'items':rows}}
        with patch.object(sources,'THEMES',sources.THEMES[:1]),patch.object(sources,'read_json',side_effect=crossref_search):
            rows=sources.discover_crossref('research',{'10.1234/used'},date(2026,10,10))
        self.assertEqual(offsets,[0,60,0,60]);self.assertEqual(len(rows),8)

    def test_publisher_only_paper_can_be_reserved_and_rebuilt_with_a_valid_source_link(self):
        import daily_digest as digest
        root=Path(__file__).resolve().parents[1]
        item={**reading.load_catalog(root)[0],'doi':'10.1371/journal.pcbi.1000001','pmcid':'',
              'fulltext_url':'https://doi.org/10.1371/journal.pcbi.1000001','discovery_sources':['PubMed','Crossref']}
        with tempfile.TemporaryDirectory() as tmp,patch.object(reading,'load_catalog',return_value=[]), \
             patch.object(reading,'store_from_environment',return_value=None),patch.object(digest,'ROOT',Path(tmp)), \
             patch.object(reading,'discover_candidates',return_value=[{'doi':item['doi'],'pmcid':''}]), \
             patch.object(reading,'load_candidate_fulltext',return_value=(item,[],'')), \
             patch('recommendation_writer.DeepReadingWriter') as writer:
            writer.return_value.analyze.return_value=item
            target=date(2026,10,12) # delivery Tuesday
            prepared=reading.build_report(tmp,{},target,reserve=True)
            rebuilt=reading.build_report(tmp,{},target,reserve=False)
            self.assertEqual(prepared['sections'][reading.TOPIC]['items'],rebuilt['sections'][reading.TOPIC]['items'])
            saved=reading.ReadingLedger(tmp).read()[0][target.isoformat()]['papers'][0]
            self.assertEqual(saved['pmcid'],'');self.assertEqual(saved['discovery_sources'],['PubMed','Crossref'])
            self.assertEqual(rebuilt['sections'][reading.TOPIC]['sources'][1]['url'],item['fulltext_url'])


if __name__=='__main__':unittest.main()
