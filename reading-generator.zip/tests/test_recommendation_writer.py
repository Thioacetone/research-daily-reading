import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import MagicMock,patch

from recommendation_writer import DeepReadingWriter


class WriterRecoveryTests(unittest.TestCase):
    def test_repeating_sentences_cannot_inflate_a_deep_reading(self):
        from paper_recommendation import repetitive_narrative
        first='该方法通过不同浓度的探针对天然蛋白质组进行定量反应性比较，并分析丰度与内在反应性的影响。'
        second='作者还用功能实验验证候选位点，明确反应性优先级与实际生物学功能之间需要逐一检验的关系。'
        self.assertFalse(repetitive_narrative(first+second))
        self.assertTrue(repetitive_narrative(first+'\\n\\n'+first+second))
    def test_wrong_language_is_repaired_without_repeating_passed_metadata(self):
        item={'doi':'10.1234/test','fulltext_sha256':'a'*64,'paper_title':'Original title','recommendation_kind':'research'}
        classifier={'focus':'An original chemistry investigation with controlled experiments.','research_direction':'organic','evidence_ids':['p1','p2']}
        judgement={'assessment':'The original study uses carefully matched controls to separate competing mechanistic explanations. '*3,
                   'research_direction':'organic','related':True,'substantive':True,'not_routine':True,'criteria':[3],'evidence_ids':['p1','p2','p3']}
        labels=['反应性','蛋白质组','同位素','质谱','浓度梯度','功能验证','亲电探针','细胞环境','选择性','实验对照','动力学','结构设计','方法迁移','机制解释','后续研究','溶剂效应','反应中间体','底物范围','温度效应','分析灵敏度','检出限','体外模型']
        chinese='我的归纳是，这种设计将化学反应性作为验证机制的线索。'+''.join('作者围绕'+label+'设计独立实验，通过比较条件分析不同机制，并说明证据支持的结论及进一步验证的边界。' for label in labels)
        bad={'text':'This is an English analysis of the supplied chemistry paper. '*20,'evidence_ids':['p1','p2','p3']}
        good={'text':chinese,'evidence_ids':['p1','p2','p3']}
        with (tempfile.TemporaryDirectory() as folder,
              patch('affiliation_sources.units_complete',return_value=True),
              patch('recommendation_writer.valid_title',return_value=True),
              patch('recommendation_writer.complete_item',return_value=True)):
            writer=DeepReadingWriter(folder)
            with (patch.object(writer,'evidence_pack',return_value=('Read evidence',{'p1','p2','p3'})),
                  patch.object(writer,'generate',side_effect=[classifier,judgement,{'title_zh':'原题','units':{}},bad]+[good]*6) as generate):
                result=writer.analyze(item,[{'id':'p'+str(n),'text':'Original controlled chemistry evidence and independent mechanistic experiments. '+str(n)} for n in range(1,4)],'')
            self.assertEqual(result['action'],chinese)
            self.assertIn('Simplified Chinese',generate.call_args_list[4].args[0])
            diagnostic=json.loads(next((Path(folder)/'data/recommendation-analysis/diagnostics').rglob('action-1.json')).read_text(encoding='utf-8'))
            self.assertIn('英文正文',diagnostic['issue'])
            with patch.object(writer,'generate') as generate:
                self.assertEqual(writer.analyze(item,[{'id':'p'+str(n),'text':'Original controlled chemistry evidence and independent mechanistic experiments. '+str(n)} for n in range(1,4)],''),result)
                generate.assert_not_called()

    def test_truncated_json_retries_with_larger_budget_and_never_accepts_broken_text(self):
        module=types.SimpleNamespace(LlamaGrammar=MagicMock())
        with tempfile.TemporaryDirectory() as folder,patch.dict('sys.modules',{'llama_cpp':module}):
            writer=DeepReadingWriter(folder);writer.model=MagicMock()
            writer.model.tokenize.return_value=[0]*100
            writer.model.side_effect=[{'choices':[{'text':'{"text":"unfinished'}]},
                                      {'choices':[{'text':'{"text":"Complete text"}'}]}]
            self.assertEqual(writer.generate('Translate','Source',{'text':{'type':'string'}},100),{'text':'Complete text'})
            calls=writer.model.call_args_list
            self.assertIn('Required JSON schema',calls[0].args[0])
            self.assertIn('"required": ["text"]',calls[0].args[0])
            self.assertGreater(calls[1].kwargs['max_tokens'],calls[0].kwargs['max_tokens'])
            writer.model.side_effect=[{'choices':[{'text':'{"text":'}]}]*2
            with self.assertRaises(json.JSONDecodeError):writer.generate('Translate','Source',{},100)

    def test_valid_negative_editorial_decision_is_not_prompted_into_acceptance(self):
        item={'doi':'10.1234/test','fulltext_sha256':'a'*64,'paper_title':'Original title','recommendation_kind':'research'}
        judgement={'assessment':'A concrete assessment of the provided original evidence and its scientific contribution. '*3,
                   'related':False,'substantive':True,'not_routine':False,'criteria':[],
                   'research_direction':'organic','evidence_ids':['p1','p2','p3']}
        with tempfile.TemporaryDirectory() as folder,patch('affiliation_sources.units_complete',return_value=True):
            writer=DeepReadingWriter(folder)
            classifier={'focus':'A concrete study of organic chemistry with experimentally testable questions.','research_direction':'organic','evidence_ids':['p1','p2']}
            with (patch.object(writer,'evidence_pack',return_value=('Body',{'p1','p2','p3'})),
                  patch.object(writer,'generate',side_effect=[classifier,judgement,classifier,judgement]) as generate):
                self.assertIsNone(writer.analyze(item,[{'id':'p'+str(n),'text':'Original controlled chemistry evidence and independent mechanistic experiments. '+str(n)} for n in range(1,4)],''));self.assertEqual(generate.call_count,2)
                self.assertEqual(writer.last_rejection,'editorial_judgement')
                pending=next((Path(folder)/'data/recommendation-analysis').glob('*.pending.json'))
                pending.with_name(pending.name.replace('.pending.json','.json')).write_text('{interrupted',encoding='utf-8')
                self.assertIsNone(writer.analyze(item,[{'id':'p'+str(n),'text':'Original controlled chemistry evidence and independent mechanistic experiments. '+str(n)} for n in range(1,4)],''));self.assertEqual(generate.call_count,2)
                changed={**item,'fulltext_sha256':'b'*64}
                self.assertIsNone(writer.analyze(changed,[],''));self.assertEqual(generate.call_count,4)


if __name__=='__main__':unittest.main()
