import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import MagicMock,patch

from recommendation_writer import DeepReadingWriter


class WriterRecoveryTests(unittest.TestCase):
    def test_truncated_json_retries_with_larger_budget_and_never_accepts_broken_text(self):
        module=types.SimpleNamespace(LlamaGrammar=MagicMock())
        with tempfile.TemporaryDirectory() as folder,patch.dict('sys.modules',{'llama_cpp':module}):
            writer=DeepReadingWriter(folder);writer.model=MagicMock()
            writer.model.tokenize.return_value=[0]*100
            writer.model.side_effect=[{'choices':[{'text':'{"text":"unfinished'}]},
                                      {'choices':[{'text':'{"text":"Complete text"}'}]}]
            self.assertEqual(writer.generate('Translate','Source',{'text':{'type':'string'}},100),{'text':'Complete text'})
            calls=writer.model.call_args_list
            self.assertIn('Required JSON schema',calls[0].args[0])
            self.assertIn('"required": ["text"]',calls[0].args[0])
            self.assertGreater(calls[1].kwargs['max_tokens'],calls[0].kwargs['max_tokens'])
            writer.model.side_effect=[{'choices':[{'text':'{"text":'}]}]*2
            with self.assertRaises(json.JSONDecodeError):writer.generate('Translate','Source',{},100)

    def test_valid_negative_editorial_decision_is_not_prompted_into_acceptance(self):
        item={'doi':'10.1234/test','fulltext_sha256':'a'*64,'paper_title':'Original title','recommendation_kind':'research'}
        judgement={'assessment':'A concrete assessment of the provided original evidence and its scientific contribution. '*3,
                   'related':False,'substantive':True,'not_routine':False,'criteria':[],
                   'research_direction':'organic','evidence_ids':['p1','p2','p3']}
        with tempfile.TemporaryDirectory() as folder,patch('affiliation_sources.units_complete',return_value=True):
            writer=DeepReadingWriter(folder)
            classifier={'focus':'A concrete study of organic chemistry with experimentally testable questions.','research_direction':'organic'}
            with (patch.object(writer,'evidence_pack',return_value=('Body',{'p1','p2','p3'})),
                  patch.object(writer,'generate',side_effect=[classifier,judgement,classifier,judgement]) as generate):
                self.assertIsNone(writer.analyze(item,[],''));self.assertEqual(generate.call_count,2)
                self.assertEqual(writer.last_rejection,'editorial_judgement')
                self.assertIsNone(writer.analyze(item,[],''));self.assertEqual(generate.call_count,2)
                changed={**item,'fulltext_sha256':'b'*64}
                self.assertIsNone(writer.analyze(changed,[],''));self.assertEqual(generate.call_count,4)


if __name__=='__main__':unittest.main()
