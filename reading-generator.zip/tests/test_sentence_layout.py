import copy
import unittest
from unittest.mock import Mock,patch

import bilingual_mail as b
from reading_view import article_cards


class SentenceLayoutTests(unittest.TestCase):
    def test_scientific_sentence_boundaries(self):
        text='Dr. A. Smith et al. used 2.5 mg, e.g. Fe³⁺ (see Fig. 2), etc. in the U.S. laboratory. CO₂ was retained.'
        self.assertEqual(b.english_sentences(text),[text.rsplit(' CO₂',1)[0],'CO₂ was retained.'])
        self.assertEqual(b.chinese_sentences('结果是“有效。”仍需验证！'),['结果是“有效。”','仍需验证！'])

    def test_unequal_pairs_are_never_zipped_or_truncated(self):
        en='First result. Second result.'
        self.assertIsNone(b.sentence_pairs(en,'第一项结果及第二项结果。'))
        translator=Mock();translator.translate.side_effect=['第一项结果。','第二项结果。']
        pairs=b.sentence_pairs(en,'第一项结果及第二项结果。',translator)
        self.assertEqual(len(pairs),2)
        self.assertTrue(b.valid_sentence_pairs(en,pairs))
        self.assertEqual(translator.translate.call_count,2)

    def test_numeric_misalignment_is_not_accepted(self):
        self.assertIsNone(b.sentence_pairs('The dose was 2 mg. It rose to 3 mg.','剂量为3 mg。后来增至2 mg。'))
        self.assertFalse(b.valid_sentence_pairs('Keep CO₂.',[{'en':'Keep CO₂.','zh':'保留NO₂。'}]))

    def test_incomplete_or_reordered_saved_pairs_are_rejected(self):
        en='Keep Fe³⁺. Keep CO₂.'
        pairs=b.sentence_pairs(en,'保留Fe³⁺。保留CO₂。')
        self.assertTrue(b.valid_sentence_pairs(en,pairs))
        self.assertFalse(b.valid_sentence_pairs(en,pairs[:1]))
        self.assertFalse(b.valid_sentence_pairs(en,list(reversed(pairs))))

    def test_reader_reflows_legacy_content_and_preserves_chemistry(self):
        field={'label_en':'Study overview','label_zh':'内容概括','en':'Keep Fe³⁺. Keep CO₂.',
               'zh':'保留Fe³⁺。保留CO₂。'}
        body="<h4>Study overview <span>内容概括</span></h4><div>old paragraph</div>"
        item={'title':'Example','doi':'10.1234/example','venue':'Journal','bilingual':{'fields':[field]}}
        entry={'count':1,'saved_cards':[body],'report':{'sections':{'papers':{'items':[item]}}}}
        result=article_cards(entry)[0]
        self.assertEqual(result.count('class="reader-sentence-pair"'),2)
        self.assertLess(result.index('Keep Fe'),result.index('保留Fe'))
        self.assertLess(result.index('保留Fe'),result.index('Keep CO'))
        self.assertIn('<sup>',result);self.assertIn('<sub>',result)
        self.assertNotIn('old paragraph',result)


if __name__=='__main__':unittest.main()
