import unittest
from reading_policy import (choose_daily,validate_daily,identity_keys,PolicyError,
                            DIRECTIONS,QUERIES,history_identities)


def item(index,lane):
    return {'doi':f'10.1234/{index}','paper_title':f'Original chemistry study {index}',
            'research_direction':lane,'recommendation_kind':'research'}


def pool():
    return [item(i,lane) for i,lane in enumerate(DIRECTIONS)]


class DailyPolicyTests(unittest.TestCase):
    def test_ten_papers_five_priority_max_three_and_wide_breadth(self):
        chosen=choose_daily(pool())
        audit=validate_daily(chosen)
        self.assertEqual(audit['papers'],10)
        self.assertGreaterEqual(audit['priority_papers'],5)
        self.assertLessEqual(max(audit['directions'].values()),3)
        self.assertEqual(len(audit['directions']),10)

    def test_old_doi_and_same_title_are_both_excluded(self):
        candidates=pool()+[item(100+i,lane) for i,lane in enumerate(DIRECTIONS)]
        old=item(0,'chemical-biology');old['doi']='https://doi.org/10.1234/0'
        used=identity_keys(old)
        candidates.insert(0,{**old,'doi':'10.1234/different-doi'})
        chosen=choose_daily(candidates,used)
        self.assertFalse(any(identity_keys(i)&used for i in chosen))
        with self.assertRaises(PolicyError):validate_daily([old]+chosen[:9],used)

    def test_several_biological_labels_cannot_bypass_same_direction_cap(self):
        candidates=[item(i,lane) for i,lane in enumerate(
            ['bioorthogonal','chemical-probes','protein-degradation','chemical-biology']*3)]
        candidates += [item(100+i,lane) for i,lane in enumerate(['organic','physical','materials','polymer','analytical','energy'])]
        with self.assertRaises(PolicyError):choose_daily(candidates)

    def test_reject_short_batch_and_insufficient_preferred_scope(self):
        with self.assertRaises(PolicyError):choose_daily(pool()[:9])
        with self.assertRaises(PolicyError):validate_daily(pool()[5:15])

    def test_editorial_quality_gate_never_accepts_metadata_only(self):
        for i in pool():i['qualified']=False
        with self.assertRaises(PolicyError):choose_daily(pool(),quality_check=lambda i:i.get('qualified',False))

    def test_all_historical_days_contribute_to_identity_history(self):
        report={'recommendation_date':'2026-10-15','sections':{'papers':{'items':[item(1,'cadd-aidd')]}}}
        used=history_identities([report])
        self.assertIn('doi:10.1234/1',used)
        self.assertEqual(history_identities([report],except_day='2026-10-15'),set())

    def test_sources_cover_every_declared_chemical_branch(self):
        self.assertEqual(set(QUERIES),set(DIRECTIONS))
        for lane in ('organic','inorganic','physical','analytical','polymer','nuclear','geochemistry'):
            self.assertTrue(QUERIES[lane])


if __name__=='__main__':unittest.main()
