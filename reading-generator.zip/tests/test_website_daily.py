import json
from pathlib import Path
import tempfile
import unittest

from website_daily import history,combine,already_published
from reading_policy import PolicyError


class WebsitePublicationTests(unittest.TestCase):
    def test_history_survives_report_replacement(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            (root/'reading-history.json').write_text(json.dumps({'doi:10.1234/old':'2026-10-15'}))
            _,saved=history(root)
            self.assertEqual(saved['doi:10.1234/old'],'2026-10-15')

    def test_empty_or_incomplete_pool_cannot_overwrite_a_report(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);pool=root/'pool';pool.mkdir()
            (pool/'candidates.json').write_text(json.dumps({'day':'2026-10-19','items':[]}))
            with self.assertRaises(PolicyError):combine(root,'2026-10-19',pool)
            self.assertFalse((root/'data/paper-recommendation').exists())
            self.assertFalse((root/'reading-history.json').exists())

    def test_legacy_three_paper_copy_is_not_treated_as_complete_new_issue(self):
        root=Path(__file__).resolve().parents[1]
        self.assertFalse(already_published(root,'2026-10-19'))


if __name__=='__main__':unittest.main()
