import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch,MagicMock
from zipfile import ZipFile
from cloud_bundle import ensure_bundled_files

from website_daily import history,combine,already_published,worker,discover
from reading_policy import PolicyError


class WebsitePublicationTests(unittest.TestCase):
    def test_unreadable_metadata_does_not_exhaust_editorial_budget(self):
        rows=[{'doi':f'10.1234/unavailable-{i}'} for i in range(12)]
        candidate={'doi':'10.1234/readable','title':'A worthwhile chemistry paper'}
        rows.append(candidate)
        analyzed={**candidate,'research_direction':'organic','venue':'Verified journal'}
        writer=MagicMock();writer.analyze.return_value=analyzed
        registry=MagicMock();registry.match.return_value={'title':'Verified journal'}
        def read(root,item):
            if item['doi']!=candidate['doi']:raise OSError('unavailable')
            return analyzed,[],''
        with tempfile.TemporaryDirectory() as folder:
            destination=Path(folder)/'pool.json'
            with (patch('website_daily.history',return_value=([],{})),
                  patch('website_daily.discover',return_value=rows),
                  patch('website_daily.prepare_item',side_effect=lambda root,item,*a:item),
                  patch('paper_recommendation.load_catalog',return_value=[]),
                  patch('paper_recommendation.load_candidate_fulltext',side_effect=read),
                  patch('paper_recommendation.complete_item',return_value=True),
                  patch('recommendation_writer.DeepReadingWriter',return_value=writer),
                  patch('journal_discovery.JournalRegistry.load',return_value=registry)):
                worker(Path(folder),'organic','2026-10-20',destination)
            pool=json.loads(destination.read_text(encoding='utf-8'))
            self.assertEqual(pool['items'],[analyzed])
            self.assertEqual(pool['diagnostics']['fulltext_failed'],12)
            self.assertEqual(pool['diagnostics']['editorial_attempts'],1)

    def test_editorial_references_are_constrained_to_read_paragraphs(self):
        from recommendation_writer import DeepReadingWriter
        with tempfile.TemporaryDirectory() as folder:
            writer=DeepReadingWriter(folder)
            evidence={'p1','p2','p3'}
            with (patch.object(writer,'evidence_pack',return_value=('Read evidence',evidence)),
                  patch.object(writer,'generate',return_value={
                      'related':True,'substantive':True,'not_routine':True,
                      'criteria':[2],'evidence_ids':['p1','p2','invented']}) as generate):
                result=writer.analyze({'doi':'10.1234/test','fulltext_sha256':'a'*64,
                                      'paper_title':'Original title','recommendation_kind':'research'},[],'')
            self.assertIsNone(result)
            self.assertEqual(writer.last_rejection,'judgement_evidence_references')
            self.assertEqual(set(generate.call_args.args[2]['evidence_ids']['items']['enum']),evidence)

    def test_index_outage_is_audited_separately_from_zero_qualified_papers(self):
        audit={}
        with (patch('journal_discovery.JournalRegistry.load',return_value=MagicMock()),
              patch('recommendation_sources.read_json',side_effect=OSError('unavailable'))):
            self.assertEqual(discover(Path('.'),'catalysis',set(),'2026-10-20',audit=audit),[])
        for name in ('Europe PMC','Crossref','PubMed'):
            self.assertGreater(audit[name]['failures'],0)

    def test_valid_cross_direction_discovery_is_kept_for_global_quotas(self):
        # A catalysis query may find a valuable organic synthesis paper.
        # The final 10/5/3 selector must decide the quota, not the query label.
        candidate={'doi':'10.1234/cross-direction','title':'Original synthesis paper'}
        analyzed={**candidate,'research_direction':'organic','venue':'Verified journal'}
        writer=MagicMock();writer.analyze.return_value=analyzed
        registry=MagicMock();registry.match.return_value={'title':'Verified journal'}
        with tempfile.TemporaryDirectory() as folder:
            destination=Path(folder)/'pool.json'
            with (patch('website_daily.history',return_value=([],{})),
                  patch('website_daily.discover',return_value=[candidate]),
                  patch('website_daily.prepare_item',side_effect=lambda root,item,*a:item),
                  patch('paper_recommendation.load_catalog',return_value=[]),
                  patch('paper_recommendation.load_candidate_fulltext',return_value=(analyzed,[],'')),
                  patch('paper_recommendation.complete_item',return_value=True),
                  patch('recommendation_writer.DeepReadingWriter',return_value=writer),
                  patch('journal_discovery.JournalRegistry.load',return_value=registry),
                  patch.dict('os.environ',{'GITHUB_STEP_SUMMARY':str(Path(folder)/'summary.md')})):
                worker(Path(folder),'catalysis','2026-10-20',destination)
            pool=json.loads(destination.read_text(encoding='utf-8'))
            self.assertEqual(pool['items'],[analyzed])
            self.assertEqual(pool['diagnostics']['qualified'],1)
            self.assertIn('(organic)',(Path(folder)/'summary.md').read_text(encoding='utf-8'))

    def test_source_archive_coexists_with_data_without_being_unpacked(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            with ZipFile(root/'reading-generator.zip','w') as bundle:
                bundle.writestr('executable.py','raise RuntimeError("must not be unpacked by the reader")')
            with ZipFile(root/'reading-content.zip','w') as bundle:
                bundle.writestr('data/paper-recommendation/2026-10-18/marker.json','{}')
            ensure_bundled_files(root)
            self.assertFalse((root/'executable.py').exists())
            self.assertTrue((root/'data/paper-recommendation/2026-10-18/marker.json').exists())
            with ZipFile(root/'reading-content.zip','w') as bundle:
                bundle.writestr('../unexpected.py','not allowed')
            with self.assertRaises(ValueError):ensure_bundled_files(root)

    def test_history_survives_report_replacement(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            (root/'reading-history.json').write_text(json.dumps({'doi:10.1234/old':'2026-10-15'}))
            _,saved=history(root)
            self.assertEqual(saved['doi:10.1234/old'],'2026-10-15')

    def test_empty_or_incomplete_pool_cannot_overwrite_a_report(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);pool=root/'pool';pool.mkdir()
            (pool/'candidates.json').write_text(json.dumps({'day':'2026-10-19','items':[]}))
            with self.assertRaises(PolicyError):combine(root,'2026-10-19',pool)
            self.assertFalse((root/'data/paper-recommendation').exists())
            self.assertFalse((root/'reading-history.json').exists())

    def test_legacy_three_paper_copy_is_not_treated_as_complete_new_issue(self):
        root=Path(__file__).resolve().parents[1]
        self.assertFalse(already_published(root,'2026-10-19'))


if __name__=='__main__':unittest.main()
