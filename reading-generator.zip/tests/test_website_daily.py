import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch,MagicMock
from zipfile import ZipFile
from datetime import date
from cloud_bundle import ensure_bundled_files

from website_daily import history,combine,already_published,worker,discover,collect_candidates,candidate_bank,prepare_item,preflight_state,requested_day,automatic_day,release_window
from reading_policy import PolicyError


class WebsitePublicationTests(unittest.TestCase):
    def test_preflight_cli_exports_numeric_inventory_as_cloud_output_text(self):
        from website_daily import main
        from datetime import datetime
        from website_daily import BJ
        day=datetime.now(BJ).date().isoformat()
        state={'day':day,'run':'true','generate':'false','lanes':'[]','available':14,'priority_available':6}
        with tempfile.TemporaryDirectory() as folder,patch('sys.argv',['website_daily.py','preflight','--date',day]),patch('website_daily.preflight_state',return_value=state),patch.dict('os.environ',{'GITHUB_OUTPUT':str(Path(folder)/'outputs')}):
            main()
            outputs=(Path(folder)/'outputs').read_text()
            self.assertIn('available=14',outputs)
            self.assertIn('priority_available=6',outputs)

    def test_release_cli_exports_partial_publication_outputs_for_cloud_packaging(self):
        from website_daily import main
        with tempfile.TemporaryDirectory() as folder,patch('sys.argv',['website_daily.py','release','--date','2026-10-26']),patch('website_daily.release_window',return_value={'today_ready':True,'published_now':['2026-10-26']}),patch('website_daily.already_published',return_value=True),patch.dict('os.environ',{'GITHUB_OUTPUT':str(Path(folder)/'outputs')}):
            main()
            outputs=(Path(folder)/'outputs').read_text()
            self.assertIn('published=true',outputs)
            self.assertIn('target_ready=true',outputs)

    def test_retries_fill_the_binding_priority_deficit_not_all_twenty_lanes(self):
        lanes=['chemical-biology','cadd-aidd','drug-discovery','interdisciplinary']+['organic','inorganic','physical','polymer','analytical','catalysis']*2
        bank=[{'doi':f'10.1234/deficit-{n}','paper_title':f'Candidate {n}','research_direction':lane} for n,lane in enumerate(lanes)]
        with patch('website_daily.already_published',return_value=False),patch('website_daily.history',return_value=([],{})),patch('website_daily.candidate_bank',return_value=bank),patch('website_daily.quality',return_value=True):
            state=preflight_state(Path('.'),'2026-10-26')
        self.assertEqual(state['generate'],'true')
        self.assertEqual(state['priority_available'],4)
        from reading_policy import PRIORITY
        self.assertEqual(set(json.loads(state['lanes'])),set(PRIORITY))

    def test_automatic_schedule_repairs_today_before_preparing_future_reserve(self):
        today=date(2026,10,26)
        with patch('website_daily.already_published',side_effect=lambda r,d:d!='2026-10-26'):
            self.assertEqual(automatic_day(Path('.'),today),'2026-10-26')
        with patch('website_daily.already_published',side_effect=lambda r,d:d in ('2026-10-26','2026-10-27')):
            self.assertEqual(automatic_day(Path('.'),today),'2026-10-28')

    def test_release_window_commits_ready_today_even_if_tomorrow_is_short(self):
        ready=set()
        def publish(root,day,pools):
            if day=='2026-10-27':raise PolicyError('Deficit')
            ready.add(day)
        with tempfile.TemporaryDirectory() as folder,patch('website_daily.already_published',side_effect=lambda r,d:d in ready),patch('website_daily.combine',side_effect=publish),patch('website_daily.preflight_state',return_value={'day':'2026-10-27','generate':'true'}):
            status=release_window(Path(folder),Path(folder),date(2026,10,26))
            self.assertTrue(status['today_ready'])
            self.assertEqual(status['published_now'],['2026-10-26'])
            self.assertEqual(status['next_pending']['day'],'2026-10-27')
            self.assertTrue((Path(folder)/'reading-status.json').exists())

    def test_existing_bank_is_excluded_from_fresh_worker_target_and_discovery(self):
        old={'doi':'10.1234/already-stocked','paper_title':'Already stocked','research_direction':'organic'}
        with tempfile.TemporaryDirectory() as folder,patch('website_daily.history',return_value=([],{})),patch('website_daily.candidate_bank',return_value=[old]),patch('paper_recommendation.load_catalog',return_value=[old]),patch('recommendation_writer.DeepReadingWriter'),patch('journal_discovery.JournalRegistry.load'),patch('website_daily.discover',return_value=[]) as discover_mock:
            dest=Path(folder)/'pool.json'
            worker(Path(folder),'organic','2026-10-26',dest)
            self.assertIn('doi:10.1234/already-stocked',discover_mock.call_args.args[2])
            self.assertEqual(json.loads(dest.read_text())['items'],[])

    def test_new_pool_work_with_old_rules_is_retained_for_reclassification(self):
        item={'doi':'10.1234/old-pool','paper_title':'Completed during previous rules'}
        with tempfile.TemporaryDirectory() as folder,patch('website_daily.quality',return_value=False):
            root=Path(folder);pool=root/'pool';pool.mkdir()
            (pool/'lane.json').write_text(json.dumps({'items':[item]}))
            collect_candidates(root,pool)
            self.assertEqual(json.loads((root/'reading-candidates.json').read_text())['items'],[item])
            self.assertEqual(candidate_bank(root,set()),[])

    def test_old_review_is_retained_but_not_selectable_after_classification_rules_change(self):
        from reading_policy import POLICY_VERSION
        item={'doi':'10.1234/old-held','paper_title':'Completed review requiring new classification'}
        with tempfile.TemporaryDirectory() as folder,patch('website_daily.quality',return_value=False):
            root=Path(folder);pools=root/'pools';pools.mkdir()
            path=root/'reading-candidates.json'
            path.write_text(json.dumps({'policy_version':POLICY_VERSION,'items':[item]}))
            collect_candidates(root,pools)
            self.assertEqual(json.loads(path.read_text())['items'],[item])
            self.assertEqual(candidate_bank(root,set()),[])

    def test_preparation_date_rolls_over_and_does_not_advance_explicit_dates(self):
        self.assertEqual(requested_day(next_day=True,today=date(2026,12,31)),'2027-01-01')
        self.assertEqual(requested_day('2026-10-21',today=date(2026,10,20)),'2026-10-21')
        with self.assertRaises(PolicyError):requested_day('2026-10-21',True)

    def test_sufficient_valid_unused_bank_publishes_without_running_models(self):
        lanes=['chemical-biology','cadd-aidd','drug-discovery','neuropharmacology','interdisciplinary',
               'organic','inorganic','catalysis','polymer','analytical']
        items=[{'doi':f'10.1234/new-{n}','paper_title':f'Paper {n}','research_direction':lane} for n,lane in enumerate(lanes)]
        with (tempfile.TemporaryDirectory() as folder,patch('website_daily.already_published',return_value=False),
              patch('website_daily.quality',return_value=True)):
            from reading_policy import POLICY_VERSION
            root=Path(folder)
            (root/'reading-candidates.json').write_text(json.dumps({'policy_version':POLICY_VERSION,'items':items}))
            self.assertEqual(preflight_state(root,'2026-10-21')['generate'],'false')
            (root/'reading-history.json').write_text(json.dumps({'doi:10.1234/new-0':'2026-10-20'}))
            self.assertEqual(preflight_state(root,'2026-10-21')['generate'],'true')
    def test_completed_bilingual_candidates_are_reused_only_after_validation(self):
        item={'doi':'10.1234/ready'}
        with patch('website_daily.quality',return_value=True),patch('bilingual_mail.LocalTranslator') as translator:
            self.assertIs(prepare_item(Path('.'),item,'2026-10-21'),item)
            translator.assert_not_called()
        with tempfile.TemporaryDirectory() as folder,patch('website_daily.quality',return_value=False),patch('bilingual_mail.prepare') as prepare:
            from tests.test_paper_classification import certified
            item=certified({'doi':'10.1234/ready','paper_title':'Ready chemistry'})
            with self.assertRaises(PolicyError):prepare_item(Path(folder),item,'2026-10-21')
            prepare.assert_called_once()
    def test_partial_successes_survive_failed_issue_without_being_marked_published(self):
        item={'doi':'10.1234/new','paper_title':'A new paper'}
        with tempfile.TemporaryDirectory() as folder,patch('website_daily.quality',return_value=True):
            root=Path(folder);pool=root/'pool';pool.mkdir()
            (pool/'a.json').write_text(json.dumps({'day':'2026-10-20','items':[item,item]}))
            collect_candidates(root,pool)
            self.assertEqual(candidate_bank(root,set()),[item])
            self.assertFalse((root/'reading-history.json').exists())
            self.assertEqual(candidate_bank(root,{'doi:10.1234/new'}),[])
            collect_candidates(root,pool)
            self.assertEqual(candidate_bank(root,set()),[item])
    def test_unreadable_metadata_does_not_exhaust_editorial_budget(self):
        rows=[{'doi':f'10.1234/unavailable-{i}'} for i in range(12)]
        candidate={'doi':'10.1234/readable','title':'A worthwhile chemistry paper'}
        rows.append(candidate)
        analyzed={**candidate,'research_direction':'organic','venue':'Verified journal'}
        writer=MagicMock();writer.analyze.return_value=analyzed
        registry=MagicMock();registry.match.return_value={'title':'Verified journal'}
        def read(root,item):
            if item['doi']!=candidate['doi']:raise OSError('unavailable')
            return analyzed,[],''
        with tempfile.TemporaryDirectory() as folder:
            destination=Path(folder)/'pool.json'
            with (patch('website_daily.history',return_value=([],{})),
                  patch('website_daily.discover',return_value=rows),
                  patch('website_daily.prepare_item',side_effect=lambda root,item,*a:item),
                  patch('paper_recommendation.load_catalog',return_value=[]),
                  patch('paper_recommendation.load_candidate_fulltext',side_effect=read),
                  patch('paper_recommendation.complete_item',return_value=True),
                  patch('affiliation_sources.units_complete',return_value=True),
                  patch('recommendation_writer.DeepReadingWriter',return_value=writer),
                  patch('journal_discovery.JournalRegistry.load',return_value=registry),
                  patch.dict('os.environ',{'GITHUB_STEP_SUMMARY':str(Path(folder)/'summary.md')})):
                worker(Path(folder),'organic','2026-10-20',destination)
            pool=json.loads(destination.read_text(encoding='utf-8'))
            self.assertEqual(pool['items'],[analyzed])
            self.assertEqual(pool['diagnostics']['fulltext_failed'],12)
            self.assertEqual(pool['diagnostics']['editorial_attempts'],1)

    def test_editorial_references_are_constrained_to_read_paragraphs(self):
        from recommendation_writer import DeepReadingWriter
        with tempfile.TemporaryDirectory() as folder:
            writer=DeepReadingWriter(folder)
            evidence={'p1','p2','p3'}
            with (patch.object(writer,'evidence_pack',return_value=('Read evidence',evidence)),
                  patch('affiliation_sources.units_complete',return_value=True),
                  patch.object(writer,'generate',side_effect=[{'focus':'A concrete organic chemistry investigation with experiments.','research_direction':'organic','evidence_ids':['p1','p2']}]+[{
                      'assessment':'An assessment of the actual research evidence, explaining the experimental contribution. '*3,
                      'related':True,'substantive':True,'not_routine':True,'research_direction':'organic',
                      'criteria':[2],'evidence_ids':['p1','p2','invented']}]*2) as generate):
                result=writer.analyze({'doi':'10.1234/test','fulltext_sha256':'a'*64,
                                      'paper_title':'Original title','recommendation_kind':'research'},[],'')
            self.assertIsNone(result)
            self.assertTrue(writer.last_rejection.startswith('judgement:'))
            self.assertEqual(set(generate.call_args.args[2]['evidence_ids']['items']['enum']),evidence)

    def test_index_outage_is_audited_separately_from_zero_qualified_papers(self):
        audit={}
        with (patch('journal_discovery.JournalRegistry.load',return_value=MagicMock()),
              patch('recommendation_sources.read_json',side_effect=OSError('unavailable'))):
            self.assertEqual(discover(Path('.'),'catalysis',set(),'2026-10-20',audit=audit),[])
        for name in ('Europe PMC','Crossref','PubMed'):
            self.assertGreater(audit[name]['failures'],0)

    def test_valid_cross_direction_discovery_is_kept_for_global_quotas(self):
        # A catalysis query may find a valuable organic synthesis paper.
        # The final 10/5/3 selector must decide the quota, not the query label.
        candidate={'doi':'10.1234/cross-direction','title':'Original synthesis paper'}
        analyzed={**candidate,'research_direction':'organic','venue':'Verified journal'}
        writer=MagicMock();writer.analyze.return_value=analyzed
        registry=MagicMock();registry.match.return_value={'title':'Verified journal'}
        with tempfile.TemporaryDirectory() as folder:
            destination=Path(folder)/'pool.json'
            with (patch('website_daily.history',return_value=([],{})),
                  patch('website_daily.discover',return_value=[candidate]),
                  patch('website_daily.prepare_item',side_effect=lambda root,item,*a:item),
                  patch('paper_recommendation.load_catalog',return_value=[]),
                  patch('paper_recommendation.load_candidate_fulltext',return_value=(analyzed,[],'')),
                  patch('paper_recommendation.complete_item',return_value=True),
                  patch('affiliation_sources.units_complete',return_value=True),
                  patch('recommendation_writer.DeepReadingWriter',return_value=writer),
                  patch('journal_discovery.JournalRegistry.load',return_value=registry),
                  patch.dict('os.environ',{'GITHUB_STEP_SUMMARY':str(Path(folder)/'summary.md')})):
                worker(Path(folder),'catalysis','2026-10-20',destination)
            pool=json.loads(destination.read_text(encoding='utf-8'))
            self.assertEqual(pool['items'],[analyzed])
            self.assertEqual(pool['diagnostics']['qualified'],1)
            self.assertIn('(organic)',(Path(folder)/'summary.md').read_text(encoding='utf-8'))

    def test_source_archive_coexists_with_data_without_being_unpacked(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            with ZipFile(root/'reading-generator.zip','w') as bundle:
                bundle.writestr('executable.py','raise RuntimeError("must not be unpacked by the reader")')
            with ZipFile(root/'reading-content.zip','w') as bundle:
                bundle.writestr('data/paper-recommendation/2026-10-18/marker.json','{}')
            ensure_bundled_files(root)
            self.assertFalse((root/'executable.py').exists())
            self.assertTrue((root/'data/paper-recommendation/2026-10-18/marker.json').exists())
            with ZipFile(root/'reading-content.zip','w') as bundle:
                bundle.writestr('../unexpected.py','not allowed')
            with self.assertRaises(ValueError):ensure_bundled_files(root)

    def test_history_survives_report_replacement(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            (root/'reading-history.json').write_text(json.dumps({'doi:10.1234/old':'2026-10-15'}))
            _,saved=history(root)
            self.assertEqual(saved['doi:10.1234/old'],'2026-10-15')

    def test_empty_or_incomplete_pool_cannot_overwrite_a_report(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);pool=root/'pool';pool.mkdir()
            (pool/'candidates.json').write_text(json.dumps({'day':'2026-10-19','items':[]}))
            with self.assertRaises(PolicyError):combine(root,'2026-10-19',pool)
            self.assertFalse((root/'data/paper-recommendation').exists())
            self.assertFalse((root/'reading-history.json').exists())

    def test_legacy_three_paper_copy_is_not_treated_as_complete_new_issue(self):
        root=Path(__file__).resolve().parents[1]
        self.assertFalse(already_published(root,'2026-10-19'))


if __name__=='__main__':unittest.main()
