"""GitHub Actions runner 之间持久保存发送状态；不保存任何密钥。"""
from datetime import date, datetime, timezone
import base64
import hashlib
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request


class StateError(Exception):
    pass


class GitHubState:
    def __init__(self, repository, token, branch="research-digest-state"):
        if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", repository):
            raise StateError("云端仓库名称无效。")
        if not token:
            raise StateError("缺少 GitHub 工作流令牌。")
        self.repository = repository
        self.token = token
        self.branch = branch

    def request(self, method, path, body=None, allow_404=False):
        data = None if body is None else json.dumps(body).encode("utf-8")
        base_url = f"https://api.github.com/repos/{self.repository}"
        request = urllib.request.Request(
            base_url + ("/" + path if path else ""), data=data,
            headers={"Authorization": "Bearer " + self.token,
                     "Accept": "application/vnd.github+json",
                     "Content-Type": "application/json", "User-Agent": "research-digest-mailer",
                     "X-GitHub-Api-Version": "2022-11-28"}, method=method)
        for attempt in range(3):
            try:
                with urllib.request.urlopen(request, timeout=45) as response:
                    return json.load(response)
            except urllib.error.HTTPError as error:
                code = error.code
                error.close()
                if code == 404 and allow_404:
                    return None
                if code not in (429, 500, 502, 503, 504) or attempt == 2:
                    raise StateError(f"云端发送记录 HTTP {code}（{method} {path or 'repository'}）；检查仓库写入权限和状态分支。") from None
            except (urllib.error.URLError, OSError):
                if attempt == 2:
                    raise StateError("无法连接云端发送记录 API，为避免重复邮件停止发送。") from None
            except (ValueError, UnicodeError):
                raise StateError("云端发送记录 API 返回的数据无法解析。") from None
            time.sleep(2 * (attempt + 1))

    def ensure_branch(self):
        ref = "git/ref/heads/" + urllib.parse.quote(self.branch, safe="")
        if self.request("GET", ref, allow_404=True):
            return
        info = self.request("GET", "")
        default = urllib.parse.quote(info["default_branch"], safe="")
        head = self.request("GET", "git/ref/heads/" + default)
        try:
            self.request("POST", "git/refs", {"ref": "refs/heads/" + self.branch,
                                              "sha": head["object"]["sha"]})
        except StateError:
            # POST 可能已成功，但响应丢失；以实际读取结果为准。
            if not self.request("GET", ref, allow_404=True):
                raise

    @staticmethod
    def filename(key):
        encoded = json.dumps(list(key), ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        return "delivery/" + hashlib.sha256(encoded).hexdigest() + ".json"

    def read_record(self, key):
        # 区分文件不存在与整条状态分支丢失，防止误删分支后静默重发。
        self.request("GET", "git/ref/heads/" + urllib.parse.quote(self.branch, safe=""))
        path = "contents/" + self.filename(key)
        value = self.request("GET", path + "?" + urllib.parse.urlencode({"ref": self.branch}), allow_404=True)
        if value is None:
            return None, None
        try:
            record = json.loads(base64.b64decode(value["content"]).decode("utf-8"))
            if record["status"] not in ("sent", "sending", "uncertain", "failed"):
                raise ValueError()
            return record, value["sha"]
        except (KeyError, TypeError, ValueError, UnicodeError):
            raise StateError("云端发送记录格式异常，为避免重复邮件停止发送。") from None

    def read(self, key):
        record, sha = self.read_record(key)
        return (record['status'] if record else None), sha

    def claim(self, key, owner):
        """Acquire a delivery with GitHub's conditional content SHA, not read/write retries."""
        if not re.fullmatch(r'[0-9a-f]{32}', owner):
            raise StateError('无效的发信任务标识。')
        record, sha = self.read_record(key)
        if record and record['status'] in ('sent','sending','uncertain'):
            return False
        record = {'day':key[0], 'status':'sending', 'owner':owner,
                  'updated':datetime.now(timezone.utc).isoformat()}
        payload = {'message':'Claim digest delivery '+key[0], 'branch':self.branch,
                   'content':base64.b64encode(json.dumps(record).encode()).decode()}
        if sha:
            payload['sha'] = sha
        try:
            self.request('PUT','contents/'+self.filename(key),payload)
        except StateError:
            # A conflicting writer must never inherit the other writer's claim.
            # A lost successful response is recoverable only with our own owner.
            current, _ = self.read_record(key)
            if current and current.get('owner') == owner and current['status'] == 'sending':
                return True
            if current and current['status'] in ('sent','sending','uncertain'):
                return False
            raise
        return True

    def status(self, key):
        return self.read(key)[0]

    def load_report(self, day):
        date.fromisoformat(day)
        value = self.request("GET", "contents/reports/" + day + ".json?" + urllib.parse.urlencode({"ref": self.branch}), allow_404=True)
        if value is None:
            return None
        try:
            report = json.loads(base64.b64decode(value["content"]).decode("utf-8"))
            if report.get("date") != day or report.get("demo") or not isinstance(report.get("sections"), dict):
                raise ValueError()
            return report
        except (KeyError, TypeError, ValueError, UnicodeError):
            raise StateError("云端预备报告格式异常，停止发送。") from None

    def save_report(self, report):
        day = report["date"]
        date.fromisoformat(day)
        if report.get("demo") or not isinstance(report.get("sections"), dict):
            raise StateError("不能保存无效的云端预备报告。")
        path = "contents/reports/" + day + ".json"
        old = self.request("GET", path + "?" + urllib.parse.urlencode({"ref": self.branch}), allow_404=True)
        body = {"message": "Prepare research digest " + day, "branch": self.branch,
                "content": base64.b64encode(json.dumps(report, ensure_ascii=False).encode("utf-8")).decode("ascii")}
        if old is not None:
            body["sha"] = old["sha"]
        self.request("PUT", path, body)

    def write(self, key, status):
        if status not in ("sent", "sending", "uncertain", "failed"):
            raise StateError("无效的邮件发送状态。")
        _, sha = self.read(key)
        record = {"day": key[0], "status": status,
                  "updated": datetime.now(timezone.utc).isoformat()}
        payload = {"message": f"Record digest delivery {key[0]}: {status}",
                   "branch": self.branch,
                   "content": base64.b64encode(json.dumps(record).encode("utf-8")).decode("ascii")}
        if sha:
            payload["sha"] = sha
        path = "contents/" + self.filename(key)
        try:
            self.request("PUT", path, payload)
        except StateError:
            # 更新的响应丢失时读取确认；未确认保存成功之前绝不提交邮件。
            if self.status(key) != status:
                raise


def store_from_environment():
    if os.environ.get("DIGEST_CLOUD_STATE") != "github":
        return None
    selected_edition = os.environ.get("DIGEST_EDITION", "chemistry")
    branches = {'chemistry':'research-digest-state', 'chemical-biology':'research-digest-chemical-biology-state',
                'chemistry-news':'research-digest-chemistry-news-state','paper-recommendation':'research-digest-recommendation-state'}
    if selected_edition not in branches:
        raise StateError("无效的云端日报类型。")
    branch = branches[selected_edition]
    return GitHubState(os.environ.get("GITHUB_REPOSITORY", ""),
                       os.environ.get("GITHUB_TOKEN", ""), branch=branch)
