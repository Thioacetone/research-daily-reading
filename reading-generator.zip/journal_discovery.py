"""Date-first discovery across an auditable Journal Impact Factor registry.

Journal eligibility is separate from article quality and chemical relevance.
The institutional compilation is not presented as a live licensed JCR export.
"""
from datetime import datetime,timedelta,timezone
import hashlib
import html
import json
import logging
import math
from pathlib import Path
import re
import urllib.parse
import unicodedata

from author_roles import name_key
from crossref_metadata import normalize_doi,publication_date

VERSION='jif-date-discovery-v2-broad-chemical-topics'
LOG=logging.getLogger('digest')
REGISTRY='journal-impact-factors.json'
POLICY='journal-search.json'
ALIASES='journal-aliases.json'
SELECT='DOI,title,container-title,ISSN,type,published-online,abstract,author,URL'
CHEMICAL_JOURNAL=re.compile(r'chemi|catal|polymer|electrochem|macromolecul|molecular catal|carbon$|carbohydrate|colloid|membrane science|separation and purification|drug discovery|medicinal',re.I)
CHEMICAL_SIGNAL=re.compile(
    r'\b(?:cataly\w*|photocatal\w*|electrocatal\w*|photoredox|organometallic\w*|'
    r'chemo(?:proteom\w*|enzym\w*|select\w*|genetic\w*)|bioorthogonal|bioconjugat\w*|covalent|stereoselect\w*|enantioselect\w*|'
    r'regioselect\w*|synthes(?:is|es|ize\w*|is\w*)|electrolyte\w*|electrode\w*|'
    r'polymer\w*|hydrogel\w*|supramolecular|metal.organic|covalent.organic|'
    r'ligand\w*|small.molecule\w*|protein degradation|glycosylation|enzyme engineer\w*|'
    r'lipid\w*|biosynthes\w*|mass spectrom\w*|nuclear magnetic resonance|'
    r'carbon dioxide conversion|chemical probe\w*|reaction mechanism\w*|'
    r'nanoparticle\w*|nanocrystal\w*|perovskite\w*|photovoltaic\w*|'
    r'quantum dot\w*|battery|batteries|fuel cell\w*|solid.state ion\w*|'
    r'photochem\w*|mechanochem\w*|chemical recycling|chemical separa\w*|'
    r'molecular dock\w*|molecular dynamic\w*|structure.based drug|'
    r'computer.aided drug|AI.driven drug|drug design|drug delivery|'
    r'targeted protein degrad\w*|proteolysis.targeting|PROTAC\w*|molecular glue\w*)\b',re.I)
CHINESE_CHEMICAL=re.compile(r'催化|光氧化还原|有机合成|立体选择|化学探针|化学生物学|生物正交|'
                            r'电化学|电解质|高分子|聚合物|水凝胶|超分子|金属有机框架|'
                            r'共价有机框架|钙钛矿|纳米颗粒|纳米晶|量子点|药物设计|药物递送|靶向蛋白降解')
NON_ARTICLE=re.compile(r'^(?:author correction|publisher correction|correction|retraction|editorial|'
                       r'obituary|erratum|research briefing|research highlight|news and views|'
                       r'cover (?:picture|profile|feature)|front(?:ispiece)? cover|back cover)\b',re.I)

class DiscoveryError(ValueError):
    pass

def journal_key(title):
    title=html.unescape(str(title))
    title=re.sub(r'<[^>]+>',' ',title)
    return re.sub(r'[\W_]+','',unicodedata.normalize('NFKC',title).casefold().replace('&',' and '))

class JournalRegistry:
    def __init__(self,value):
        if (not isinstance(value,dict) or value.get('schema_version')!=1
                or value.get('comparison')!='>' or value.get('threshold')!=6
                or not isinstance(value.get('journals'),list) or not value['journals']):
            raise DiscoveryError('期刊影响因子清单无效，停止使用未核实期刊。')
        self.value=value;self.names={};self.issns={}
        for row in value['journals']:
            if (not isinstance(row,dict) or not isinstance(row.get('title'),str)
                    or type(row.get('jif')) not in (int,float) or not math.isfinite(row['jif'])
                    or row['jif']<=6):
                raise DiscoveryError('期刊清单含有未达到 JIF>6 的条目。')
            key=journal_key(row['title'])
            if key in self.names:raise DiscoveryError('期刊名称存在重复，请核对清单。')
            self.names[key]=row
            if row.get('eissn'):
                if not re.fullmatch(r'\d{4}-\d{3}[\dX]',row['eissn']):
                    raise DiscoveryError('期刊 ISSN 格式无效。')
                if row['eissn'] in self.issns:raise DiscoveryError('期刊 ISSN 存在重复。')
                self.issns[row['eissn']]=row

    @classmethod
    def load(cls,root):
        try:
            registry=cls(json.loads((Path(root)/REGISTRY).read_text(encoding='utf-8')))
            path=Path(root)/ALIASES
            if path.exists():registry.add_aliases(json.loads(path.read_text(encoding='utf-8')))
            return registry
        except (OSError,TypeError,KeyError) as exc:raise DiscoveryError('无法读取期刊影响因子清单。') from exc

    def add_aliases(self,value):
        if not isinstance(value,dict) or value.get('schema_version')!=1 or not isinstance(value.get('journals'),list):
            raise DiscoveryError('期刊别名目录无效。')
        names={};issns={}
        for entry in value['journals']:
            row=self.names.get(journal_key(entry['canonical_journal']))
            if not row:continue
            if entry.get('canonical_eissn') and entry['canonical_eissn']!=row.get('eissn'):continue
            for alias in entry.get('titles',[]):
                names.setdefault(journal_key(alias),{})[row['title']]=row
            for issn in entry.get('issns',[]):
                if re.fullmatch(r'\d{4}-\d{3}[\dX]',issn):issns.setdefault(issn,{})[row['title']]=row
        for mapping,incoming in ((self.names,names),(self.issns,issns)):
            for key,rows in incoming.items():
                if len(rows)!=1:continue
                row=next(iter(rows.values()))
                if key not in mapping or mapping[key]['title']==row['title']:mapping[key]=row

    @property
    def journal_count(self):
        return len({row['title'] for row in self.names.values()})

    def match(self,title,issns=()):
        if isinstance(issns,str):issns=[issns]
        found={self.issns[i]['title']:self.issns[i] for i in issns if i in self.issns}
        if len(found)>1:return None  # Conflicting journal identifiers are not guessed.
        by_name=self.names.get(journal_key(title))
        if found:
            row=next(iter(found.values()))
            if by_name and by_name['title']!=row['title']:return None
            return row
        return by_name

    def evidence(self,row):
        return {'value':row['jif'],'metric':'Journal Impact Factor',
                'jif_year':self.value['jif_year'],'release_year':self.value['release_year'],
                'journal':row['title'],'eissn':row.get('eissn'),
                'source_url':self.value['source']['url'],'source_page':row['source_page'],
                'publisher_crosscheck':row.get('publisher_crosscheck','')}

def chemistry_relevant(record):
    titles=record.get('title',[]);journals=record.get('container-title',[])
    if not titles or NON_ARTICLE.search(str(titles[0])):return False
    if any(CHEMICAL_JOURNAL.search(str(j)) for j in journals):return True
    title=str(titles[0]);abstract=re.sub(r'<[^>]+>',' ',str(record.get('abstract','')))
    # Evidence synthesis and AI-generated synthetic images are not molecular
    # synthesis. Require another chemical signal in those contexts.
    if re.search(r'evidence synthesis|systematic review|meta.analysis|synthetic (?:data|image)|large language model',title+' '+abstract,re.I):
        signal=lambda text:[s for s in CHEMICAL_SIGNAL.findall(text) if not s.lower().startswith('synthes')]
        return bool(signal(title) or len(signal(abstract))>=2)
    return bool(CHEMICAL_SIGNAL.search(title) or len(CHEMICAL_SIGNAL.findall(abstract))>=2
                or CHINESE_CHEMICAL.search(title) or len(CHINESE_CHEMICAL.findall(abstract))>=2)

def query_url(target,cursor='*',rows=500):
    return 'https://api.crossref.org/works?'+urllib.parse.urlencode({
        'filter':f'type:journal-article,from-online-pub-date:{target},until-online-pub-date:{target}',
        'rows':rows,'cursor':cursor,'select':SELECT})

def discover(root,target,fetcher,max_pages=100,rows=500):
    """Read all cursor pages. Failed/incomplete scans stay explicitly partial."""
    root=Path(root);registry=JournalRegistry.load(root)
    registry_bytes=(root/REGISTRY).read_bytes()
    if (root/ALIASES).exists():registry_bytes+=(root/ALIASES).read_bytes()
    registry_hash=hashlib.sha256(registry_bytes).hexdigest()
    cache=root/'data/journal-discovery'/(target.isoformat()+'.json')
    try:
        previous=json.loads(cache.read_text(encoding='utf-8'))
        age=datetime.now(timezone.utc)-datetime.fromisoformat(previous['retrieved_at'])
        if (previous.get('version')==VERSION and previous.get('registry_sha256')==registry_hash
                and previous.get('coverage',{}).get('cursor_exhausted')
                and timedelta(0)<=age<timedelta(hours=1)):
            # Narrowing topic rules must also apply to a cached snapshot.
            records=[record for record in previous['records'] if chemistry_relevant(record)]
            coverage=dict(previous['coverage'],chemistry_candidates=len(records))
            return records,coverage
    except (OSError,ValueError,KeyError,TypeError):pass
    records=[];seen=set();cursor='*';cursors=set();failures=[]
    coverage={'name':'JIF>6 全学科期刊在线日期检索','url':query_url(target),
              'status':'ok','pages_read':0,'records_examined':0,'registry_matches':0,
              'registry_journals':registry.journal_count,'cursor_exhausted':False,
              'jif_year':registry.value['jif_year'],'release_year':registry.value['release_year']}
    for _ in range(max_pages):
        if cursor in cursors:
            failures.append('文献登记分页游标重复，覆盖范围不完整。');break
        cursors.add(cursor)
        try:
            payload=json.loads(fetcher(query_url(target,cursor,rows),limit=30_000_000))
            message=payload['message'];items=message['items']
            if not isinstance(items,list):raise ValueError('Invalid records')
        except Exception as exc:
            failures.append('日期检索分页失败（'+type(exc).__name__+'），未宣称完整覆盖。');break
        coverage['pages_read']+=1
        coverage['total_records_reported']=message.get('total-results')
        coverage['records_examined']+=len(items)
        LOG.info('跨期刊日期检索：第%s页，已读取%s/%s条登记。',coverage['pages_read'],
                 coverage['records_examined'],message.get('total-results','未知'))
        for record in items:
            if not isinstance(record,dict):continue
            doi=normalize_doi(record.get('DOI'))
            titles=record.get('container-title',[])
            if (not doi or doi in seen or record.get('type')!='journal-article'
                    or publication_date(record)!=target.isoformat() or not titles):continue
            seen.add(doi)
            metric=registry.match(titles[0],record.get('ISSN',[]))
            if not metric:continue
            coverage['registry_matches']+=1
            if chemistry_relevant(record):
                record['_journal_metric']=registry.evidence(metric);records.append(record)
        if len(items)<rows:
            coverage['cursor_exhausted']=True;break
        next_cursor=message.get('next-cursor')
        if not isinstance(next_cursor,str) or not next_cursor:
            failures.append('文献登记未提供下一页游标，覆盖范围不完整。');break
        cursor=next_cursor
    else:failures.append('日期检索达到分页上限，覆盖范围不完整。')
    coverage.update(chemistry_candidates=len(records),failures=failures,
                    status='partial' if failures else 'ok')
    if failures and not coverage['pages_read']:raise DiscoveryError(failures[0])
    cache.parent.mkdir(parents=True,exist_ok=True)
    cache.write_text(json.dumps({'version':VERSION,'retrieved_at':datetime.now(timezone.utc).isoformat(),
                                'registry_sha256':registry_hash,'records':records,'coverage':coverage},
                               ensure_ascii=False),encoding='utf-8')
    return records,coverage

def enabled(root):
    path=Path(root)/POLICY
    if not path.exists():return False
    try:
        policy=json.loads(path.read_text(encoding='utf-8'))
        if policy.get('journal_impact_factor')!={'comparison':'>','threshold':6}:
            raise DiscoveryError('期刊阈值配置无效。')
        return policy.get('chemistry_date_discovery') is True
    except (ValueError,OSError) as exc:raise DiscoveryError('无法读取期刊检索策略。') from exc
