"""读取公开来源和 Crossref，筛选论文并概括摘要；不调用 AI 接口。"""
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from html.parser import HTMLParser
import html
import hashlib
import json
import logging
from pathlib import Path
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from crossref_metadata import CrossrefClient, MetadataError, author_details, normalize_doi, publication_date
from paper_summary import summarize_item, translator_for, complete_item
from author_roles import jats_roles, meta_correspondents, name_key, html_affiliations, merge_author_affiliations

BJ = timezone(timedelta(hours=8))
LOG = logging.getLogger("digest")
ENGINE = "public-chemistry-and-chemical-biology-v22-independent-journal-indices"
NEWS_TOPIC = "化学新闻"
BIO_TOPIC = "化学生物学"
CHEMISTRY_NEWS = re.compile(r"\b(chemistr\w*|chemical\w*|catal\w*|molecul\w*|polymer\w*|electrochem\w*|battery|batteries|hydrogen|pfas|synthesis|synthesi[sz]\w*)\b|化学|催化|分子|合成|电化学|电池|聚合物|化工|超导|氢能|材料", re.I)
MAJOR_NEWS = {
    "重要奖项或学术认可": re.compile(r"nobel|prestigious award|international award|诺贝尔|国家科学技术奖|国家自然科学奖", re.I),
    "明确的新突破或纪录": re.compile(r"breakthrough|unprecedented|first[ -]ever|world.?s first|record[ -]breaking|重大突破|世界首次|国际首次|创.{0,6}纪录|首次实现", re.I),
    "产业应用或规模化": re.compile(r"commerciali[sz]|industrial.scale|pilot plant|billion|量产|产业化|规模化应用|工业化|重大项目", re.I),
    "重大政策、安全或环境事件": re.compile(r"regulat\w*|ban\w*|explosion|chemical accident|toxic spill|重大事故|化工事故|禁用|新规|监管|重大污染", re.I),
    "化学标准或新兴技术": re.compile(r"emerging technolog|new element|element nam|periodic table|nomenclature|technical recommendation|新元素|命名规则|技术标准|新兴技术", re.I),
    "实质性化学研究进展": re.compile(r"discover\w*|develop\w*|demonstrat\w*|new (?:method|catalyst|material|process)|研制|揭示|研发|发现|实现|取得.{0,8}进展", re.I),
}
NEWS_ADMIN = re.compile(r"webinar|register now|call for (abstracts|proposals)|eTOC|newsletter|predictions?|predicting|press invitation|announcement dates|会议通知|招生|招聘|报名|征集|预测|公布时间|公告日程", re.I)
CHEMISTRY_AREAS = {
    "催化与反应方法": ("catal", "reaction", "selectiv", "functionalization", "dearom"),
    "合成与分子构筑": ("synthes", "molecular", "stereo", "assembly", "polymer"),
    "电化学与能源": ("electro", "battery", "lithium", "hydrogen", "fuel", "solar"),
    "材料与结构化学": ("material", "framework", "crystal", "nanoconfin", "allotrop"),
    "分析与表征": ("spectroscop", "detect", "sensor", "imaging", "analytical"),
    "理论与物理化学": ("quantum", "mechanism", "simulation", "diffusion", "theor"),
    "环境与绿色化学": ("pfas", "defluorin", "carbon dioxide", "pollut", "recycl", "sustainab"),
}
NOVELTY = ("first", "unprecedented", "novel", "new strategy", "new method", "enables", "overcome")
VALUE = ("selectiv", "efficient", "scalable", "general", "ambient", "mild", "stable", "recycl")
CHEMICAL_BIOLOGY = re.compile(
    r"chemical biology|chemoproteom|chemical probe|bioorthogonal|bio-orthogonal|PROTAC|molecular glue|"
    r"targeted protein degradation|cysteine arylation|lipid.protein crosslink|chemogenetic|chemoproteomic|photoaffinity|"
    r"activity.based probe|covalent inhibitor|ligand.directed|protein glycosylation|"
    r"(?:protein|peptide|ribosomal).{0,100}thioamid|thioamid.{0,100}(?:protein|peptide|ribosomal)|"
    r"biosynthetic gene cluster|non.ribosomal peptide|"
    r"化学生物学|化学探针|生物正交|靶向蛋白降解|化学蛋白质组", re.I)
BIO_CONTEXT = re.compile(r"\b(protein\w*|peptide\w*|enzyme\w*|cellular|lipid\w*|receptor\w*|proteom\w*|kinase\w*|DNA|RNA|chromatin|glycan\w*)\b", re.I)
CHEM_METHOD = re.compile(r"crosslink\w*|covalent|small.molecule|metal coordination|chemical (?:label|modif)|"
                        r"site.selective|site.resolved|late.stage functionalization|bioconjugat\w*|enzyme engineer\w*|inhibit\w*|chemical modification", re.I)
PRIORITY_JOURNALS = {name_key(name) for name in (
    "Nature Chemical Biology", "Nature Chemistry", "Nature Synthesis", "Nature", "Science", "Cell",
    "Journal of the American Chemical Society", "JACS Au", "Angewandte Chemie International Edition",
    "ACS Central Science", "Chemical Science", "Cell Chemical Biology", "Nature Methods",
    "Nature Biotechnology", "Nature Communications", "ACS Nano", "Journal of Medicinal Chemistry", "ACS Chemical Biology")}


def chemical_biology_priority(title, abstract, journal):
    text = title + " " + clean(abstract)
    relevant = bool(CHEMICAL_BIOLOGY.search(text) or (BIO_CONTEXT.search(text) and CHEM_METHOD.search(text)))
    return relevant and name_key(journal) in PRIORITY_JOURNALS


def chemical_biology_paper(title, abstract, journal):
    dedicated = {name_key(name) for name in ('Nature Chemical Biology','Cell Chemical Biology','ACS Chemical Biology')}
    return name_key(journal) in dedicated or chemical_biology_priority(title,abstract,journal)


def source_fingerprint(root):
    try:
        content=(Path(root) / "sources.json").read_bytes()
        for name in ('journal-search.json','journal-impact-factors.json','journal-aliases.json'):
            path=Path(root)/name
            if path.exists():content+=name.encode()+path.read_bytes()
        return hashlib.sha256(content).hexdigest()
    except OSError:
        return ""


def chemistry_outline(title, abstract):
    text = (title + " " + abstract).lower()
    areas = [area for area, words in CHEMISTRY_AREAS.items() if any(w in text for w in words)]
    sentences = re.split(r"(?<=[.!?])\s+(?=[A-Z])", clean(abstract))
    key = next((s for s in sentences if re.search(r"\b(here|we (report|show|demonstrate|develop|present)|this (study|work))\b", s, re.I)), "")
    excerpt = short_excerpt(key or abstract, 45)
    outline = "研究方向：" + "、".join(areas[:3] or ["化学研究"]) + "。"
    outline += "摘要要点（原文短摘录）：" + excerpt if excerpt else "可读取的来源没有提供摘要，请查看原文。"
    signals = [w for w in NOVELTY if w in text]
    values = [w for w in VALUE if w in text]
    return outline, areas, signals, values
KEYWORDS = {
    "化学": ["catal", "synthes", "electro", "battery", "quantum", "catalysis", "催化", "合成", "电池", "突破"],
    "生物": ["crispr", "gene edit", "genome", "protein", "cell", "therap", "single-cell", "基因", "细胞", "蛋白"],
    "人工智能": ["reasoning", "multimodal", "agent", "language model", "open model", "benchmark", "transformer", "推理", "模型", "开源"],
}


class ResearchError(Exception):
    pass


def valid_url(value):
    parsed = urllib.parse.urlsplit(value)
    return parsed.scheme in ("https", "http") and bool(parsed.hostname) and not parsed.username


def fetch(url, limit=3_000_000):
    if not valid_url(url):
        raise ResearchError("来源链接无效。")
    request = urllib.request.Request(url, headers={"User-Agent": "ResearchDigest/1.0 (RSS reader)",
                                                  "Accept": "application/rss+xml,application/atom+xml,text/html,*/*"})
    for attempt in range(2):
        try:
            with urllib.request.urlopen(request, timeout=25) as response:
                data = response.read(limit + 1)
            if len(data) > limit:
                raise ResearchError("来源页面超过大小限制。")
            return data
        except urllib.error.HTTPError as error:
            code = error.code
            error.close()
            if code not in (429, 500, 502, 503, 504) or attempt == 1:
                raise ResearchError(f"公开来源返回 HTTP {code}。") from None
        except (urllib.error.URLError, OSError):
            if attempt == 1:
                raise ResearchError("公开来源连接失败或超时。") from None
        time.sleep(1)
    raise ResearchError("公开来源读取失败。")


class Page(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.meta = {}
        self.paragraphs = []
        self.ld = []
        self.links = []
        self._paragraph = None
        self._script = None
        self._skip = 0
        self.author_pairs = []
        self._author_department = ''
        self._abstract_stack = []
        self.abstract_text = []
        self._affiliation = None
        self.affiliation_headings = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag not in ("meta", "link", "img", "br", "hr", "input", "source", "wbr"):
            marker = (attrs.get("id", "") + " " + attrs.get("class", "")).lower()
            self._abstract_stack.append((tag, "abstract" in marker or attrs.get("id", "").lower() == "abs1"))
        if tag == "h3" and "author-affiliation__address" in attrs.get("class", ""):
            self._affiliation = []
        if tag == "a" and attrs.get("href"):
            self.links.append(attrs["href"])
        if tag == "meta":
            key = (attrs.get("name") or attrs.get("property") or "").lower()
            if key:
                self.meta.setdefault(key, []).append(attrs.get("content", ""))
            if key == "citation_author":
                self.author_pairs.append({"name": clean(attrs.get("content", "")), "institutions": []})
                self._author_department = ''
            elif key == "citation_author_institution" and self.author_pairs:
                unit = clean(attrs.get('content',''))
                self.author_pairs[-1]['institutions'].append((self._author_department + ', ' if self._author_department else '') + unit)
            elif key == 'citation_author_affiliation' and self.author_pairs:
                self.author_pairs[-1]['institutions'].append(clean(attrs.get('content','')))
            elif key == 'citation_author_department' and self.author_pairs:
                department = clean(attrs.get('content',''))
                self._author_department = department
                self.author_pairs[-1]['institutions'] = [department + ', ' + unit for unit in self.author_pairs[-1]['institutions']]
        if tag == "script":
            self._script = [] if attrs.get("type") == "application/ld+json" else None
            self._skip += 1
        elif tag in ("style", "nav", "footer"):
            self._skip += 1
        if tag == "p" and not self._skip:
            self._paragraph = []

    def handle_endtag(self, tag):
        if tag == "h3" and self._affiliation is not None:
            self.affiliation_headings.append(clean(" ".join(self._affiliation)))
            self._affiliation = None
        for index in range(len(self._abstract_stack) - 1, -1, -1):
            if self._abstract_stack[index][0] == tag:
                del self._abstract_stack[index:]
                break
        if tag == "p" and self._paragraph is not None:
            value = clean(" ".join(self._paragraph))
            if value:
                self.paragraphs.append(value)
            self._paragraph = None
        if tag == "script":
            if self._script is not None:
                try:
                    self.ld.append(json.loads("".join(self._script)))
                except ValueError:
                    pass
            self._script = None
            self._skip = max(0, self._skip - 1)
        elif tag in ("style", "nav", "footer"):
            self._skip = max(0, self._skip - 1)

    def handle_data(self, value):
        if not self._skip and any(is_abstract for _, is_abstract in self._abstract_stack):
            self.abstract_text.append(value)
        if self._affiliation is not None:
            self._affiliation.append(value)
        if self._script is not None:
            self._script.append(value)
        if self._paragraph is not None and not self._skip:
            self._paragraph.append(value)


def clean(value):
    value = re.sub(r"<[^>]+>", " ", value or "")
    return " ".join(html.unescape(value).split())


def local_name(tag):
    return tag.rsplit("}", 1)[-1]


def normalize_time(value):
    value = clean(value).strip()
    if not value:
        return ""
    normalized = value.replace("/", "-")
    try:
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", normalized):
            return date.fromisoformat(normalized).isoformat()
        parsed = datetime.fromisoformat(normalized.replace("Z", "+00:00"))
        # 无时区的时刻退化为来源日期，绝不假定为 UTC。
        return parsed.isoformat() if parsed.tzinfo else parsed.date().isoformat()
    except ValueError:
        try:
            parsed = parsedate_to_datetime(value)
            return parsed.isoformat() if parsed.tzinfo else parsed.date().isoformat()
        except (ValueError, TypeError, OverflowError):
            return ""


def day_of(value):
    if not value:
        return None
    if len(value) == 10:
        return date.fromisoformat(value)
    return datetime.fromisoformat(value).astimezone(BJ).date()


def parse_feed(data):
    # External RSS DTD declarations do not require fetching a remote resource;
    # ElementTree does not resolve them. Reject entity declarations/internal
    # subsets and unsupported NUL-based encodings before parsing.
    if b'\x00' in data or b"<!ENTITY" in data.upper() or re.search(br'<!DOCTYPE[^>]*\[',data,re.I):
        raise ResearchError("来源 XML 包含不支持的实体声明。")
    try:
        root = ET.fromstring(data)
    except ET.ParseError:
        raise ResearchError("来源没有返回有效 RSS/Atom。") from None
    if local_name(root.tag) not in ("rss", "RDF", "feed"):
        raise ResearchError("来源内容不是 RSS/Atom。")
    items = []
    for node in root.iter():
        if local_name(node.tag) not in ("item", "entry"):
            continue
        fields = {}
        authors = []
        for child in node:
            key = local_name(child.tag)
            text = clean(" ".join(child.itertext()))
            if key == "link" and child.attrib.get("href") and child.attrib.get("rel", "alternate") == "alternate":
                fields["link"] = child.attrib["href"]
            elif key in ("creator", "author"):
                if text:
                    authors.append(text)
            else:
                fields.setdefault(key, text)
        stamp = next((fields[k] for k in ("pubDate", "published", "date", "publicationDate") if fields.get(k)), "")
        # updated 不是原始发布日期，单独提供 updated 的条目不纳入。
        items.append({"title": fields.get("title", ""), "url": fields.get("link", ""),
                      "summary": fields.get("description") or fields.get("summary") or fields.get("encoded", ""),
                      "publication_time": normalize_time(stamp), "raw_date": stamp, "authors": authors,
                      "doi": fields.get("doi", ""), "publisher": fields.get("source", "")})
    return items


def ld_articles(value):
    if isinstance(value, list):
        for child in value:
            yield from ld_articles(child)
    elif isinstance(value, dict):
        types = value.get("@type", [])
        if isinstance(types, str):
            types = [types]
        if set(types) & {"Article", "NewsArticle", "BlogPosting", "ScholarlyArticle", "TechArticle"}:
            yield value
        if "@graph" in value:
            yield from ld_articles(value["@graph"])


def read_source(source, target=None):
    if source.get('mode')in('jif_date_discovery','pubmed_date_discovery','europepmc_date_discovery'):
        from journal_discovery import discover,DiscoveryError
        try:
            if source['mode']=='jif_date_discovery':
                records,coverage=discover(source['_registry_root'],target,fetch)
            else:
                from scholarly_daily import discover as independent
                provider='pubmed'if source['mode']=='pubmed_date_discovery'else'europepmc'
                records,coverage=independent(source['_registry_root'],target,provider,fetch)
        except DiscoveryError as exc:raise ResearchError(str(exc)) from exc
        source['_discovery_coverage']=coverage
        return [{'title':clean(r['title'][0]),'doi':normalize_doi(r['DOI']),
                 'url':'https://doi.org/'+normalize_doi(r['DOI']),
                 'summary':r.get('abstract',''),'authors':author_details(r)[0],
                 'publication_time':target.isoformat(),'raw_date':target.isoformat(),'_record':r}
                for r in records]
    if source.get('mode') == 'annual_news':
        year = (target or datetime.now(BJ).date()).year
        return [{"title":"", "url": template.format(year=year), "summary":"", "publication_time":"", "raw_date":"", "authors":[]}
                for template in source['templates']]
    try:
        data = fetch(source["url"])
        if source.get("mode") != "html_index":
            entries = parse_feed(data)
            if source.get('crossref_discovery') and target is not None:
                try:
                    entries.extend(crossref_journal_entries(source,target))
                except ResearchError:
                    LOG.warning("期刊补充检索暂不可用：%s",source['name'])
            return entries
    except ResearchError:
        if source.get("crossref_fallback") and target is not None and not source.get("mixed_journals"):
            return crossref_journal_entries(source, target)
        raise
    page = Page()
    page.feed(data.decode("utf-8", errors="replace"))
    base = urllib.parse.urlsplit(source["url"])
    prefix = base.path.rstrip("/") + "/"
    index_dates = {}
    if source.get("index_dates") == "cas":
        for href, title, year, month, day in re.findall(
                r'<li>\s*<a[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>\s*<span>\s*(\d{4})年(\d{2})月(\d{2})日',
                data.decode("utf-8", errors="replace"), re.S):
            index_dates[urllib.parse.urljoin(source["url"], href)] = (clean(title), "-".join((year, month, day)))
    entries, seen = [], set()
    for href in page.links:
        url = urllib.parse.urljoin(source["url"], href)
        parsed = urllib.parse.urlsplit(url)
        path_matches = bool(re.search(source["article_path"], parsed.path)) if source.get("article_path") else parsed.path.startswith(prefix)
        if (parsed.hostname != base.hostname or not path_matches
                or parsed.path.rstrip("/") == base.path.rstrip("/")
                or parsed.path.endswith((".xml", ".rss")) or url in seen):
            continue
        seen.add(url)
        index_title, index_date = index_dates.get(url, ("", ""))
        entries.append({"title": index_title, "url": url, "summary": "", "publication_time": index_date,
                        "raw_date": index_date, "authors": []})
    if not entries:
        raise ResearchError("机构页面没有可读取的文章链接。")
    return entries


def crossref_journal_entries(source, target):
    """Backup discovery uses publisher-deposited online dates, never index dates."""
    parameters = {"query.container-title":source["name"], "filter":
        "type:journal-article,from-online-pub-date:" + target.isoformat()
        + ",until-online-pub-date:" + target.isoformat(), "rows":"100"}
    url = "https://api.crossref.org/works?" + urllib.parse.urlencode(parameters)
    try:
        records = json.loads(fetch(url))["message"]["items"]
    except (ValueError, KeyError, TypeError):
        raise ResearchError("备用期刊登记信息无法解析。") from None
    entries = []
    for record in records:
        journals = record.get("container-title", [])
        doi = normalize_doi(record.get("DOI"))
        if (not doi or record.get("type") != "journal-article"
                or publication_date(record) != target.isoformat()
                or not any(name_key(journal) == name_key(source["name"]) for journal in journals)):
            continue
        titles = record.get("title", [])
        if not titles:
            continue
        authors, _, _ = author_details(record)
        entries.append({"title":clean(titles[0]), "doi":doi, "url":"https://doi.org/" + doi,
                        "summary":record.get("abstract", ""), "authors":authors,
                        "publication_time":target.isoformat(), "raw_date":target.isoformat(),
                        "_record":record})
    LOG.info("期刊订阅备用检索：%s，出版社登记的目标日论文 %s 篇。", source["name"], len(entries))
    return entries


def article_info(data):
    page = Page()
    page.feed(data.decode("utf-8", errors="replace"))
    result = {"date": "", "date_evidence": "", "authors": [], "institutions": [], "title": "",
              "summary": "", "paragraphs": page.paragraphs, "journal": "", "doi": "",
              "article_type": "", "author_affiliations": [], "byline": [], "publisher": "",
              "first_authors": [], "corresponding_authors": []}
    for key in ("citation_title", "og:title", "twitter:title"):
        if page.meta.get(key):
            result["title"] = clean(page.meta[key][0])
            break
    for key in ("citation_online_date", "citation_publication_date", "article:published_time", "dc.date", "prism.publicationdate", "citation_date", "pubdate", "publishdate", "publishdate_time", "pubtime"):
        for value in page.meta.get(key, []):
            stamp = normalize_time(value)
            if stamp:
                result.update(date=stamp, date_evidence=f"原文元数据 {key}={value}")
                break
        if result["date"]:
            break
    result["authors"] = page.meta.get("citation_author", [])
    result["byline"] = page.meta.get("author", [])
    result["publisher"] = next((clean(page.meta[k][0]) for k in ("contentsource", "publisher", "dc.publisher") if page.meta.get(k)), "")
    result["institutions"] = page.meta.get("citation_author_institution", [])
    result["institutions"].extend(page.affiliation_headings)
    if page.author_pairs and all(p['institutions'] for p in page.author_pairs):
        result['author_affiliations'] = merge_author_affiliations([], page.author_pairs)
    for target_key, meta_keys in (("journal", ("citation_journal_title", "prism.publicationname", "dc.source")),
                                  ("doi", ("citation_doi", "prism.doi")),
                                  ("article_type", ("citation_article_type", "dc.type", "prism.section"))):
        result[target_key] = next((clean(page.meta[k][0]) for k in meta_keys if page.meta.get(k)), "")
    for key in ("citation_abstract", "dc.description", "description", "og:description"):
        if page.meta.get(key):
            result["summary"] = clean(page.meta[key][0])
            break
    for ld in page.ld:
        for article in ld_articles(ld):
            if not result["date"]:
                raw = article.get("datePublished", "")
                stamp = normalize_time(raw)
                if stamp:
                    result.update(date=stamp, date_evidence=f"原文 datePublished={raw}")
            if not result["summary"]:
                result["summary"] = clean(article.get("description", ""))
            if not result["journal"] and isinstance(article.get("isPartOf"), dict):
                result["journal"] = clean(article["isPartOf"].get("name", ""))
            authors = article.get("author", [])
            if isinstance(authors, dict):
                authors = [authors]
            if not isinstance(authors, list):
                authors = []
            for author in authors:
                if not isinstance(author, dict) or not author.get("name"):
                    continue
                name = clean(author["name"])
                if name not in result["authors"]:
                    result["authors"].append(name)
                affiliations = author.get("affiliation", [])
                if isinstance(affiliations, (dict, str)):
                    affiliations = [affiliations]
                if not isinstance(affiliations, list):
                    affiliations = []
                units = [clean(a.get("name", "") if isinstance(a, dict) else a) for a in affiliations if isinstance(a, (dict, str))]
                units = [u for u in units if u]
                result["institutions"].extend(units)
                if units:
                    result['author_affiliations'] = merge_author_affiliations(result['author_affiliations'], [{'name':name,'institutions':units}])
    if page.abstract_text:
        result["summary"] = clean(" ".join(page.abstract_text)).removeprefix("Abstract ")
    roles = jats_roles(data)
    if roles["first_authors"]:
        result["first_authors"] = roles["first_authors"]
        if not result["authors"]:
            result["authors"] = roles["authors"]
    result["corresponding_authors"] = roles["corresponding_authors"] or meta_correspondents(page.meta, result["authors"])
    result['author_affiliations'] = merge_author_affiliations(result['author_affiliations'], roles['author_affiliations'])
    result['author_affiliations'] = merge_author_affiliations(result['author_affiliations'], html_affiliations(data, result['authors']))
    if not result["first_authors"]:
        result["first_authors"] = result["authors"][:1]
    return result


def short_excerpt(value, word_limit):
    """提取有限长度的原文要点；中文按字符控制。"""
    if word_limit <= 0:
        return ""
    value = clean(value)
    if re.search(r"[\u4e00-\u9fff]", value):
        limit = min(160, word_limit * 2)
        return value[:limit] + ("…" if len(value) > limit else "")
    words = value.split()
    return " ".join(words[:word_limit]) + ("…" if len(words) > word_limit else "")


def extract_quote(paragraphs):
    for paragraph in paragraphs:
        match = re.search(r'[“"]([^”"]{10,500})[”"]\s*,?\s*(?:says|said|explains|adds)\s+([A-Z][A-Za-z.-]+(?:\s+[A-Z][A-Za-z.-]+){1,3})', paragraph)
        if match:
            return match.group(2).rstrip(".,;:"), match.group(1)
    return "", ""


def collect_source(source, target):
    registry=None
    if source.get('_registry_root'):
        from journal_discovery import JournalRegistry
        registry=JournalRegistry.load(source['_registry_root'])
    entries = read_source(source, target)
    candidates = []
    for entry in entries:
        day = day_of(entry["publication_time"])
        # 期刊/机构订阅已有原始日期，只读取目标日；arXiv 公告可能比提交晚一天。
        dated_candidate = day is not None and abs((day - target).days) <= 1
        if valid_url(entry["url"]) and (dated_candidate
                                       or (source.get("mode") in ("html_index", "annual_news") and day is None)):
            candidates.append(entry)
    candidates.sort(key=lambda entry: -sum(keyword in (entry["title"] + " " + entry["summary"]).lower()
                                             for keyword in KEYWORDS.get(source["topic"], KEYWORDS["化学"])))
    # Read every dated candidate exposed by the feed; no pre-ranking truncation.
    def read_page(entry):
        if entry.get("_record"):
            record = entry["_record"]
            authors, units, pairs = author_details(record)
            return {"date":publication_date(record), "date_evidence":record.get('_date_evidence')or"Crossref 出版社登记的在线发表日期",
                    "authors":authors, "institutions":units, "author_affiliations":pairs,
                    "summary":record.get("abstract", ""), "paragraphs":[], "journal":clean((record.get('container-title') or [source['name']])[0]),
                    "doi":normalize_doi(record.get("DOI")), "title":clean(record["title"][0])}
        if source.get('aggregator'):
            return None
        try:
            data = fetch(entry["url"])
            info = article_info(data)
            if source['topic'] == NEWS_TOPIC:
                from news_sources import enrich_news_page
                info = enrich_news_page(info, data, source)
            # HTTP 200 can still be a bot challenge rather than an article.
            return info if info["date"] or info["journal"] or info["authors"] or (source["topic"] == NEWS_TOPIC and info.get("_news_body")) else None
        except ResearchError:
            return None
    with ThreadPoolExecutor(max_workers=3) as executor:
        pages = list(executor.map(read_page, candidates))
    result, page_failures = [], 0
    for entry, loaded_page in zip(candidates, pages):
        if re.match(r"^(author correction|publisher correction|correction|retraction|editorial|obituary|erratum|research briefing|research highlight|news and views|cover picture|cover profile|cover feature|front cover|back cover)\b", entry["title"], re.I):
            continue
        info = {"date": "", "date_evidence": "", "authors": [], "institutions": [], "summary": "", "paragraphs": []}
        if loaded_page is None:
            page_failures += 1
        else:
            info = loaded_page
        if source.get("research_only") and re.search(r"\b(news|comment|editorial|highlight|obituary|correction|retraction)\b", info.get("article_type", ""), re.I):
            continue
        if source.get("mixed_journals") and not info.get("journal"):
            # A subject feed's name is not the actual journal name.
            continue
        stamp = info["date"] or entry["publication_time"]
        if source.get("require_page_date") and not info["date"]:
            # Issue TOC feeds can timestamp every article with the issue date.
            # Such a feed alone cannot establish a paper's first online date.
            continue
        if day_of(stamp) != target:
            continue
        if source["kind"] == "预印本" and not info["date"]:
            # arXiv RSS 常为公告日，不能证明首次提交日。
            continue
        if source["kind"] == "预印本" and re.search(r"\b(replacement|updated|revision|v[2-9])\b", entry["summary"], re.I):
            continue
        title = clean(info.get("title") or entry["title"])
        if not title:
            continue
        metric=None
        if registry:
            record=entry.get('_record',{})
            metric=registry.match(info.get('journal') or source['name'],record.get('ISSN',[]))
            if not metric:continue
        if source["topic"] == NEWS_TOPIC:
            news = make_news_item(source, entry, info, title, stamp)
            if news:
                result.append(news)
            continue
        budget = max(0, 25 - len(title.split()))
        speaker, quotation = extract_quote(info["paragraphs"])
        quoted = short_excerpt(quotation, min(10, budget)) if speaker else ""
        summary = short_excerpt(info["summary"] or entry["summary"], budget - len(quoted.split()))
        people = list(dict.fromkeys(info["authors"] or (entry["authors"] if source["kind"] != "机构资讯" else [])))
        if speaker and speaker not in people:
            people.append(speaker)
        units = list(dict.fromkeys(info["institutions"]))
        if not units and source.get("publisher"):
            units = [source["publisher"] + "（发布单位，不能据此认定全部研究人员归属）"]
        text = (entry["title"] + " " + entry["summary"]).lower()
        matched = [keyword for keyword in KEYWORDS[source["topic"]] if keyword in text]
        outline, areas, signals, values = chemistry_outline(title, info["summary"] or entry["summary"])
        score = source.get("weight", 50) + min(len(signals), 3) * 4 + min(len(values), 3) * 2
        priority = chemical_biology_priority(title, info["summary"] or entry["summary"], info.get("journal") or source["name"])
        if priority:
            score += 30
        rationale = "期刊来源：" + (info.get("journal") or source["name"]) + "；研究方向：" + "、".join(areas or ["化学研究"])
        if signals or values:
            rationale += "；摘要/标题线索：" + "、".join(signals + values)
        rationale += "。线索仅用于自动筛选，重要性仍需阅读论文判断。"
        item = {"title": title, "kind": source["kind"], "people": people, "institutions": units,
                "author_affiliations": info.get("author_affiliations", []),
                "first_authors": info.get("first_authors", []) or people[:1],
                "corresponding_authors": info.get("corresponding_authors", []),
                "doi": info.get("doi", "") or entry.get("doi", ""),
                "action": ("发表/发布了这篇内容。公开摘要短摘录：" + summary) if summary else "发表/发布了这篇内容；详情请阅读原文。",
                "significance": "规则筛选依据：" + source["name"] + "，主题词：" + ("、".join(matched) or "该领域专题源") + "。此排序不代表对技术突破的专家判断。",
                "limitations": "自动提取，未进行人工科学核验；英文信息保留原文。" + ("预印本尚未同行评审。" if source["kind"] == "预印本" else "期刊栏目/成果验证阶段以原文为准。") + ("原文页面未能读取，仅依据官方订阅源，人物/单位可能不完整。" if not info["date"] else ""),
                "paper_title": title, "venue": info.get("journal") or source["name"], "publication_time": stamp,
                "date_evidence": info["date_evidence"] or "官方 RSS 原始发布日期：" + entry["raw_date"],
                "primary_source_id": "", "date_source_id": "", "source_ids": [],
                "quote": {"speaker": speaker if quoted else "", "original": quoted,
                          "translation": "", "source_id": ""},
                "_url": entry["url"], "_score": score, "_area": areas[0] if areas else "化学研究",
                "chemical_biology_priority":priority,
                "_page_date": "" if entry.get("_record") else info["date"], "_abstract": info["summary"] or entry["summary"],
                "_abstract_source": entry.get('_record',{}).get('_metadata_provider','Crossref')+" 出版社登记摘要" if entry.get("_record") else (
                    "期刊公开页面摘要" if info["summary"] else "期刊官方 RSS 摘要")}
        if source["topic"] == "化学":
            item.update(action=outline, significance=rationale)
        if entry.get('_record'):item['_metadata_record']=entry['_record']
        item['discovery_sources']=[source['name']]
        if metric:item['journal_impact_factor']=registry.evidence(metric)
        result.append(item)
    status={"name": source["name"], "url": source["url"], "status": "ok", "page_failures": page_failures,
            "dated_candidates": len(candidates), "eligible_articles": len(result)}
    if source.get('_discovery_coverage'):
        status.update(source['_discovery_coverage'])
    return result,status


def make_news_item(source, entry, info, title, stamp):
    from news_sources import news_source_ready, news_actors
    if source.get('aggregator'):
        # Search feeds discover headlines; they are never accepted as article bodies.
        return None
    summary = info.get('_news_body') or info['summary'] or entry['summary'] or ' '.join(info['paragraphs'][:5])
    if not news_source_ready(summary):return None
    text = title + ' ' + summary
    # The story title/lead must carry chemical substance. Footer and related-story
    # mentions of chemistry, institutes or molecular evolution are insufficient.
    focused = title + ' ' + summary[:900]
    specific = re.search(r'\b(chemistr\w*|chemical\w*|catal\w*|electrochem\w*|battery|batteries|polymer\w*|synthesi[sz]\w*|pfas|aerogel\w*|coordination|spectroscop\w*|nanoparticl\w*|perovskit\w*|scintillat\w*|hydrogen|reaction\w*)\b|化学|催化|电化学|电池|聚合物|化工|合成|抗菌肽|短肽|药物|化学探针|生物正交|锡基|电解液|气凝胶|光谱|配位|单原子|电极|钙钛矿|储氢|有机|无机|二氧化碳|碳捕集',focused,re.I)
    if not source.get('chemistry_specific') and not specific:return None
    if NEWS_ADMIN.search(title):
        return None
    if not source.get("chemistry_specific") and not CHEMISTRY_NEWS.search(text):
        return None
    reasons = [label for label, pattern in MAJOR_NEWS.items() if pattern.search(text)]
    if not reasons:
        return None
    speaker, quote = extract_quote(info["paragraphs"])
    units = list(dict.fromkeys(info["institutions"]))
    publisher = info.get("publisher") or entry.get('publisher') or source.get("publisher", source["name"])
    if source.get('aggregator') and re.search(r'facebook|instagram|tiktok|pinterest|youtube', publisher, re.I):
        return None
    for part in re.split(r'[,，]',publisher):
        part = part.strip()
        if re.search(r'大学|研究所|研究院|University|Institute',part,re.I) and part in summary and part not in units:
            full = '中国科学院' + part if '中国科学院' + part in summary else part
            units.append(full)
    actors,units=news_actors(summary,units)
    if speaker and speaker not in actors:actors.append(speaker)
    item = {"title": title, "kind": "化学新闻", "paper_title": "", "people": actors,
            "institutions": units, "publisher": publisher, "news_byline": info.get("byline", []),
            "action": "消息要点（原文短摘录）：" + short_excerpt(summary, 55) if summary else "请查看原始公告正文。",
            "significance": "关注依据：" + "、".join(reasons) + "。报道中的突破和应用仍以原始证据为准。",
            "limitations": "新闻发布日期不等于所述论文的发表日期；未把报道作者认定为研究人员。",
            "venue": source["name"], "publication_time": stamp,
            "date_evidence": info["date_evidence"] or ("官方栏目列表日期：" + entry["raw_date"] + "；列表：" + source["url"] if source.get("index_dates") else "官方 RSS 原始发布日期：" + entry["raw_date"]),
            "primary_source_id": "", "date_source_id": "", "source_ids": [],
            "quote": {"speaker": speaker, "original": short_excerpt(quote, 10) if speaker else "", "translation": "", "source_id": ""},
            "_url": entry["url"], "_score": source.get("weight", 50) + 10 * len(reasons), "_area": reasons[0],
            "_news_content":clean(summary), "_headline_only":False,
            "news_source_text":clean(summary),
            "news_evidence":{"kind":"original-page" if info.get('_news_body') else "official-feed-body",
                             "url":entry['url'],"characters":len(clean(summary)),
                             "sha256":hashlib.sha256(clean(summary).encode()).hexdigest()}}
    if source.get('aggregator'):
        item['_link_label'] = '新闻聚合链接；发布机构：' + publisher
        item['limitations'] += '只取得聚合订阅的标题和发布日期，未核验原始报道正文。'
    if source.get('official_award'):
        from news_sources import apply_award_details
        apply_award_details(item, info.get('_news_text', text))
    if re.search(r'nobel.*(?:chemistry|chemists)|(?:chemistry|chemists).*nobel|诺贝尔化学奖', item['title'], re.I):
        year = re.search(r'20\d{2}', item['title'])
        if year:
            item['_event_key'] = 'nobel-chemistry-' + year.group()
        else:
            item['_event_key'] = 'nobel-chemistry-' + str(day_of(stamp).year)
        item['_score'] += 500
    return item


def enrich_paper(item, client, target):
    """Exact DOI lookup only. Return False for demonstrably recycled feed entries."""
    affiliation_cache=getattr(client,'cache_directory',None)
    affiliation_root=Path(affiliation_cache).parent.parent if isinstance(affiliation_cache,(str,Path)) else None
    if affiliation_root is not None:
        from affiliation_sources import POLICY
        item['affiliation_policy']=POLICY
    doi = normalize_doi(item.get("doi"))
    item["metadata_status"] = "missing-doi"
    if not doi:
        item["limitations"] += "没有可验证的 DOI，无法补查文献信息。"
        return True
    try:
        deposited=item.pop('_metadata_record',None)
        record = deposited if isinstance(deposited,dict) and normalize_doi(deposited.get('DOI'))==doi else client.lookup(doi)
    except MetadataError as error:
        item["metadata_status"] = "unavailable"
        item["limitations"] += str(error) + "；作者和单位以已读取来源为准。"
        if affiliation_root is not None:
            from affiliation_sources import supplement_affiliations
            supplement_affiliations(item,affiliation_root)
        return True
    if record.get("type") != "journal-article":
        return False
    provider=record.get('_metadata_provider','Crossref')
    online_date = publication_date(record)
    if online_date:
        item["online_publication_date"] = online_date
        if not item.get("_page_date") and online_date != target.isoformat():
            # A fully timestamped official feed can cross the Beijing day boundary;
            # a date-only Crossref deposit cannot resolve that one-day difference.
            precise_feed = len(item["publication_time"]) > 10
            if not precise_feed or abs((date.fromisoformat(online_date) - target).days) > 1:
                return False
            item["limitations"] += "Crossref 在线日期与北京时间订阅时间相差一天；Crossref 未披露时区，按官方订阅时间纳入。"
        elif item.get("_page_date") and online_date != day_of(item["_page_date"]).isoformat():
            item["limitations"] += "Crossref 在线日期与原文日期不同，按原文日期纳入。"
    authors, units, pairs = author_details(record)
    supplied = []
    if not item["people"] and authors:
        item["people"] = authors
        supplied.append("作者")
    if not item.get("first_authors") and item["people"]:
        item["first_authors"] = item["people"][:1]
    if not item["institutions"] and units:
        item["institutions"] = units
        supplied.append("作者单位")
    known_names = {" ".join(name.casefold().split()) for name in item["people"]}
    known_names = {name_key(name) for name in item["people"]}
    added_pairs = [pair for pair in pairs if name_key(pair['name']) in known_names]
    if added_pairs:
        item['author_affiliations'] = merge_author_affiliations(item['author_affiliations'], added_pairs)
        supplied.append("作者与单位对应")
    from affiliation_sources import supplement_affiliations
    if affiliation_root is not None:
        supplement_affiliations(item,affiliation_root)
    item["metadata_status"] = "ok"
    if (isinstance(record.get("abstract"), str) and clean(record["abstract"])
            and len(clean(record['abstract'])) >= len(clean(item.get('_abstract','')))):
        item["_abstract"] = record["abstract"]
        item["_abstract_source"] = provider+" 出版社登记摘要"
        supplied.append("摘要")
    if online_date:
        supplied.append("在线发表日期")
    journal = record.get("container-title", [])
    if journal and isinstance(journal, list) and isinstance(journal[0], str):
        supplied.append("期刊名称核对")
        item["crossref_journal"] = clean(journal[0])
    item["bibliographic_evidence"] = provider+" 出版社登记元数据：" + "、".join(supplied or ["DOI 核对"])
    item["_metadata_url"] = record.get('_provider_url')or client.url(doi)
    mapped_names = {" ".join(pair["name"].casefold().split()) for pair in item["author_affiliations"]}
    unmapped = [name for name in item["people"] if " ".join(name.casefold().split()) not in mapped_names]
    if unmapped:
        item["limitations"] += "未取得可靠的逐人单位对应：" + "、".join(unmapped) + "。"
    if "作者" in supplied or "作者单位" in supplied:
        item["limitations"] += "补充作者/单位来自 "+provider+" 登记信息，并非已读取订阅全文。"
    return True


def merge_candidate_metadata(existing,incoming):
    """Combine exact-DOI evidence instead of discarding a richer second index."""
    left=normalize_doi(existing.get('doi'));right=normalize_doi(incoming.get('doi'))
    if not left or left!=right:return
    existing['author_affiliations']=merge_author_affiliations(existing.get('author_affiliations',[]),
                                                            incoming.get('author_affiliations',[]))
    for key in ('people','first_authors','corresponding_authors'):
        if not existing.get(key)and incoming.get(key):existing[key]=list(incoming[key])
    existing['institutions']=list(dict.fromkeys(existing.get('institutions',[])+incoming.get('institutions',[])))
    if len(incoming.get('_abstract',''))>len(existing.get('_abstract','')):
        existing['_abstract']=incoming['_abstract']
        existing['_abstract_source']=incoming.get('_abstract_source','')
    existing['discovery_sources']=list(dict.fromkeys(existing.get('discovery_sources',[])+incoming.get('discovery_sources',[])))


def research_topic(root, topic, target, maximum, metadata_client=None, excluded_keys=None):
    from paper_history import paper_keys
    excluded_keys = excluded_keys or set()
    try:
        sources = json.loads((Path(root) / "sources.json").read_text(encoding="utf-8"))
        selected = [source for source in sources if source["topic"] == ("化学" if topic == BIO_TOPIC else topic)
                    and (topic not in ("化学",BIO_TOPIC) or source["kind"] == "期刊论文")
                    and (not source.get('editions') or ('chemical-biology' if topic == BIO_TOPIC else 'chemistry') in source['editions'])]
    except (ValueError, KeyError, TypeError, OSError):
        raise ResearchError("sources.json 来源配置无法读取。") from None
    expanded=False
    candidate_limit=200
    if topic=='化学':
        from journal_discovery import enabled,JournalRegistry,DiscoveryError,query_url
        try:
            expanded=enabled(root)
            if expanded:
                registry=JournalRegistry.load(root)
                policy=json.loads((Path(root)/'journal-search.json').read_text(encoding='utf-8'))
                candidate_limit=policy.get('maximum_candidates_checked',600)
                if type(candidate_limit)is not int or not 200<=candidate_limit<=2000:
                    raise DiscoveryError('候选核查上限配置无效。')
                selected=[dict(source,_registry_root=str(root)) for source in selected
                          if source.get('mixed_journals') or registry.match(source['name'])]
                selected.append({'topic':'化学','name':'JIF>6 全学科期刊在线日期检索',
                                 'url':query_url(target),'kind':'期刊论文','research_only':True,
                                 'mixed_journals':True,'weight':95,'mode':'jif_date_discovery',
                                 '_registry_root':str(root)})
                from scholarly_daily import pubmed_url,epmc_url
                providers={'pubmed':('PubMed 跨期刊电子首发检索',pubmed_url),
                           'europepmc':('Europe PMC 跨期刊在线日期检索',epmc_url)}
                for provider in policy.get('independent_indices',[]):
                    if provider not in providers:raise DiscoveryError('独立索引配置无效。')
                    label,url=providers[provider]
                    selected.append({'topic':'化学','name':label,'url':url(target),'kind':'期刊论文',
                                     'research_only':True,'mixed_journals':True,'weight':95,
                                     'mode':provider+'_date_discovery','_registry_root':str(root)})
        except DiscoveryError as exc:raise ResearchError(str(exc)) from exc
    if not selected:
        raise ResearchError("本领域没有配置资讯来源。")
    LOG.info("正在直接读取 %s 的 %s 个公开来源：%s", topic, len(selected), target)
    articles, coverage = [], []
    with ThreadPoolExecutor(max_workers=4) as executor:
        jobs = [(source, executor.submit(collect_source, source, target)) for source in selected]
        for source, future in jobs:
            try:
                found, status = future.result()
                articles.extend(found)
                coverage.append(status)
            except ResearchError as error:
                LOG.warning("来源 %s 读取失败：%s", source["name"], error)
                coverage.append({"name": source["name"], "url": source["url"], "status": "failed", "reason": str(error)})
    articles.sort(key=lambda item: (-item["_score"], -bool(item["institutions"]), -bool(item["people"]), item["title"]))
    unique, identities = [], {}
    for item in articles:
        if topic != NEWS_TOPIC and paper_keys(item) & excluded_keys:
            continue
        doi = item.get("doi", "").lower().strip().removeprefix("https://doi.org/")
        key = item.get('_event_key') or doi or re.sub(r"\W+", "", item["title"].casefold())
        if key in identities:
            if topic!=NEWS_TOPIC:merge_candidate_metadata(identities[key],item)
            continue
        identities[key]=item
        unique.append(item)
    client = (metadata_client or CrossrefClient(Path(root) / "data" / "crossref")) if topic in ("化学",BIO_TOPIC) else None
    metadata_attempts = 0
    if topic == BIO_TOPIC:
        biological = []
        for item in unique:
            if name_key(item['venue']) not in PRIORITY_JOURNALS:
                continue
            metadata_attempts += 1
            if not enrich_paper(item, client, target):
                continue
            journal = item.get('crossref_journal') or item['venue']
            if not chemical_biology_paper(item['title'],item.get('_abstract',''),journal):
                continue
            item['_metadata_enriched'] = True
            item['chemical_biology_priority'] = True
            biological.append(item)
        unique = sorted(biological,key=lambda item:(-item['_score'],item['title']))
        LOG.info("化学生物学专报：日期与主题复核后保留 %s 篇高质量期刊候选。",len(unique))
    # Preserve ranking within each direction while avoiding one journal crowding
    # every available slot when other qualifying journals are present.
    balanced, deferred, counts = [], [], {}
    for item in unique:
        journal = name_key(item["venue"])
        if topic != NEWS_TOPIC and counts.get(journal, 0) >= 4:
            deferred.append(item)
        else:
            balanced.append(item)
            counts[journal] = counts.get(journal, 0) + 1
    chosen, links, seen = [], [], set()
    incomplete_count = 0
    summary_attempts = 0
    candidate_attempts=0
    translator = translator_for(root) if topic in ("化学",BIO_TOPIC,NEWS_TOPIC) else None
    for item in (balanced + deferred):
        url = item["_url"]
        if url in seen:
            continue
        if client:
            candidate_attempts+=1
            if expanded and candidate_attempts>candidate_limit:
                LOG.warning('已核查%s篇候选，剩余候选保留在检索缓存中。',candidate_limit);break
            if not item.pop('_metadata_enriched',False):
                metadata_attempts += 1
                if not enrich_paper(item, client, target):
                    continue
            if paper_keys(item) & excluded_keys:
                continue
            if item.get('affiliation_policy'):
                from affiliation_sources import units_complete
                if not units_complete(item):
                    incomplete_count+=1
                    LOG.info('候选论文院系或国家尚未核实，换选下一篇：%s',item.get('doi',''))
                    continue
            summary_attempts += 1
            summarize_item(item, translator)
            if translator and not complete_item(item):
                incomplete_count += 1
                LOG.warning("候选论文补全后仍不完整，换选下一篇：%s", item.get("doi", "无 DOI"))
                if summary_attempts >= maximum + 10:
                    break
                continue
        if topic == NEWS_TOPIC:
            from news_sources import NEWS_CONTENT_VERSION, complete_news_item, reviewed_news_analysis
            content = item.pop('_news_content', '')
            item.pop('_headline_only',None)
            if not translator:
                LOG.warning('新闻缺少正文分析模型，停止将短摘录作为新闻发送。')
                continue
            headline=item['title']
            analysis=reviewed_news_analysis(headline,content) or translator.analyze(headline,content,news=True)
            if not analysis.get('title_zh') or not analysis.get('summary') or not analysis.get('selection_reason'):
                LOG.warning('新闻正文或具体重要性分析不完整，换选下一条。')
                continue
            item.update(title_zh=analysis['title_zh'], action=analysis['summary'],
                        news_importance=analysis['selection_reason'], news_content_version=NEWS_CONTENT_VERSION)
            if not complete_news_item(item):
                LOG.warning('新闻正文未通过具体内容检查，换选下一条。')
                continue
        item.pop("_url")
        item.pop("_score")
        item.pop("_area", None)
        item.pop("_event_key", None)
        item.pop("_page_date", None)
        item.pop("_abstract", None)
        item.pop("_abstract_source", None)
        item.pop('_metadata_record',None)
        seen.add(url)
        source_id = "s" + str(len(links) + 1)
        links.append({"id": source_id, "url": url, "title": item.pop('_link_label', "原文链接")})
        item.update(primary_source_id=source_id, date_source_id=source_id, source_ids=[source_id])
        metadata_url = item.pop("_metadata_url", "")
        if metadata_url:
            metadata_id = "s" + str(len(links) + 1)
            links.append({"id": metadata_id, "url": metadata_url, "title": "Crossref 文献信息（出版社登记）"})
            item["source_ids"].append(metadata_id)
        for affiliation_url in item.get('affiliation_sources',[]):
            affiliation_id='s'+str(len(links)+1)
            links.append({'id':affiliation_id,'url':affiliation_url,'title':'出版社作者署名与补充材料'})
            item['source_ids'].append(affiliation_id)
        if item["quote"]["original"]:
            item["quote"]["source_id"] = source_id
        chosen.append(item)
        if len(chosen) >= maximum:
            break
    failed = sum(source["status"] == "failed" for source in coverage)
    page_failures = sum(source.get("page_failures", 0) for source in coverage)
    metadata_failures = sum(item.get("metadata_status") != "ok" for item in chosen) if client else 0
    partial_sources=any(source['status']=='partial' for source in coverage)
    state = "failed" if failed == len(selected) else "partial" if failed or page_failures or metadata_failures or partial_sources else "ok"
    note = f"已读取 {len(selected) - failed}/{len(selected)} 个来源。"
    if topic == NEWS_TOPIC:
        note += f"筛选 {len(chosen)} 条目标日重大化学相关新闻。"
        if not chosen:
            note += "已读取的来源中未发现同时满足日期、化学关联和重要事件条件的新闻。"
    else:
        field = "高质量化学生物学" if topic == BIO_TOPIC else "化学"
        note += f"已读取来源有 {len(unique)} 篇符合日期与主题条件的{field}候选论文，筛选 {len(chosen)} 篇；公开来源不保证覆盖全部{field}论文。"
        if expanded:note+='本次按2026版公开指标清单中的2025年JIF>6期刊筛查，已结合跨出版社的在线日期登记与官方订阅；登记延迟或不可访问来源仍可能漏检。'
        with_authors = sum(bool(item["people"]) for item in chosen)
        with_units = sum(bool(item["institutions"]) for item in chosen)
        metadata_ok = sum(item.get("metadata_status") == "ok" for item in chosen)
        note += f"Crossref 文献信息查询成功 {metadata_ok}/{len(chosen)} 篇；最终 {with_authors} 篇有作者、{with_units} 篇有作者单位。"
        chinese_count = sum(item.get("summary_method") in ("local-summary", "reviewed-abstract-summary") for item in chosen)
        note += f"{chinese_count} 篇提供中文方法与结果要点。"
        if incomplete_count:
            note += f"{incomplete_count} 篇经补全仍缺少可靠摘要、中文分析或目标作者单位，已换选。"
            state = "partial"
    if topic != NEWS_TOPIC and len(chosen) < min(10, maximum):
        note += "可核实的目标日论文不足 10 篇，不使用其他日期的论文补足。"
    if failed:
        note += "未能读取：" + "、".join(s["name"] for s in coverage if s["status"] == "failed") + "。"
    if page_failures:
        note += f"有 {page_failures} 个原文页面未能读取，相关信息可能不完整。"
    if not chosen and topic != NEWS_TOPIC:
        note += "已读取的来源中未找到符合日期条件的新内容；这不等于该领域没有新进展。"
    if topic in ("化学",BIO_TOPIC) and translator and unique and not chosen:
        raise ResearchError("候选论文经补全仍未通过中文内容与作者单位完整性检查，请重试；未生成缺项论文日报。")
    return {"items": chosen, "sources": links, "status": state, "note": note,
            "coverage": coverage, "engine": ENGINE, "max_items": maximum,
            "source_hash": source_fingerprint(root), "eligible_count": len(unique),
            "summary_enabled": translator is not None,
            "quality_gate": "complete-chinese-v1" if translator else "",
            "metadata_attempts": metadata_attempts, "metadata_failures": metadata_failures,
            "candidate_checks":candidate_attempts,"summary_attempts":summary_attempts}
