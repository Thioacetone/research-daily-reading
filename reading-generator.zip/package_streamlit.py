"""Prepare a small, data-only Streamlit deployment, excluding mail secrets."""
from pathlib import Path
import shutil
import json
from paper_library import build_paper_library,publication_history
from zipfile import ZipFile, ZIP_DEFLATED
from reading_library import load_library

ROOT=Path(__file__).resolve().parent
OUTPUT=ROOT/'dist'/'streamlit-reader'
SOURCE_FILES=('app.py','app_branding.py','reading_library.py','reading_view.py','paper_library.py','reading_policy.py','cloud_bundle.py',
              'bilingual_mail.py','author_roles.py','chemical_typography.py',
              'requirements.txt','institution_names.json','department_names.json',
              'affiliation_countries.json')


def archive(name,files):
    with ZipFile(OUTPUT/name,'w',compression=ZIP_DEFLATED) as bundle:
        for file in files:
            bundle.write(file,file.relative_to(ROOT).as_posix())


def build():
    OUTPUT.mkdir(parents=True,exist_ok=True)
    for name in SOURCE_FILES:
        shutil.copyfile(ROOT/name,OUTPUT/name)
    reports,unavailable=load_library(ROOT)
    history_path=ROOT/'site-publication.json'
    previous=json.loads(history_path.read_text(encoding='utf-8')) if history_path.exists() else {}
    history=publication_history(build_paper_library(reports),previous)
    history_path.write_text(json.dumps(history,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    shutil.copyfile(history_path,OUTPUT/history_path.name)
    files=[ROOT/'assets'/name for name in ('program-art.jpg','reading-theme.css','reading-theme.js','streamlit-reader.css','reading-navigation.js')]
    for report in reports:
        files.extend([report['file'],report['file'].with_name('report.html')])
    archive('reading-content.zip',files)
    pictures=[p for p in sorted((ROOT/'graphics').rglob('*'))
              if p.is_file() and p.suffix.lower() in ('.jpg','.jpeg','.png','.webp','.gif','.bmp')
              and p.resolve().is_relative_to((ROOT/'graphics').resolve())]
    group=[];size=0;index=1
    for picture in pictures:
        length=picture.stat().st_size
        if length>6_500_000:
            raise ValueError('A picture exceeds the web upload bundle size')
        if group and size+length>6_500_000:
            archive(f'reading-graphics-{index:02d}.zip',group)
            index+=1;group=[];size=0
        group.append(picture);size+=length
    if group:
        archive(f'reading-graphics-{index:02d}.zip',group)
    (OUTPUT/'.gitignore').write_text('__pycache__/\n*.pyc\n.env\n.streamlit/secrets.toml\n.streamlit-cache/\ndata/\ngraphics/\nassets/\n',encoding='utf-8')
    (OUTPUT/'README.md').write_text(
        '# 每日论文精读 · Streamlit\n\n'
        'Streamlit Community Cloud：仓库选择 research-daily-reading，分支 main，入口 app.py。\n\n'
        '本程序只展示已发布的精读报告，不启动邮件发送或模型生成。\n'
        'reading-content.zip 保存报告和页面样式，reading-graphics-*.zip 保存原始配图。'
        '启动时自动展开，首页展示今日精读；往期目录支持类型与方向筛选，点击进入独立单篇阅读页。\n'
        '支持配图轮换与自动配色，不提供阅读页下载功能。\n'
        'site-publication.json 持久记录正文更新到网站的日期，刷新或仅修改界面不会重置日期。\n\n'
        '新报告需由独立任务生成后更新 reading-content.zip，再提交到仓库；'
        'Streamlit 随仓库更新部署。网页本身不提供准点定时生成服务。\n',encoding='utf-8')
    print(f'Prepared {len(reports)} reports and {len(pictures)} pictures; unavailable: {unavailable}')
    print(OUTPUT)


if __name__=='__main__':
    build()
