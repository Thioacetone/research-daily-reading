"""Free Crossref DOI metadata; no AI, login, or institutional credentials."""
from datetime import date, datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request


class MetadataError(Exception):
    pass


def normalize_doi(value):
    value = urllib.parse.unquote(str(value or "").strip())
    value = re.sub(r"^(?:https?://(?:dx\.)?doi\.org/|doi:\s*)", "", value, flags=re.I)
    return value.lower() if re.fullmatch(r"10\.\d{4,9}/[^\s?#]+", value) else ""


def publication_date(record, key="published-online"):
    """Only an explicitly recorded full publication date; never created/indexed."""
    try:
        parts = record[key]["date-parts"][0]
        if len(parts) != 3 or any(type(p) is not int for p in parts):
            return ""
        return date(*parts).isoformat()
    except (KeyError, IndexError, TypeError, ValueError):
        return ""


def _text(value):
    # Publisher affiliation deposits sometimes contain empty comma-separated fields.
    return " ".join(value.split()) if isinstance(value, str) else ""


def author_details(record):
    authors, institutions, pairs = [], [], []
    entries = record.get("author", [])
    for author in entries if isinstance(entries, list) else []:
        if not isinstance(author, dict):
            continue
        roles = author.get("role", [])
        if isinstance(roles, list) and roles and not any(
                isinstance(role, dict) and role.get("role") == "author" for role in roles):
            continue
        name = _text(author.get("name")) or " ".join(filter(None, (
            _text(author.get("given")), _text(author.get("family")))))
        if not name:
            continue
        affiliations = author.get("affiliation", [])
        units = []
        for affiliation in affiliations if isinstance(affiliations, list) else []:
            if isinstance(affiliation, dict):
                unit = ", ".join(part.strip() for part in _text(affiliation.get("name")).split(",") if part.strip())
                department = affiliation.get('department', [])
                if isinstance(department, str):
                    department = [department]
                if isinstance(department, list):
                    details = [_text(part) for part in department if isinstance(part, str) and _text(part)]
                    unit = ', '.join(details + [unit]) if unit else ''
                # The publisher deposit puts countries in `place`; retaining
                # it also distinguishes campuses of the same institution.
                places=affiliation.get('place',[])
                if isinstance(places,str):places=[places]
                if unit and isinstance(places,list):
                    for place in places:
                        if isinstance(place,str) and place.strip() and place.strip() not in unit:
                            unit+=', '+place.strip()
                if unit and unit not in units:
                    units.append(unit)
        if name not in authors:
            authors.append(name)
        institutions.extend(unit for unit in units if unit not in institutions)
        if units:
            pairs.append({"name": name, "institutions": units})
    # Funder and publisher fields deliberately do not establish author affiliations.
    return authors, institutions, pairs


class CrossrefClient:
    def __init__(self, cache_directory=None):
        self.cache_directory = Path(cache_directory) if cache_directory else None
        self.memory = {}
        self.lock = threading.Lock()
        self.next_request = 0.0
        self.unavailable = False

    @staticmethod
    def url(doi):
        return "https://api.crossref.org/works/" + urllib.parse.quote(doi, safe="")

    def _cache_path(self, doi):
        return self.cache_directory / (hashlib.sha256(doi.encode()).hexdigest() + ".json")

    def _read_cache(self, doi):
        if not self.cache_directory:
            return None
        try:
            saved = json.loads(self._cache_path(doi).read_text(encoding="utf-8"))
            age = datetime.now(timezone.utc) - datetime.fromisoformat(saved["retrieved_at"])
            record = saved["record"]
            if timedelta(0) <= age < timedelta(hours=6) and normalize_doi(record.get("DOI")) == doi:
                return record
        except (OSError, ValueError, KeyError, TypeError, AttributeError):
            pass
        return None

    def _save_cache(self, doi, record):
        if not self.cache_directory:
            return
        try:
            self.cache_directory.mkdir(parents=True, exist_ok=True)
            path = self._cache_path(doi)
            temporary = path.with_suffix(".tmp")
            temporary.write_text(json.dumps({"retrieved_at": datetime.now(timezone.utc).isoformat(),
                                             "record": record}, ensure_ascii=False), encoding="utf-8")
            temporary.replace(path)
        except OSError:
            pass  # A local cache failure must not prevent the digest.

    def lookup(self, value):
        doi = normalize_doi(value)
        if not doi:
            raise MetadataError("没有可验证的 DOI")
        with self.lock:
            if doi in self.memory:
                return self.memory[doi]
            cached = self._read_cache(doi)
            if cached is not None:
                self.memory[doi] = cached
                return cached
            if self.unavailable:
                raise MetadataError("Crossref 暂不可用，已停止本轮请求")
            for attempt in range(2):
                time.sleep(max(0, self.next_request - time.monotonic()))
                self.next_request = time.monotonic() + 1  # At most one request/second.
                request = urllib.request.Request(self.url(doi), headers={
                    "User-Agent": "ResearchDigest/2.0 (https://github.com/Thioacetone/-research-digest-mailer)",
                    "Accept": "application/json"})
                try:
                    with urllib.request.urlopen(request, timeout=25) as response:
                        data = response.read(3_000_001)
                    if len(data) > 3_000_000:
                        raise MetadataError("Crossref 返回内容超过大小限制")
                    payload = json.loads(data)
                    record = payload.get("message") if isinstance(payload, dict) else None
                    if (not isinstance(record, dict) or payload.get("status") != "ok"
                            or normalize_doi(record.get("DOI")) != doi):
                        raise MetadataError("Crossref 返回的 DOI 不匹配或数据无效")
                    self.memory[doi] = record
                    self._save_cache(doi, record)
                    return record
                except urllib.error.HTTPError as error:
                    code = error.code
                    error.close()
                    if code in (403, 429):
                        self.unavailable = True
                    if code not in (500, 502, 503, 504) or attempt == 1:
                        raise MetadataError(f"Crossref 返回 HTTP {code}") from None
                except (urllib.error.URLError, OSError):
                    if attempt == 1:
                        self.unavailable = True
                        raise MetadataError("Crossref 连接失败或超时") from None
                except (ValueError, TypeError):
                    raise MetadataError("Crossref 返回数据无法解析") from None
                self.next_request = time.monotonic() + 2
        raise MetadataError("Crossref 读取失败")
