/* Small shared clock, independent of device locale and DST. */
(function (root) {
  const offset = 8 * 60 * 60 * 1000;
  const dayLength = 24 * 60 * 60 * 1000;
  const clock = {
    day: milliseconds => new Date(milliseconds + offset).toISOString().slice(0, 10),
    untilMidnight: milliseconds => dayLength - ((milliseconds + offset) % dayLength + dayLength) % dayLength,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = clock;
  else root.ReadingClock = clock;
})(typeof window === 'undefined' ? {} : window);
